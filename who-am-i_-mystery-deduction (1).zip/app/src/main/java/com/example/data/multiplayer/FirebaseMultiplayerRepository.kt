package com.example.data.multiplayer

import com.example.model.AnswerType
import com.example.model.ClueLogItem
import com.example.model.GameCategory
import com.example.model.GameMode
import com.example.model.LiveRoom
import com.example.model.RankTier
import com.example.model.RoomPlayer
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

data class RealtimeMatchState(
    val roomId: String = "",
    val name: String = "",
    val category: GameCategory = GameCategory.ANIME,
    val mode: GameMode = GameMode.ONE_V_ONE,
    val hostId: String = "",
    val status: String = "LOBBY", // LOBBY, BAN_PHASE, CHARACTER_PICK, MATCH_ACTIVE, MATCH_SUMMARY
    val players: List<RoomPlayer> = emptyList(),
    val bannedCharacterIds: List<String> = emptyList(),
    val secretCharacterMap: Map<String, String> = emptyMap(), // playerId -> charId
    val currentTurnPlayerId: String = "",
    val turnNumber: Int = 1,
    val turnTimeRemaining: Int = 60,
    val pendingQuestion: ClueLogItem? = null,
    val clueLogs: List<ClueLogItem> = emptyList(),
    val winnerPlayerId: String? = null,
    val winnerPlayerName: String? = null,
    val isVoiceEnabled: Boolean = true,
    val isPasswordProtected: Boolean = false,
    val passwordPin: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

class FirebaseMultiplayerRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    /**
     * Observes available live rooms for the LiveRoomsScreen
     */
    fun observeLiveRooms(): Flow<List<LiveRoom>> = callbackFlow {
        val listener = firestore.collection("rooms")
            .whereEqualTo("status", "LOBBY")
            .addSnapshotListener { snapshot, error ->
                if (snapshot != null) {
                    val rooms = snapshot.documents.mapNotNull { it.toLiveRoom() }
                    trySend(rooms)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Subscribes to a single room in real-time
     */
    fun observeRoom(roomId: String): Flow<RealtimeMatchState?> = callbackFlow {
        if (roomId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val listener = firestore.collection("rooms").document(roomId)
            .addSnapshotListener { snapshot, error ->
                if (snapshot != null && snapshot.exists()) {
                    val matchState = snapshot.toRealtimeMatchState()
                    trySend(matchState)
                } else {
                    trySend(null)
                }
            }
        awaitClose { listener.remove() }
    }

    /**
     * Creates a new live room in Firestore
     */
    suspend fun createRoom(
        roomName: String,
        category: GameCategory,
        mode: GameMode,
        maxPlayers: Int,
        isVoiceEnabled: Boolean,
        isPasswordProtected: Boolean,
        passwordPin: String,
        turnTimerSec: Int,
        hostPlayer: RoomPlayer
    ): Result<String> {
        return try {
            val randomPin = (1000..9999).random().toString()
            val roomId = "ROOM-$randomPin"
            val roomData = hashMapOf<String, Any>(
                "id" to roomId,
                "name" to roomName.ifBlank { "غرفة ${hostPlayer.name} 🎙️" },
                "category" to category.name,
                "mode" to mode.name,
                "hostId" to hostPlayer.id,
                "hostName" to hostPlayer.name,
                "status" to "LOBBY",
                "maxPlayers" to maxPlayers,
                "currentPlayers" to 1,
                "isVoiceEnabled" to isVoiceEnabled,
                "isPasswordProtected" to isPasswordProtected,
                "passwordPin" to passwordPin,
                "turnTimerSec" to turnTimerSec,
                "players" to listOf(hostPlayer.toMap()),
                "bannedCharacterIds" to emptyList<String>(),
                "secretCharacterMap" to emptyMap<String, String>(),
                "currentTurnPlayerId" to hostPlayer.id,
                "turnNumber" to 1,
                "turnTimeRemaining" to turnTimerSec,
                "clueLogs" to emptyList<Map<String, Any>>(),
                "createdAt" to System.currentTimeMillis(),
                "updatedAt" to System.currentTimeMillis()
            )

            firestore.collection("rooms").document(roomId).set(roomData).await()
            Result.success(roomId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Joins an existing room
     */
    suspend fun joinRoom(roomId: String, player: RoomPlayer): Result<Unit> {
        return try {
            val docRef = firestore.collection("rooms").document(roomId)
            firestore.runTransaction { tx ->
                val snapshot = tx.get(docRef)
                if (!snapshot.exists()) {
                    throw Exception("الغرفة غير موجودة")
                }
                val playersRaw = snapshot.get("players") as? List<Map<String, Any>> ?: emptyList()
                val maxPlayers = (snapshot.getLong("maxPlayers") ?: 6L).toInt()

                // Check if already in room
                val existing = playersRaw.find { it["id"] == player.id }
                val updatedPlayers = if (existing != null) {
                    playersRaw.map { if (it["id"] == player.id) player.toMap() else it }
                } else {
                    if (playersRaw.size >= maxPlayers) {
                        throw Exception("الغرفة ممتلئة بالكامل!")
                    }
                    playersRaw + player.toMap()
                }

                tx.update(docRef, mapOf(
                    "players" to updatedPlayers,
                    "currentPlayers" to updatedPlayers.size,
                    "updatedAt" to System.currentTimeMillis()
                ))
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Leaves the room
     */
    suspend fun leaveRoom(roomId: String, playerId: String) {
        try {
            val docRef = firestore.collection("rooms").document(roomId)
            firestore.runTransaction { tx ->
                val snapshot = tx.get(docRef)
                if (!snapshot.exists()) return@runTransaction
                val playersRaw = snapshot.get("players") as? List<Map<String, Any>> ?: emptyList()
                val remaining = playersRaw.filterNot { it["id"] == playerId }

                if (remaining.isEmpty()) {
                    tx.delete(docRef)
                } else {
                    val hostId = snapshot.getString("hostId")
                    val newHostId = if (hostId == playerId) (remaining.first()["id"] as? String ?: "") else hostId
                    tx.update(docRef, mapOf(
                        "players" to remaining,
                        "currentPlayers" to remaining.size,
                        "hostId" to newHostId,
                        "updatedAt" to System.currentTimeMillis()
                    ))
                }
            }.await()
        } catch (_: Exception) {}
    }

    /**
     * Toggles ready state
     */
    suspend fun setPlayerReady(roomId: String, playerId: String, isReady: Boolean) {
        try {
            val docRef = firestore.collection("rooms").document(roomId)
            firestore.runTransaction { tx ->
                val snapshot = tx.get(docRef)
                if (!snapshot.exists()) return@runTransaction
                val playersRaw = snapshot.get("players") as? List<Map<String, Any>> ?: return@runTransaction
                val updated = playersRaw.map { p ->
                    if (p["id"] == playerId) {
                        val m = p.toMutableMap()
                        m["isReady"] = isReady
                        m
                    } else p
                }
                tx.update(docRef, "players", updated, "updatedAt", System.currentTimeMillis())
            }.await()
        } catch (_: Exception) {}
    }

    /**
     * Host starts the game from lobby
     */
    suspend fun startGame(roomId: String, initialStatus: String = "BAN_PHASE") {
        try {
            firestore.collection("rooms").document(roomId).update(
                mapOf(
                    "status" to initialStatus,
                    "turnNumber" to 1,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
        } catch (_: Exception) {}
    }

    /**
     * Submits a ban choice
     */
    suspend fun banCharacter(roomId: String, characterId: String) {
        try {
            val docRef = firestore.collection("rooms").document(roomId)
            firestore.runTransaction { tx ->
                val snapshot = tx.get(docRef)
                if (!snapshot.exists()) return@runTransaction
                val banned = (snapshot.get("bannedCharacterIds") as? List<String> ?: emptyList()).toMutableList()
                if (!banned.contains(characterId)) {
                    banned.add(characterId)
                }
                tx.update(docRef, "bannedCharacterIds", banned, "updatedAt", System.currentTimeMillis())
            }.await()
        } catch (_: Exception) {}
    }

    /**
     * Sets player's secret chosen character
     */
    suspend fun selectSecretCharacter(roomId: String, playerId: String, characterId: String) {
        try {
            firestore.collection("rooms").document(roomId).update(
                mapOf(
                    "secretCharacterMap.$playerId" to characterId,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
        } catch (_: Exception) {}
    }

    /**
     * Transitions match status
     */
    suspend fun updateMatchStatus(roomId: String, status: String) {
        try {
            firestore.collection("rooms").document(roomId).update(
                mapOf(
                    "status" to status,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
        } catch (_: Exception) {}
    }

    /**
     * Submits a question from active player
     */
    suspend fun askQuestion(roomId: String, clueItem: ClueLogItem) {
        try {
            firestore.collection("rooms").document(roomId).update(
                mapOf(
                    "pendingQuestion" to clueItem.toMap(),
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
        } catch (_: Exception) {}
    }

    /**
     * Submits defender's answer to the pending question
     */
    suspend fun answerQuestion(roomId: String, answeredItem: ClueLogItem, nextTurnPlayerId: String) {
        try {
            val docRef = firestore.collection("rooms").document(roomId)
            firestore.runTransaction { tx ->
                val snapshot = tx.get(docRef)
                if (!snapshot.exists()) return@runTransaction
                val existingLogs = (snapshot.get("clueLogs") as? List<Map<String, Any>> ?: emptyList()).toMutableList()
                existingLogs.add(answeredItem.toMap())
                val turnNum = (snapshot.getLong("turnNumber") ?: 1L).toInt() + 1

                tx.update(docRef, mapOf(
                    "pendingQuestion" to null,
                    "clueLogs" to existingLogs,
                    "currentTurnPlayerId" to nextTurnPlayerId,
                    "turnNumber" to turnNum,
                    "turnTimeRemaining" to 60,
                    "updatedAt" to System.currentTimeMillis()
                ))
            }.await()
        } catch (_: Exception) {}
    }

    /**
     * Concludes the match with winner
     */
    suspend fun finishMatch(roomId: String, winnerId: String, winnerName: String) {
        try {
            firestore.collection("rooms").document(roomId).update(
                mapOf(
                    "status" to "MATCH_SUMMARY",
                    "winnerPlayerId" to winnerId,
                    "winnerPlayerName" to winnerName,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
        } catch (_: Exception) {}
    }

    /**
     * Updates player speaking / mic in room
     */
    suspend fun updatePlayerAudioState(roomId: String, playerId: String, isSpeaking: Boolean, isMicOn: Boolean) {
        try {
            val docRef = firestore.collection("rooms").document(roomId)
            firestore.runTransaction { tx ->
                val snapshot = tx.get(docRef)
                if (!snapshot.exists()) return@runTransaction
                val playersRaw = snapshot.get("players") as? List<Map<String, Any>> ?: return@runTransaction
                val updated = playersRaw.map { p ->
                    if (p["id"] == playerId) {
                        val m = p.toMutableMap()
                        m["isSpeaking"] = isSpeaking
                        m["isMicOn"] = isMicOn
                        m
                    } else p
                }
                tx.update(docRef, "players", updated)
            }.await()
        } catch (_: Exception) {}
    }

    // Helper extensions
    private fun DocumentSnapshot.toLiveRoom(): LiveRoom? {
        return try {
            val catStr = getString("category") ?: GameCategory.ANIME.name
            val modeStr = getString("mode") ?: GameMode.FREE_FOR_ALL.name
            val playersRaw = get("players") as? List<Map<String, Any>> ?: emptyList()
            val players = playersRaw.mapNotNull { it.toRoomPlayer() }

            LiveRoom(
                id = id,
                name = getString("name") ?: "غرفة لعب",
                hostName = getString("hostName") ?: "المضيف",
                category = try { GameCategory.valueOf(catStr) } catch (_: Exception) { GameCategory.ANIME },
                mode = try { GameMode.valueOf(modeStr) } catch (_: Exception) { GameMode.FREE_FOR_ALL },
                currentPlayers = (getLong("currentPlayers") ?: 1L).toInt(),
                maxPlayers = (getLong("maxPlayers") ?: 6L).toInt(),
                isVoiceEnabled = getBoolean("isVoiceEnabled") ?: true,
                isPasswordProtected = getBoolean("isPasswordProtected") ?: false,
                passwordPin = getString("passwordPin") ?: "",
                pingMs = (15..35).random(),
                players = players
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun DocumentSnapshot.toRealtimeMatchState(): RealtimeMatchState {
        val catStr = getString("category") ?: GameCategory.ANIME.name
        val modeStr = getString("mode") ?: GameMode.ONE_V_ONE.name
        val playersRaw = get("players") as? List<Map<String, Any>> ?: emptyList()
        val players = playersRaw.mapNotNull { it.toRoomPlayer() }
        val banned = get("bannedCharacterIds") as? List<String> ?: emptyList()
        val secrets = get("secretCharacterMap") as? Map<String, String> ?: emptyMap()
        val pendingMap = get("pendingQuestion") as? Map<String, Any>
        val clueLogsRaw = get("clueLogs") as? List<Map<String, Any>> ?: emptyList()

        return RealtimeMatchState(
            roomId = id,
            name = getString("name") ?: "",
            category = try { GameCategory.valueOf(catStr) } catch (_: Exception) { GameCategory.ANIME },
            mode = try { GameMode.valueOf(modeStr) } catch (_: Exception) { GameMode.ONE_V_ONE },
            hostId = getString("hostId") ?: "",
            status = getString("status") ?: "LOBBY",
            players = players,
            bannedCharacterIds = banned,
            secretCharacterMap = secrets,
            currentTurnPlayerId = getString("currentTurnPlayerId") ?: "",
            turnNumber = (getLong("turnNumber") ?: 1L).toInt(),
            turnTimeRemaining = (getLong("turnTimeRemaining") ?: 60L).toInt(),
            pendingQuestion = pendingMap?.toClueLogItem(),
            clueLogs = clueLogsRaw.mapNotNull { it.toClueLogItem() },
            winnerPlayerId = getString("winnerPlayerId"),
            winnerPlayerName = getString("winnerPlayerName"),
            isVoiceEnabled = getBoolean("isVoiceEnabled") ?: true,
            isPasswordProtected = getBoolean("isPasswordProtected") ?: false,
            passwordPin = getString("passwordPin") ?: "",
            updatedAt = getLong("updatedAt") ?: System.currentTimeMillis()
        )
    }

    private fun RoomPlayer.toMap(): Map<String, Any> {
        return mapOf(
            "id" to id,
            "name" to name,
            "avatar" to avatar,
            "countryFlag" to countryFlag,
            "rankTier" to rankTier.name,
            "isHost" to isHost,
            "isReady" to isReady,
            "isMicOn" to isMicOn,
            "isSpeaking" to isSpeaking,
            "pingMs" to pingMs,
            "score" to score,
            "equippedTitle" to equippedTitle
        )
    }

    private fun Map<String, Any>.toRoomPlayer(): RoomPlayer? {
        return try {
            val tierStr = this["rankTier"] as? String ?: RankTier.SILVER.name
            RoomPlayer(
                id = this["id"] as? String ?: UUID.randomUUID().toString(),
                name = this["name"] as? String ?: "لاعب",
                avatar = this["avatar"] as? String ?: "👑",
                countryFlag = this["countryFlag"] as? String ?: "🇸🇦",
                rankTier = try { RankTier.valueOf(tierStr) } catch (_: Exception) { RankTier.SILVER },
                isHost = this["isHost"] as? Boolean ?: false,
                isReady = this["isReady"] as? Boolean ?: false,
                isLocalUser = false,
                isMicOn = this["isMicOn"] as? Boolean ?: true,
                isSpeaking = this["isSpeaking"] as? Boolean ?: false,
                pingMs = (this["pingMs"] as? Number)?.toInt() ?: 20,
                score = (this["score"] as? Number)?.toInt() ?: 0,
                equippedTitle = this["equippedTitle"] as? String ?: "تكتيكي مبتدئ ⚡"
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun ClueLogItem.toMap(): Map<String, Any> {
        return mapOf(
            "id" to id,
            "question" to question,
            "askedByPlayerName" to askedByPlayerName,
            "targetPlayerName" to targetPlayerName,
            "answer" to answer.name,
            "timestamp" to timestamp
        )
    }

    private fun Map<String, Any>.toClueLogItem(): ClueLogItem? {
        return try {
            val ansStr = this["answer"] as? String ?: AnswerType.YES.name
            ClueLogItem(
                id = this["id"] as? String ?: UUID.randomUUID().toString(),
                question = this["question"] as? String ?: "",
                askedByPlayerName = this["askedByPlayerName"] as? String ?: "",
                targetPlayerName = this["targetPlayerName"] as? String ?: "",
                answer = try { AnswerType.valueOf(ansStr) } catch (_: Exception) { AnswerType.YES },
                timestamp = this["timestamp"] as? String ?: ""
            )
        } catch (_: Exception) {
            null
        }
    }
}
