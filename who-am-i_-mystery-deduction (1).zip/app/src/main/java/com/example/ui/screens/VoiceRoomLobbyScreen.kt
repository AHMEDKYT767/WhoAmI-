package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.HeadsetOff
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SettingsVoice
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.QuickVoiceEmote
import com.example.model.RoomPlayer
import com.example.ui.components.LiveVoiceWaveVisualizer
import com.example.ui.components.PlayerVoiceControlModal
import com.example.ui.components.VoiceSettingsDialog
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.GameViewModel

@Composable
fun VoiceRoomLobbyScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val room by viewModel.currentLiveRoom.collectAsState()
    val voiceSettings by viewModel.voiceSettings.collectAsState()
    val quickEmotes by viewModel.quickVoiceEmotes.collectAsState()
    val profile by viewModel.profile.collectAsState()

    var selectedPlayerForVolume by remember { mutableStateOf<RoomPlayer?>(null) }
    var showVoiceSettingsModal by remember { mutableStateOf(false) }
    var copiedCodeToast by remember { mutableStateOf(false) }

    if (room == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(DarkBg),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "جاري تحميل الغرفة الصوتية...", color = TextMuted)
        }
        return
    }

    val currentRoom = room!!
    val isHost = currentRoom.players.find { it.isLocalUser }?.isHost == true
    val isLocalReady = currentRoom.players.find { it.isLocalUser }?.isReady == true
    val isLocalSpeaking = currentRoom.players.find { it.isLocalUser }?.isSpeaking == true

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Top Bar: Back, Room Info & Ping
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                IconButton(
                    onClick = { viewModel.leaveLiveRoom() },
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceHighlight)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column {
                    Text(
                        text = currentRoom.name,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${currentRoom.category.emoji} ${currentRoom.category.titleAr} • ${currentRoom.mode.titleAr}",
                        color = ElectricCyan,
                        fontSize = 11.sp
                    )
                }
            }

            // Room Code Copy Pill & Ping
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceHighlight,
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.5f)),
                    modifier = Modifier.clickable { copiedCodeToast = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "Copy Code",
                            tint = ElectricCyan,
                            modifier = Modifier.size(13.dp)
                        )
                        Text(
                            text = currentRoom.id,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = EmeraldGreen.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Wifi,
                            contentDescription = "Ping",
                            tint = EmeraldGreen,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "${currentRoom.pingMs}ms",
                            color = EmeraldGreen,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Room Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(80.dp)
                .clip(RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = DarkSurface)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.img_voice_room_banner),
                    contentDescription = "Voice Stage",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(DarkBg.copy(alpha = 0.85f), Color.Transparent)
                            )
                        )
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LiveVoiceWaveVisualizer(
                            isActive = true,
                            barColor = EmeraldGreen,
                            barCount = 6
                        )
                        Column {
                            Text(
                                text = "🎙️ دردشة صوتية حية فائقة الوضوح (HD Audio)",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "تحدث مباشرة مع اللاعبين واسأل بالمايك في دورك لتخمين الشخصية!",
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // Players Stage Grid (8 Slots)
        Text(
            text = "👥 مقاعد اللاعبين في الغرفة (${currentRoom.players.size}/${currentRoom.maxPlayers})",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(2.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(currentRoom.players) { player ->
                RoomPlayerPodCard(
                    player = player,
                    onPlayerClick = {
                        if (!player.isLocalUser) {
                            selectedPlayerForVolume = player
                        }
                    }
                )
            }

            // Empty Seats Placeholders
            val emptySeats = (currentRoom.maxPlayers - currentRoom.players.size).coerceAtLeast(0)
            items(emptySeats) { index ->
                EmptyPlayerPodCard(seatNumber = currentRoom.players.size + index + 1)
            }
        }

        // Quick Tactical Voice Emotes Row
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "⚡ ردود صوتية تكتيكية سريعة (Quick Voice Cues)",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(quickEmotes) { emote ->
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurfaceHighlight,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.4f)),
                        modifier = Modifier.clickable { viewModel.sendVoiceEmote(emote) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(text = emote.emoji, fontSize = 14.sp)
                            Text(
                                text = emote.textAr,
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Bottom Voice Control Dock & Ready/Start Button
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = DarkSurfaceVariant,
            border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Mic Control Buttons Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Push to talk hold trigger
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isLocalSpeaking) EmeraldGreen
                                else DarkSurfaceHighlight
                            )
                            .border(
                                1.dp,
                                if (isLocalSpeaking) EmeraldGreen else ElectricCyan.copy(alpha = 0.6f),
                                RoundedCornerShape(14.dp)
                            )
                            .pointerInput(Unit) {
                                detectTapGestures(
                                    onPress = {
                                        viewModel.setPushToTalkActive(true)
                                        tryAwaitRelease()
                                        viewModel.setPushToTalkActive(false)
                                    }
                                )
                            }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Push to Talk",
                                tint = if (isLocalSpeaking) DarkBg else ElectricCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = if (isLocalSpeaking) "🎙️ أنت تتحدث الآن..." else "اضغط هنا للتحدث (PTT)",
                                color = if (isLocalSpeaking) DarkBg else TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Mute / Unmute Mic Toggle
                    IconButton(
                        onClick = { viewModel.toggleVoiceMute() },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (voiceSettings.isMicMuted) WarningAmber.copy(alpha = 0.2f) else EmeraldGreen.copy(alpha = 0.2f))
                            .border(1.dp, if (voiceSettings.isMicMuted) WarningAmber else EmeraldGreen, CircleShape)
                            .testTag("btn_room_mic_toggle")
                    ) {
                        Icon(
                            imageVector = if (voiceSettings.isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Mic Toggle",
                            tint = if (voiceSettings.isMicMuted) WarningAmber else EmeraldGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Deafen Toggle
                    IconButton(
                        onClick = { viewModel.toggleDeafen() },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (voiceSettings.isDeafened) HotPink.copy(alpha = 0.2f) else DarkSurfaceHighlight)
                            .border(1.dp, if (voiceSettings.isDeafened) HotPink else DarkSurfaceHighlight, CircleShape)
                    ) {
                        Icon(
                            imageVector = if (voiceSettings.isDeafened) Icons.Default.HeadsetOff else Icons.Default.Headphones,
                            contentDescription = "Deafen Toggle",
                            tint = if (voiceSettings.isDeafened) HotPink else TextPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Voice Settings Modal Button
                    IconButton(
                        onClick = { showVoiceSettingsModal = true },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceHighlight)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SettingsVoice,
                            contentDescription = "Voice Settings",
                            tint = ElectricCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Ready / Start Game Action
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.toggleRoomReady() },
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                            .testTag("btn_room_ready"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isLocalReady) EmeraldGreen else DarkSurfaceHighlight
                        ),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Ready",
                            tint = if (isLocalReady) DarkBg else TextPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isLocalReady) "أنت جاهز ✅" else "تأكيد الجاهزية (Ready)",
                            color = if (isLocalReady) DarkBg else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    if (isHost) {
                        Button(
                            onClick = { viewModel.launchRoomGame() },
                            modifier = Modifier
                                .weight(1.2f)
                                .height(44.dp)
                                .testTag("btn_room_start"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricCyan
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Start",
                                tint = DarkBg,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "انطلاق المباراة 🚀",
                                color = DarkBg,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Modals
    if (selectedPlayerForVolume != null) {
        PlayerVoiceControlModal(
            player = selectedPlayerForVolume!!,
            onDismiss = { selectedPlayerForVolume = null },
            onVolumeChange = { vol ->
                viewModel.setPlayerVolume(selectedPlayerForVolume!!.id, vol)
            },
            onToggleMute = {
                viewModel.togglePlayerMuteInRoom(selectedPlayerForVolume!!.id)
            }
        )
    }

    if (showVoiceSettingsModal) {
        VoiceSettingsDialog(
            settings = voiceSettings,
            onDismiss = { showVoiceSettingsModal = false },
            onToggleDeafen = { viewModel.toggleDeafen() },
            onTogglePushToTalk = { viewModel.setPushToTalk(it) }
        )
    }
}

@Composable
fun RoomPlayerPodCard(
    player: RoomPlayer,
    onPlayerClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "speaking_pulse")
    val pulseScale = if (player.isSpeaking) {
        infiniteTransition.animateFloat(
            initialValue = 1.0f,
            targetValue = 1.08f,
            animationSpec = infiniteRepeatable(
                animation = tween(400),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse"
        ).value
    } else 1.0f

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onPlayerClick() }
            .border(
                width = if (player.isSpeaking) 2.dp else if (player.isReady) 1.dp else 0.5.dp,
                color = if (player.isSpeaking) EmeraldGreen
                else if (player.isReady) ElectricCyan.copy(alpha = 0.7f)
                else DarkSurfaceHighlight,
                shape = RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(
            containerColor = if (player.isLocalUser) DarkSurfaceHighlight else DarkSurfaceVariant
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Header: Host / Ready Tag
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (player.isHost) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = CyberGold.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, CyberGold)
                    ) {
                        Text(
                            text = "👑 المضيف",
                            color = CyberGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(4.dp))
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (player.isReady) EmeraldGreen.copy(alpha = 0.2f) else DarkSurfaceHighlight
                ) {
                    Text(
                        text = if (player.isReady) "جاهز ✅" else "ينتظر...",
                        color = if (player.isReady) EmeraldGreen else TextMuted,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                    )
                }
            }

            // Avatar with pulse scale and Speaking Wave Ring
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .scale(pulseScale),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                if (player.isSpeaking) listOf(EmeraldGreen.copy(alpha = 0.4f), DarkSurfaceHighlight)
                                else listOf(NeonPurple.copy(alpha = 0.3f), DarkSurfaceHighlight)
                            )
                        )
                        .border(
                            width = if (player.isSpeaking) 2.5.dp else 1.5.dp,
                            color = if (player.isSpeaking) EmeraldGreen else NeonPurple,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = player.avatar, fontSize = 28.sp)
                }

                // Mic Badge on bottom-right of avatar
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(if (player.isMicOn) EmeraldGreen else WarningAmber)
                        .border(1.dp, DarkBg, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (player.isMicOn) Icons.Default.Mic else Icons.Default.MicOff,
                        contentDescription = "Mic",
                        tint = DarkBg,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }

            // Player Name and country
            Text(
                text = "${player.countryFlag} ${player.name}",
                color = TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Title & Tier
            Text(
                text = player.equippedTitle,
                color = ElectricCyan,
                fontSize = 10.sp
            )

            // Voice visualizer wave & ping
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                LiveVoiceWaveVisualizer(
                    isActive = player.isSpeaking,
                    barColor = EmeraldGreen,
                    barCount = 4
                )
                Text(
                    text = "${player.pingMs}ms",
                    color = TextMuted,
                    fontSize = 9.sp
                )
            }
        }
    }
}

@Composable
fun EmptyPlayerPodCard(
    seatNumber: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(
                1.dp,
                DarkSurfaceHighlight,
                RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = DarkSurface.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceHighlight.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "+", color = TextMuted, fontSize = 24.sp, fontWeight = FontWeight.Light)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "مقعد شاغر #$seatNumber",
                color = TextMuted,
                fontSize = 11.sp
            )
            Text(
                text = "في انتظار لاعب...",
                color = TextMuted.copy(alpha = 0.7f),
                fontSize = 9.sp
            )
        }
    }
}
