package com.example.model

enum class UserPresenceStatus(val titleAr: String, val emoji: String) {
    ONLINE("متصل الآن", "🟢"),
    IN_LOBBY("في غرفة انتظار", "🎙️"),
    IN_GAME("في مباراة حية", "⚔️"),
    OFFLINE("غير متصل", "⚪");

    val displayName: String get() = when (this) {
        ONLINE -> "Online"
        IN_LOBBY -> "In Lobby"
        IN_GAME -> "In Match"
        OFFLINE -> "Offline"
    }
}

data class UserProfile(
    val id: String = "user_me",
    val username: String = "NAGATO",
    val email: String = "",
    val avatarEmoji: String = "🦊",
    val equippedAvatar: String = "🦊",
    val equippedTitle: String = "🧠 Mastermind",
    val rankTier: RankTier = RankTier.DIAMOND,
    val rankPoints: Int = 2140,
    val level: Int = 18,
    val xp: Int = 4320,
    val coins: Int = 850,
    val gems: Int = 50,
    val gamesPlayed: Int = 840,
    val gamesWon: Int = 570,
    val totalGames: Int = 840,
    val wins: Int = 570,
    val winStreak: Int = 12,
    val highestStreak: Int = 15,
    val accuracyPercent: Int = 82,
    val fastestGuessSeconds: Float = 2.3f,
    val equippedFrame: String = "frame_cyber_neon",
    val unlockedCharacterIds: Set<String> = setOf("naruto", "luffy", "levi", "messi", "ronaldo", "kratos", "mario", "batman", "spongebob", "walter_white", "einstein", "godzilla", "pikachu"),
    val categoryMastery: Map<GameCategory, Int> = mapOf(
        GameCategory.ANIME to 94,
        GameCategory.FOOTBALL to 71,
        GameCategory.VIDEO_GAMES to 86,
        GameCategory.SUPERHEROES to 88,
        GameCategory.CARTOONS to 90,
        GameCategory.MOVIES_SERIES to 78,
        GameCategory.HISTORICAL to 65,
        GameCategory.CREATURES to 82,
        GameCategory.CARS to 60,
        GameCategory.SPORTS to 74
    )
) {
    val totalMatches: Int get() = totalGames
    val totalWins: Int get() = wins
    val currentStreak: Int get() = winStreak
    val bestStreak: Int get() = highestStreak
}

data class FriendUser(
    val id: String = "",
    val username: String = "",
    val avatarEmoji: String = "👑",
    val rankTier: RankTier = RankTier.SILVER,
    val rankPoints: Int = 1200,
    val level: Int = 1,
    val status: UserPresenceStatus = UserPresenceStatus.ONLINE,
    val customStatusText: String = "",
    val isFavorite: Boolean = false,
    val unreadMessagesCount: Int = 0
)

data class FriendRequest(
    val id: String = "",
    val fromUserId: String = "",
    val fromUsername: String = "",
    val fromAvatar: String = "👑",
    val fromRank: RankTier = RankTier.SILVER,
    val timestamp: Long = System.currentTimeMillis(),
    val status: FriendRequestStatus = FriendRequestStatus.PENDING
)

enum class FriendRequestStatus {
    PENDING,
    ACCEPTED,
    DECLINED
}

data class GameInvite(
    val id: String = "",
    val roomId: String = "",
    val roomName: String = "",
    val category: GameCategory = GameCategory.ANIME,
    val mode: GameMode = GameMode.ONE_V_ONE,
    val fromUserId: String = "",
    val fromUsername: String = "",
    val fromAvatar: String = "👑",
    val timestamp: Long = System.currentTimeMillis()
)

data class SocialChatMessage(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val messageText: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isSystemNotice: Boolean = false
)
