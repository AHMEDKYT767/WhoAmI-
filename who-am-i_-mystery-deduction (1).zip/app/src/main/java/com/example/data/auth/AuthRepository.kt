package com.example.data.auth

import android.content.Context
import com.example.model.RankTier
import com.example.model.UserProfile
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

sealed class AuthState {
    data object Idle : AuthState()
    data object Loading : AuthState()
    data class Authenticated(val user: UserProfile) : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthRepository(
    private val context: Context,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    val currentUser: FirebaseUser?
        get() = auth.currentUser

    fun observeAuthState(): Flow<UserProfile?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            if (user != null) {
                // Fetch user document from firestore
                firestore.collection("users").document(user.uid)
                    .addSnapshotListener { snapshot, error ->
                        if (snapshot != null && snapshot.exists()) {
                            val profile = snapshot.toUserProfile(user)
                            trySend(profile)
                        } else {
                            // Document might not exist yet, build initial profile
                            val initialProfile = createDefaultProfile(user)
                            trySend(initialProfile)
                        }
                    }
            } else {
                trySend(null)
            }
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    suspend fun signInAnonymously(): Result<UserProfile> {
        return try {
            val authResult = auth.signInAnonymously().await()
            val user = authResult.user ?: throw Exception("فشل تسجيل الدخول كضيف")
            val profile = createDefaultProfile(user)
            saveUserProfile(profile)
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun signInWithEmail(email: String, pass: String): Result<UserProfile> {
        return try {
            val authResult = auth.signInWithEmailAndPassword(email.trim(), pass).await()
            val user = authResult.user ?: throw Exception("المستخدم غير موجود")
            val doc = firestore.collection("users").document(user.uid).get().await()
            val profile = if (doc.exists()) {
                doc.toUserProfile(user)
            } else {
                val newProfile = createDefaultProfile(user)
                saveUserProfile(newProfile)
                newProfile
            }
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registerWithEmail(email: String, pass: String, username: String): Result<UserProfile> {
        return try {
            val authResult = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
            val user = authResult.user ?: throw Exception("فشل إنشاء الحساب")
            val profile = createDefaultProfile(user).copy(
                username = username.ifBlank { "لاعب_${user.uid.take(5)}" },
                email = email
            )
            saveUserProfile(profile)
            Result.success(profile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun saveUserProfile(profile: UserProfile): Result<Unit> {
        return try {
            val uid = profile.id.ifBlank { auth.currentUser?.uid ?: "user_me" }
            val map = hashMapOf<String, Any>(
                "id" to uid,
                "username" to profile.username,
                "email" to profile.email,
                "avatarEmoji" to profile.avatarEmoji,
                "equippedAvatar" to profile.equippedAvatar,
                "equippedTitle" to profile.equippedTitle,
                "rankTier" to profile.rankTier.name,
                "rankPoints" to profile.rankPoints,
                "level" to profile.level,
                "xp" to profile.xp,
                "coins" to profile.coins,
                "gems" to profile.gems,
                "gamesPlayed" to profile.gamesPlayed,
                "gamesWon" to profile.gamesWon,
                "winStreak" to profile.winStreak,
                "highestStreak" to profile.highestStreak,
                "accuracyPercent" to profile.accuracyPercent,
                "status" to "ONLINE",
                "lastActive" to System.currentTimeMillis()
            )
            firestore.collection("users").document(uid).set(map, SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updatePresence(status: String) {
        val uid = auth.currentUser?.uid ?: return
        try {
            firestore.collection("users").document(uid).update(
                mapOf(
                    "status" to status,
                    "lastActive" to System.currentTimeMillis()
                )
            ).await()
        } catch (_: Exception) {}
    }

    fun signOut() {
        auth.signOut()
    }

    private fun createDefaultProfile(user: FirebaseUser): UserProfile {
        val randomSuffix = user.uid.take(4).uppercase()
        return UserProfile(
            id = user.uid,
            username = if (user.isAnonymous) "لاعب_ضيف_$randomSuffix" else (user.displayName ?: "بطل_التخمين_$randomSuffix"),
            email = user.email ?: "",
            avatarEmoji = "👑",
            rankTier = RankTier.SILVER,
            rankPoints = 1250,
            level = 1,
            xp = 250,
            coins = 1500,
            gems = 50,
            equippedAvatar = "👑",
            equippedTitle = "تكتيكي مبتدئ ⚡"
        )
    }

    private fun com.google.firebase.firestore.DocumentSnapshot.toUserProfile(user: FirebaseUser): UserProfile {
        val rankStr = getString("rankTier") ?: RankTier.SILVER.name
        val tier = try { RankTier.valueOf(rankStr) } catch (_: Exception) { RankTier.SILVER }

        return UserProfile(
            id = id,
            username = getString("username") ?: (user.displayName ?: "لاعب_${id.take(4)}"),
            email = getString("email") ?: (user.email ?: ""),
            avatarEmoji = getString("avatarEmoji") ?: "👑",
            equippedAvatar = getString("equippedAvatar") ?: "👑",
            equippedTitle = getString("equippedTitle") ?: "تكتيكي مبتدئ ⚡",
            rankTier = tier,
            rankPoints = (getLong("rankPoints") ?: 1250L).toInt(),
            level = (getLong("level") ?: 1L).toInt(),
            xp = (getLong("xp") ?: 250L).toInt(),
            coins = (getLong("coins") ?: 1500L).toInt(),
            gems = (getLong("gems") ?: 50L).toInt(),
            gamesPlayed = (getLong("gamesPlayed") ?: 0L).toInt(),
            gamesWon = (getLong("gamesWon") ?: 0L).toInt(),
            winStreak = (getLong("winStreak") ?: 0L).toInt(),
            highestStreak = (getLong("highestStreak") ?: 0L).toInt(),
            accuracyPercent = (getLong("accuracyPercent") ?: 85L).toInt()
        )
    }
}
