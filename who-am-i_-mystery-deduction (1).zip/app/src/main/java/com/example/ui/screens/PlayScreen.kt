package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameCategory
import com.example.model.GameMode
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyanBlue
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.RadiantViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.GameScreen
import com.example.viewmodel.GameViewModel

@Composable
fun PlayScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf(GameCategory.ANIME) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Screen Header
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "PLAY",
                    color = TextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Select a mode and category to enter the match",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        // Category Horizontal Selector
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "SELECT CATEGORY",
                    color = TextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(GameCategory.values()) { cat ->
                        val isSelected = cat == selectedCategory
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { selectedCategory = cat }
                                .border(
                                    1.dp,
                                    if (isSelected) ElectricPurple else BorderGlow,
                                    RoundedCornerShape(12.dp)
                                ),
                            color = if (isSelected) DarkSurfaceHighlight else DarkSurfaceVariant.copy(alpha = 0.7f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(text = cat.emoji, fontSize = 16.sp)
                                Text(
                                    text = cat.titleEn,
                                    color = if (isSelected) Color.White else TextSecondary,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        // Mode 1: Quick Match
        item {
            PlayModeCard(
                icon = "⚡",
                title = "Quick Match",
                description = "Fast online matchmaking with 1v1 tactical turns.",
                accentColor = CyanBlue,
                onClick = {
                    viewModel.startMatchSetup(GameMode.ONE_V_ONE, selectedCategory)
                },
                tag = "play_quick_match"
            )
        }

        // Mode 2: Ranked
        item {
            PlayModeCard(
                icon = "🏆",
                title = "Ranked",
                description = "Compete for Rank Points (RP) and climb the global ladder.",
                accentColor = ElectricPurple,
                onClick = {
                    viewModel.startMatchSetup(GameMode.RANKED, selectedCategory)
                },
                tag = "play_ranked_match"
            )
        }

        // Mode 3: Group / Teams
        item {
            PlayModeCard(
                icon = "👥",
                title = "Group & Teams",
                description = "Play 2v2 or team battles with multiple players.",
                accentColor = EmeraldGreen,
                onClick = {
                    viewModel.startMatchSetup(GameMode.TEAMS, selectedCategory)
                },
                tag = "play_teams_match"
            )
        }

        // Mode 4: Custom Room
        item {
            PlayModeCard(
                icon = "🏠",
                title = "Custom Room",
                description = "Create or join a private room with custom rules.",
                accentColor = CyberGold,
                onClick = {
                    viewModel.navigateTo(GameScreen.LIVE_ROOMS)
                },
                tag = "play_custom_room"
            )
        }

        // Mode 5: Party Mode
        item {
            PlayModeCard(
                icon = "🎉",
                title = "Party Mode",
                description = "Casual deduction with friends up to 8 players.",
                accentColor = HotPink,
                onClick = {
                    viewModel.startMatchSetup(GameMode.PARTY, selectedCategory)
                },
                tag = "play_party_match"
            )
        }

        // Mode 6: Live Voice Rooms
        item {
            PlayModeCard(
                icon = "🎙️",
                title = "Live Voice Rooms",
                description = "Voice chat enabled rooms with real-time audio deduction.",
                accentColor = EmeraldGreen,
                onClick = {
                    viewModel.navigateTo(GameScreen.LIVE_ROOMS)
                },
                tag = "play_live_voice"
            )
        }

        // Mode 7: 64-Player Tournament
        item {
            PlayModeCard(
                icon = "🏟️",
                title = "64-Player Tournament",
                description = "Championship elimination bracket for supreme glory.",
                accentColor = RadiantViolet,
                onClick = {
                    viewModel.navigateTo(GameScreen.TOURNAMENT)
                },
                tag = "play_tournament"
            )
        }
    }
}

@Composable
private fun PlayModeCard(
    icon: String,
    title: String,
    description: String,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tag: String = ""
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .border(1.dp, BorderGlow, RoundedCornerShape(16.dp))
            .testTag(tag),
        color = DarkSurfaceVariant.copy(alpha = 0.85f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f))
                        .border(1.dp, accentColor.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = icon, fontSize = 22.sp)
                }

                Column {
                    Text(
                        text = title,
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = description,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Surface(
                shape = RoundedCornerShape(10.dp),
                color = accentColor.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, accentColor.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "PLAY",
                        color = accentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Go",
                        tint = accentColor,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}
