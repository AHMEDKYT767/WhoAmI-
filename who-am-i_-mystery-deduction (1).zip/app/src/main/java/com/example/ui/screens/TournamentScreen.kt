package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TournamentNode
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.RadiantViolet
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.GameViewModel

@Composable
fun TournamentScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val nodes by viewModel.tournamentNodes.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Tournament Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = RadiantViolet.copy(alpha = 0.35f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, CyberGold)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(CyberGold.copy(alpha = 0.2f))
                            .border(1.dp, CyberGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🏟️", fontSize = 28.sp)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "بطولة الـ 64 الكبرى — Grand Tournament",
                            color = CyberGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "64 Players ➔ 32 ➔ 16 ➔ 8 ➔ 4 ➔ 2 ➔ 🏆 CHAMPION",
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                        Text(
                            text = "جائزة البطل: 5,000 كوينز + لقب أسطوري في لوحة المتصدرين!",
                            color = ElectricCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Bracket Matches List
        item {
            Text(
                text = "⚔️ مباريات التصفيات الحالية (Live Bracket):",
                color = TextPrimary,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }

        items(nodes) { node ->
            TournamentMatchCard(
                node = node,
                onPlayMatch = { viewModel.playOrSimulateTournamentMatch(node.id) }
            )
        }
    }
}

@Composable
fun TournamentMatchCard(
    node: TournamentNode,
    onPlayMatch: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                1.dp,
                if (node.isCompleted) EmeraldGreen.copy(alpha = 0.4f) else DarkSurfaceHighlight,
                RoundedCornerShape(16.dp)
            )
            .testTag("tournament_match_${node.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = node.roundName,
                    color = ElectricCyan,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (node.isCompleted) EmeraldGreen.copy(alpha = 0.2f) else DarkSurfaceHighlight
                ) {
                    Text(
                        text = if (node.isCompleted) "مكتملة ✅" else "جارية ⏱️",
                        color = if (node.isCompleted) EmeraldGreen else CyberGold,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Player 1 Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (node.winnerName == node.player1Name) EmeraldGreen.copy(alpha = 0.15f) else DarkSurface)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = node.player1Name,
                    color = if (node.winnerName == node.player1Name) EmeraldGreen else TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (node.isCompleted) "${node.score1}" else "-",
                    color = if (node.winnerName == node.player1Name) EmeraldGreen else TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Player 2 Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (node.winnerName == node.player2Name) EmeraldGreen.copy(alpha = 0.15f) else DarkSurface)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = node.player2Name,
                    color = if (node.winnerName == node.player2Name) EmeraldGreen else TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = if (node.isCompleted) "${node.score2}" else "-",
                    color = if (node.winnerName == node.player2Name) EmeraldGreen else TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black
                )
            }

            if (!node.isCompleted) {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = onPlayMatch,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(38.dp)
                        .testTag("btn_play_tournament_${node.id}"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(
                        text = "بدء / محاكاة المباراة ⚔️",
                        color = DarkBg,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
