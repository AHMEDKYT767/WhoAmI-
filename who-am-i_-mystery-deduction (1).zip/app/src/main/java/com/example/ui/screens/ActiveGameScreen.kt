package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Character
import com.example.model.Player
import com.example.ui.components.AskQuestionBottomSheet
import com.example.ui.components.ClueLogCard
import com.example.ui.components.GuessCharacterDialog
import com.example.ui.components.InGameVoiceHud
import com.example.ui.components.InteractiveEliminationCard
import com.example.ui.components.MatchTimerBar
import com.example.ui.components.OpponentsCarousel
import com.example.ui.components.PowerCardsDeck
import com.example.ui.components.ReportPlayerDialog
import com.example.ui.components.VoiceSettingsDialog
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.HotPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.GameViewModel

@Composable
fun ActiveGameScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val matchState by viewModel.matchState.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val voiceSettings by viewModel.voiceSettings.collectAsState()

    var selectedTab by remember { mutableStateOf(0) } // 0: Game Board, 1: Clue Log
    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") }

    var showQuestionModal by remember { mutableStateOf(false) }
    var showGuessModal by remember { mutableStateOf(false) }
    var showVoiceSettingsModal by remember { mutableStateOf(false) }
    var reportingPlayer by remember { mutableStateOf<Player?>(null) }
    var selectedTargetOpponentId by remember { mutableStateOf(matchState.opponents.firstOrNull()?.id) }

    val filteredCharacters = remember(
        matchState.availableCharacters,
        matchState.eliminatedCharacterIds,
        matchState.bookmarkedCharacterIds,
        searchQuery,
        selectedFilter
    ) {
        matchState.availableCharacters.filter { char ->
            val matchesSearch = searchQuery.isEmpty() ||
                    char.nameAr.contains(searchQuery, ignoreCase = true) ||
                    char.name.contains(searchQuery, ignoreCase = true) ||
                    char.origin.contains(searchQuery, ignoreCase = true)

            val isEliminated = matchState.eliminatedCharacterIds.contains(char.id)
            val isBookmarked = matchState.bookmarkedCharacterIds.contains(char.id)

            val matchesFilter = when (selectedFilter) {
                "BOOKMARKED" -> isBookmarked
                "ACTIVE" -> !isEliminated
                "ELIMINATED" -> isEliminated
                else -> true
            }

            matchesSearch && matchesFilter
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Top Bar: Timer, Voice Status & Alert
            MatchTimerBar(
                timeRemainingSeconds = matchState.timeRemainingSeconds,
                isFinalTenSeconds = matchState.isFinalTenSeconds,
                isVoiceMuted = matchState.isVoiceChatMuted,
                isSpeaking = matchState.isSpeaking,
                onToggleVoice = { viewModel.toggleVoiceMute() },
                onToggleSpeaking = { viewModel.toggleSpeakingState() }
            )

            // In-Game Live Voice HUD
            InGameVoiceHud(
                isMicMuted = voiceSettings.isMicMuted,
                isSpeaking = matchState.isSpeaking,
                activeSpeakerName = matchState.opponents.firstOrNull { it.isTalking }?.name,
                onToggleMic = { viewModel.toggleVoiceMute() },
                onPushToTalkPress = { isPressed -> viewModel.setPushToTalkActive(isPressed) },
                onOpenVoiceSettings = { showVoiceSettingsModal = true },
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp)
            )

            // Secret Character HUD Card
            matchState.localPlayer.secretCharacter?.let { mySecret ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp)
                        .border(1.dp, NeonPurple.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🤫 شخصيتك السرية:", color = TextSecondary, fontSize = 11.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = mySecret.nameAr,
                                color = HotPink,
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp
                            )
                        }

                        Text(
                            text = "(${mySecret.origin})",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // Opponents Carousel
            OpponentsCarousel(
                opponents = matchState.opponents,
                selectedOpponentId = selectedTargetOpponentId,
                onSelectOpponent = { selectedTargetOpponentId = it },
                onReportOpponent = { reportingPlayer = it }
            )

            // Power Cards Row
            PowerCardsDeck(
                userCoins = profile.coins,
                onActivatePower = { viewModel.activatePowerCard(it) }
            )

            // Tabs
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = ElectricCyan,
                edgePadding = 16.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = ElectricCyan
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "🎴 لوحة الشخصيات (${matchState.availableCharacters.size - matchState.eliminatedCharacterIds.size} متبقية)",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "📜 سجل الأسئلة والأدلة (${matchState.clueLogs.size})",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 12.sp
                        )
                    }
                )
            }

            // Tab Content
            when (selectedTab) {
                0 -> {
                    // Search & Quick Filter Chips
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("بحث عن شخصية أو عمل...", fontSize = 12.sp, color = TextMuted) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Search,
                                    contentDescription = "Search",
                                    tint = TextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextMuted)
                                    }
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("active_search_input"),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricCyan,
                                unfocusedBorderColor = DarkSurfaceHighlight,
                                focusedContainerColor = DarkSurfaceVariant,
                                unfocusedContainerColor = DarkSurfaceVariant,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Filter Chips
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            ActiveFilterChip(
                                label = "الكل",
                                isSelected = selectedFilter == "ALL",
                                onClick = { selectedFilter = "ALL" }
                            )
                            ActiveFilterChip(
                                label = "⭐ المشتبه بهم",
                                isSelected = selectedFilter == "BOOKMARKED",
                                onClick = { selectedFilter = "BOOKMARKED" }
                            )
                            ActiveFilterChip(
                                label = "✅ المتاحة",
                                isSelected = selectedFilter == "ACTIVE",
                                onClick = { selectedFilter = "ACTIVE" }
                            )
                            ActiveFilterChip(
                                label = "❌ المستبعدة",
                                isSelected = selectedFilter == "ELIMINATED",
                                onClick = { selectedFilter = "ELIMINATED" }
                            )
                        }
                    }

                    // Grid of Characters with Elimination support
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 4.dp, bottom = 90.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("active_characters_grid")
                    ) {
                        items(filteredCharacters, key = { it.id }) { character ->
                            val isEliminated = matchState.eliminatedCharacterIds.contains(character.id)
                            val isBookmarked = matchState.bookmarkedCharacterIds.contains(character.id)

                            InteractiveEliminationCard(
                                character = character,
                                isEliminated = isEliminated,
                                isBookmarked = isBookmarked,
                                onToggleEliminate = { viewModel.toggleEliminateCharacter(character.id) },
                                onToggleBookmark = { viewModel.toggleBookmarkCharacter(character.id) },
                                onGuessCharacter = {
                                    showGuessModal = true
                                }
                            )
                        }
                    }
                }

                1 -> {
                    // Clue Log Stream
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = 90.dp),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) {
                        items(matchState.clueLogs.reversed()) { logItem ->
                            ClueLogCard(item = logItem)
                        }
                    }
                }
            }
        }

        // Floating Bottom Actions Bar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(20.dp),
            color = DarkSurfaceVariant.copy(alpha = 0.95f),
            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGlow)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { showQuestionModal = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("btn_open_ask_modal"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple)
                ) {
                    Text(text = "❓ اسأل سؤالاً", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Button(
                    onClick = { showGuessModal = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("btn_open_guess_modal"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = HotPink)
                ) {
                    Text(text = "🎯 خمن الشخصية!", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        // Modals
        if (showQuestionModal) {
            AskQuestionBottomSheet(
                opponents = matchState.opponents,
                selectedOpponentId = selectedTargetOpponentId,
                onSendQuestion = { question, targetId ->
                    viewModel.askQuestion(question, targetId)
                    showQuestionModal = false
                },
                onDismiss = { showQuestionModal = false }
            )
        }

        if (showGuessModal) {
            GuessCharacterDialog(
                opponents = matchState.opponents,
                characters = matchState.availableCharacters,
                eliminatedIds = matchState.eliminatedCharacterIds,
                onConfirmGuess = { targetId, character ->
                    viewModel.submitGuess(targetId, character)
                    showGuessModal = false
                },
                onDismiss = { showGuessModal = false }
            )
        }

        reportingPlayer?.let { player ->
            ReportPlayerDialog(
                player = player,
                onReport = { reason ->
                    viewModel.reportPlayer(player.name, reason)
                    reportingPlayer = null
                },
                onMuteToggle = {
                    viewModel.toggleVoiceMute()
                    reportingPlayer = null
                },
                onDismiss = { reportingPlayer = null }
            )
        }

        if (showVoiceSettingsModal) {
            VoiceSettingsDialog(
                settings = voiceSettings,
                onDismiss = { showVoiceSettingsModal = false },
                onToggleDeafen = { viewModel.toggleDeafen() },
                onTogglePushToTalk = { viewModel.setPushToTalk(it) }
            )
        }
    }
}

@Composable
fun ActiveFilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) ElectricCyan.copy(alpha = 0.25f) else DarkSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) ElectricCyan else DarkSurfaceHighlight
        )
    ) {
        Text(
            text = label,
            color = if (isSelected) ElectricCyan else TextSecondary,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}
