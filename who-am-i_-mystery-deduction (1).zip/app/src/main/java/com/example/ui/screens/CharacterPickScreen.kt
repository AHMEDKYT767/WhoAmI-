package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Character
import com.example.model.Difficulty
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyanBlue
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.GameViewModel
import com.example.viewmodel.MatchPhase

@Composable
fun CharacterPickScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val matchState by viewModel.matchState.collectAsState()
    val availableChars = matchState.availableCharacters.filterNot { matchState.bannedCharacterIds.contains(it.id) }

    var searchQuery by remember { mutableStateOf("") }
    var chosenCharacter by remember { mutableStateOf<Character?>(availableChars.firstOrNull()) }

    val filtered = remember(availableChars, searchQuery) {
        availableChars.filter { char ->
            searchQuery.isBlank() ||
                    char.nameEn.contains(searchQuery, ignoreCase = true) ||
                    char.nameAr.contains(searchQuery, ignoreCase = true) ||
                    char.origin.contains(searchQuery, ignoreCase = true)
        }
    }

    val isLocked = matchState.phase == MatchPhase.CHARACTER_LOCKED

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .padding(bottom = 90.dp)
        ) {
            // 1. Header & Category Display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CHOOSE YOUR SECRET CHARACTER",
                        color = TextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Opponent will have to guess who you picked",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurfaceHighlight,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderGlow)
                ) {
                    Text(
                        text = "${matchState.category.emoji} ${matchState.category.titleEn}",
                        color = CyanBlue,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Search Field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search character...", color = TextMuted, fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.6f),
                    unfocusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.6f),
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = BorderGlow,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )

            Spacer(modifier = Modifier.height(14.dp))

            // 3. Grid of Character Cards
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filtered) { character ->
                    val isSelected = chosenCharacter?.id == character.id
                    PickCharacterCard(
                        character = character,
                        isSelected = isSelected,
                        onClick = {
                            if (!isLocked) chosenCharacter = character
                        }
                    )
                }
            }
        }

        // 4. Bottom Sticky Area: Selected Character & [ LOCK CHARACTER 🔒 ]
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                .border(1.dp, BorderGlow, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)),
            color = DarkSurfaceVariant.copy(alpha = 0.98f)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceHighlight)
                            .border(1.5.dp, ElectricPurple, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = chosenCharacter?.emoji ?: "❓", fontSize = 22.sp)
                    }

                    Column {
                        Text(
                            text = "Selected:",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                        Text(
                            text = chosenCharacter?.nameEn ?: "Select character",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                // Primary Action Button: [ LOCK CHARACTER 🔒 ]
                Button(
                    onClick = {
                        chosenCharacter?.let {
                            viewModel.lockSelectedCharacter(it)
                        }
                    },
                    enabled = chosenCharacter != null && !isLocked,
                    modifier = Modifier
                        .height(46.dp)
                        .testTag("btn_lock_character"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricPurple,
                        disabledContainerColor = DarkSurfaceHighlight
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Lock",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isLocked) "LOCKED" else "LOCK CHARACTER",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun PickCharacterCard(
    character: Character,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) ElectricPurple else BorderGlow,
                shape = RoundedCornerShape(14.dp)
            )
            .testTag("pick_char_${character.id}"),
        color = if (isSelected) ElectricPurple.copy(alpha = 0.15f) else DarkSurfaceVariant.copy(alpha = 0.7f)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceHighlight),
                contentAlignment = Alignment.Center
            ) {
                Text(text = character.emoji, fontSize = 26.sp)
                if (isSelected) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(ElectricPurple.copy(alpha = 0.3f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Selected",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = character.nameEn,
                color = TextPrimary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )

            Text(
                text = character.difficulty.name,
                color = when (character.difficulty) {
                    Difficulty.EASY -> EmeraldGreen
                    Difficulty.NORMAL -> CyberGold
                    Difficulty.HARD -> HotPink
                    Difficulty.EXPERT, Difficulty.IMPOSSIBLE -> ElectricPurple
                },
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
