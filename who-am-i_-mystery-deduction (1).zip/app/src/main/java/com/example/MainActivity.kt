package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.TopGameHeader
import com.example.ui.screens.ActiveGameScreen
import com.example.ui.screens.BanPhaseScreen
import com.example.ui.screens.CharacterPickScreen
import com.example.ui.screens.CollectionScreen
import com.example.ui.screens.CommunityPacksScreen
import com.example.ui.screens.FriendsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LeaderboardScreen
import com.example.ui.screens.LiveRoomsScreen
import com.example.ui.screens.MainPlayScreen
import com.example.ui.screens.MatchSummaryScreen
import com.example.ui.screens.PlayScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ShopScreen
import com.example.ui.screens.TournamentScreen
import com.example.ui.screens.VoiceRoomLobbyScreen
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.WhoAmITheme
import com.example.viewmodel.GameScreen
import com.example.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            WhoAmITheme {
                WhoAmIApp()
            }
        }
    }
}

@Composable
fun WhoAmIApp(
    viewModel: GameViewModel = viewModel()
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val friends by viewModel.friendsList.collectAsState()
    val friendRequests by viewModel.friendRequests.collectAsState()
    val gameInvites by viewModel.gameInvites.collectAsState()
    val currentLiveRoom by viewModel.currentLiveRoom.collectAsState()

    var showSocialModal by remember { mutableStateOf(false) }

    val showBottomBar = currentScreen !in listOf(
        GameScreen.BAN_PHASE,
        GameScreen.CHARACTER_PICK,
        GameScreen.MATCH_ACTIVE,
        GameScreen.MATCH_SUMMARY
    )

    val showTopHeader = showBottomBar

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBg)
            .statusBarsPadding()
            .navigationBarsPadding(),
        containerColor = DarkBg,
        topBar = {
            if (showTopHeader) {
                TopGameHeader(
                    username = profile.username,
                    level = 18,
                    xpProgress = 0.65f,
                    coins = profile.coins,
                    gems = 50,
                    avatar = profile.avatarEmoji,
                    onProfileClick = { viewModel.navigateTo(GameScreen.PROFILE) },
                    onNotificationClick = { viewModel.navigateTo(GameScreen.FRIENDS) },
                    hasUnreadNotification = friendRequests.isNotEmpty() || gameInvites.isNotEmpty()
                )
            }
        },
        bottomBar = {
            if (showBottomBar) {
                BottomGameNavBar(
                    currentScreen = currentScreen,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DarkBg)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen_transition"
            ) { screen ->
                when (screen) {
                    GameScreen.HOME -> HomeScreen(viewModel = viewModel)
                    GameScreen.PLAY -> PlayScreen(viewModel = viewModel)
                    GameScreen.FRIENDS -> FriendsScreen(viewModel = viewModel)
                    GameScreen.LOBBY_SETUP -> PlayScreen(viewModel = viewModel)
                    GameScreen.LIVE_ROOMS -> LiveRoomsScreen(viewModel = viewModel)
                    GameScreen.ROOM_LOBBY -> VoiceRoomLobbyScreen(viewModel = viewModel)
                    GameScreen.BAN_PHASE -> BanPhaseScreen(viewModel = viewModel)
                    GameScreen.CHARACTER_PICK -> CharacterPickScreen(viewModel = viewModel)
                    GameScreen.MATCH_ACTIVE -> ActiveGameScreen(viewModel = viewModel)
                    GameScreen.MATCH_SUMMARY -> MatchSummaryScreen(viewModel = viewModel)
                    GameScreen.TOURNAMENT -> TournamentScreen(viewModel = viewModel)
                    GameScreen.COLLECTION -> CollectionScreen(viewModel = viewModel)
                    GameScreen.COMMUNITY_PACKS -> CommunityPacksScreen(viewModel = viewModel)
                    GameScreen.LEADERBOARD -> LeaderboardScreen(viewModel = viewModel)
                    GameScreen.SHOP -> ShopScreen(viewModel = viewModel)
                    GameScreen.PROFILE -> ProfileScreen(viewModel = viewModel)
                }
            }
        }

        if (showSocialModal) {
            com.example.ui.components.SocialAndFriendsSheet(
                friends = friends,
                friendRequests = friendRequests,
                gameInvites = gameInvites,
                currentRoomId = currentLiveRoom?.id,
                onDismiss = { showSocialModal = false },
                onSendFriendRequest = { usernameOrId ->
                    viewModel.sendFriendRequest(usernameOrId)
                },
                onAcceptRequest = { reqId ->
                    viewModel.acceptFriendRequest(reqId)
                },
                onDeclineRequest = { reqId ->
                    viewModel.declineFriendRequest(reqId)
                },
                onInviteToRoom = { friendId ->
                    viewModel.sendGameInviteToFriend(friendId)
                },
                onAcceptInvite = { invite ->
                    viewModel.acceptGameInvite(invite)
                    showSocialModal = false
                },
                onDeclineInvite = { inviteId ->
                    viewModel.declineGameInvite(inviteId)
                },
                onRemoveFriend = { friendId ->
                    viewModel.removeFriend(friendId)
                }
            )
        }
    }
}

@Composable
fun BottomGameNavBar(
    currentScreen: GameScreen,
    onNavigate: (GameScreen) -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(20.dp),
        color = DarkSurfaceVariant.copy(alpha = 0.95f),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderGlow)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            NavBarItem(
                icon = "🏠",
                label = "HOME",
                isSelected = currentScreen == GameScreen.HOME,
                onClick = { onNavigate(GameScreen.HOME) },
                tag = "nav_home"
            )

            NavBarItem(
                icon = "⚡",
                label = "PLAY",
                isSelected = currentScreen == GameScreen.PLAY || currentScreen == GameScreen.LOBBY_SETUP || currentScreen == GameScreen.LIVE_ROOMS,
                onClick = { onNavigate(GameScreen.PLAY) },
                tag = "nav_play"
            )

            NavBarItem(
                icon = "👥",
                label = "FRIENDS",
                isSelected = currentScreen == GameScreen.FRIENDS,
                onClick = { onNavigate(GameScreen.FRIENDS) },
                tag = "nav_friends"
            )

            NavBarItem(
                icon = "🎴",
                label = "COLLECTION",
                isSelected = currentScreen == GameScreen.COLLECTION,
                onClick = { onNavigate(GameScreen.COLLECTION) },
                tag = "nav_collection"
            )

            NavBarItem(
                icon = "👤",
                label = "PROFILE",
                isSelected = currentScreen == GameScreen.PROFILE,
                onClick = { onNavigate(GameScreen.PROFILE) },
                tag = "nav_profile"
            )
        }
    }
}

@Composable
fun NavBarItem(
    icon: String,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .background(if (isSelected) ElectricPurple.copy(alpha = 0.15f) else Color.Transparent)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(tag)
    ) {
        Text(text = icon, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = if (isSelected) ElectricPurple else TextMuted,
            fontSize = 9.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
