package com.example.data

import com.example.model.Character
import com.example.model.CommunityPack
import com.example.model.DailyQuest
import com.example.model.Difficulty
import com.example.model.GameCategory
import com.example.model.ShopItem
import com.example.model.ShopItemType

object GameDataRepository {

    val allCharacters: List<Character> = listOf(
        // === ANIME ===
        Character(
            id = "naruto",
            name = "Naruto Uzumaki",
            nameAr = "ناروتو أوزوماكي",
            category = GameCategory.ANIME,
            difficulty = Difficulty.EASY,
            origin = "Naruto / Naruto Shippuden",
            hints = listOf("نينجا من قرية كونوها ولديه ثعلب ذو تسعة ذيول", "حلمه أن يصبح الهوكاغي وعبارته الشهيرة داتي بايو", "يستخدم الراسينغان ولديه شعر أصفر"),
            tags = listOf("Ninja", "Rasengan", "Hokage", "Kyuubi", "Konoha"),
            description = "البطل الأسطوري لقرية كونوها وحامل الكيوبي",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "luffy",
            name = "Monkey D. Luffy",
            nameAr = "مونكي دي لوفي",
            category = GameCategory.ANIME,
            difficulty = Difficulty.EASY,
            origin = "One Piece",
            hints = listOf("قائد طاقم قبعة القش وجسده مصنوع من المطاط", "حلمه أن يجد الكنز الأسطوري ويصبح ملك القراصنة", "يحب اللحم ويتحول إلى Gear 5"),
            tags = listOf("Pirate", "Straw Hat", "Gomu Gomu", "Gear 5", "Emperor"),
            description = "قبطان قراصنة قبعة القش وصاحب فاكهة المطاط الشمسية نيكا",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "zoro",
            name = "Roronoa Zoro",
            nameAr = "رورونوا زورو",
            category = GameCategory.ANIME,
            difficulty = Difficulty.EASY,
            origin = "One Piece",
            hints = listOf("سياف يستخدم ثلاثة سيوف ولديه شعر أخضر", "يعاني دائماً من ضياع الاتجاهات بشكل كوميدي", "نائب قبطان قبعة القش ومنافس ميهوك"),
            tags = listOf("Swordsman", "Three Swords", "Green Hair", "Pirate Hunter"),
            description = "أعظم سياف مستقبلي في ون بيس ومستخدم أسلوب السانتوريو",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "levi",
            name = "Levi Ackerman",
            nameAr = "ليفاي أكرمان",
            category = GameCategory.ANIME,
            difficulty = Difficulty.NORMAL,
            origin = "Attack on Titan",
            hints = listOf("أقوى جندي في البشرية وقائد فرقة الاستطلاع", "مهووس بالنظافة والترتيب ولديه بنية قصيرة", "يقاتل العمالقة بمهارة خارقة باستخدام معدات المناورة"),
            tags = listOf("Survey Corps", "Ackerman", "Titan Slayer", "Cleanliness"),
            description = "قائد فرقة العمليات الخاصة في فيلق الاستكشاف",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "goku",
            name = "Son Goku",
            nameAr = "سون غوكو",
            category = GameCategory.ANIME,
            difficulty = Difficulty.EASY,
            origin = "Dragon Ball",
            hints = listOf("محارب سايان مرسل إلى كوكب الأرض ويحب القتال والأكل", "يتحول إلى سوبر سايان ويطلق كاميهاميها", "حقق مستوى الغريزة الفائقة Ultra Instinct"),
            tags = listOf("Saiyan", "Kamehameha", "Super Saiyan", "Martial Arts"),
            description = "المحارب الأقوى في الكون وحامي كوكب الأرض",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "gojo",
            name = "Satoru Gojo",
            nameAr = "ساتورو غوجو",
            category = GameCategory.ANIME,
            difficulty = Difficulty.NORMAL,
            origin = "Jujutsu Kaisen",
            hints = listOf("أقوى ساحر جوجوتسو يرتدي عصابة سوداء على عينيه", "يمتلك العيون الست وتقنية اللانهائية ومجال الفراغ اللانهائي", "أستاذ في مدرسة طوكيو للسحر وشعره أبيض ناصع"),
            tags = listOf("Six Eyes", "Infinity", "Domain Expansion", "Sorcerer"),
            description = "أقوى مستعمل لعنة وجوجوتسو في العصر الحديث",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "eren",
            name = "Eren Yeager",
            nameAr = "إيرين ييغر",
            category = GameCategory.ANIME,
            difficulty = Difficulty.NORMAL,
            origin = "Attack on Titan",
            hints = listOf("أقسم على إبادة جميع العمالقة بعد تدمير مسقط رأسه شيغانشينا", "يمتلك العملاق المهاجم والعملاق المؤسس وأطلق الدك الأرضي", "شخصيته تحولت من متهور باحث عن الحرية إلى مدبر أعظم خطة"),
            tags = listOf("Attack Titan", "Founding Titan", "Rumbling", "Freedom"),
            description = "حامل قوة العملاق المؤسس وقائد عملية دك الأرض",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "madara",
            name = "Madara Uchiha",
            nameAr = "مادارا أوتشيها",
            category = GameCategory.ANIME,
            difficulty = Difficulty.HARD,
            origin = "Naruto Shippuden",
            hints = listOf("زعيم عشيرة الأوتشيها التاريخي ومؤسس كونوها مع هاشيراما", "أسقط نيزكين في حرب النينجا العظمى الرابعة بمفرده", "فعل التسوكويومي اللانهائية وأصبح جينشوريكي الجيوبي"),
            tags = listOf("Uchiha", "Sharingan", "Rinnegan", "Susanoo", "Legend"),
            description = "أسطورة الأوتشيها وأحد أعظم أشرار عالم الأنمي",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "killua",
            name = "Killua Zoldyck",
            nameAr = "كيلوا زولديك",
            category = GameCategory.ANIME,
            difficulty = Difficulty.HARD,
            origin = "Hunter x Hunter",
            hints = listOf("قاتل محترف من عائلة زولديك الشهيرة وشعره فضي", "صديق غون المقرب ويستخدم نين البرق ونظام Godspeed", "يحب حلوى الشوكولاتة واستخدم اليويو كسلاح"),
            tags = listOf("Zoldyck", "Lightning", "Assassin", "Hunter", "Godspeed"),
            description = "القاتل الموهوب ووريث عائلة زولديك للقتلة",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "tanjiro",
            name = "Tanjiro Kamado",
            nameAr = "تانجيرو كامادو",
            category = GameCategory.ANIME,
            difficulty = Difficulty.NORMAL,
            origin = "Demon Slayer",
            hints = listOf("صائد شياطين يحمل أخته نيزوكو في صندوق خشبي", "يتقن تنفس الماء ورقصة إله النار ولديه حاسة شم خارقة", "يرتدي أقراط الهانافودا ولديه ندبة على جبهته"),
            tags = listOf("Demon Slayer", "Sun Breathing", "Water Breathing", "Hanafuda"),
            description = "صائد الشياطين الطيب الساعي لإعادة أخته إنسانة",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "light",
            name = "Light Yagami",
            nameAr = "لايت ياغامي (كيرا)",
            category = GameCategory.ANIME,
            difficulty = Difficulty.HARD,
            origin = "Death Note",
            hints = listOf("طالب عبقري عثر على مذكرة موت وقتل المجرمين باسم كيرا", "خاض حرب ذكاء أسطورية ضد المحقق إل", "يرافقه الشينيغامي ريوك المحب للتفاح"),
            tags = listOf("Kira", "Death Note", "Genius", "Ryuk", "Justice"),
            description = "صاحب مذكرة الموت والملقب بإله العالم الجديد كيرا",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "itachi",
            name = "Itachi Uchiha",
            nameAr = "إيتاشي أوتشيها",
            category = GameCategory.ANIME,
            difficulty = Difficulty.EXPERT,
            origin = "Naruto Shippuden",
            hints = listOf("ضحى بسمعته وعشيرته من أجل حماية قرية كونوها وأخيه الصغير", "عبقري الغينجوتسو ومستخدم التسوكويومي والأماتيراسو والغربان", "عضو غامض في منظمة الأكاتسكي"),
            tags = listOf("Akatsuki", "Tsukuyomi", "Amaterasu", "Crow", "Hero"),
            description = "بطل الظلال المجهول وعبقري عشيرة الأوتشيها",
            isMale = true,
            usesWeaponsOrPowers = true
        ),

        // === FOOTBALL ===
        Character(
            id = "messi",
            name = "Lionel Messi",
            nameAr = "ليونيل ميسي",
            category = GameCategory.FOOTBALL,
            difficulty = Difficulty.EASY,
            origin = "Argentina / Barcelona / Inter Miami",
            hints = listOf("فاز بكأس العالم 2022 في قطر وحقق 8 كرات ذهبية", "الملقب بالبرغوث وأسطورة نادي برشلونة والأرجنتين", "يرتدي الرقم 10 ومشهور بالمراوغات الخارقة بالقدم اليسرى"),
            tags = listOf("Argentina", "GOAT", "Ballon d'Or", "World Cup", "Left Foot"),
            description = "أحد أعظم أساطير كرة القدم عبر التاريخ",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "ronaldo",
            name = "Cristiano Ronaldo",
            nameAr = "كريستيانو رونالدو",
            category = GameCategory.FOOTBALL,
            difficulty = Difficulty.EASY,
            origin = "Portugal / Real Madrid / Al Nassr",
            hints = listOf("الهداف التاريخي لكرة القدم وحائز على 5 كرات ذهبية", "الملقب بالدون وصاحب الاحتفال الشهير SIUUU", "تألق مع مانشستر يونايتد وريال مدريد والبرتغال والنصر"),
            tags = listOf("Portugal", "CR7", "Real Madrid", "Siu", "Top Scorer"),
            description = "الهداف التاريخي وأسطورة ريال مدريد والبرتغال",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "zidane",
            name = "Zinedine Zidane",
            nameAr = "زين الدين زيدان",
            category = GameCategory.FOOTBALL,
            difficulty = Difficulty.NORMAL,
            origin = "France / Real Madrid / Juventus",
            hints = listOf("قاد فرنسا للتتويج بكأس العالم 1998 بهدفين رأس في النهائي", "صاحب هدف الفولي التاريخي في نهائي دوري أبطال أوروبا 2002", "درب ريال مدريد وحقق معهم 3 ألقاب دوري أبطال أوروبا متتالية"),
            tags = listOf("France", "Zizou", "Volley 2002", "World Cup 1998", "Real Madrid"),
            description = "المايسترو الفرنسي وأحد أعظم صناع اللعب والمدربين",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "mbappe",
            name = "Kylian Mbappé",
            nameAr = "كيليان مبابي",
            category = GameCategory.FOOTBALL,
            difficulty = Difficulty.NORMAL,
            origin = "France / Real Madrid / PSG",
            hints = listOf("سجل هاتريك في نهائي كأس العالم 2022 وتوج بالبطولة 2018 وهو شاب", "يمتلك سرعة مرعبة وانتقل لريال مدريد في صيف 2024", "يرتدي الرقم 9 أو 10 ويلعب في خط الهجوم"),
            tags = listOf("Speed", "France", "Hat-trick Final", "Real Madrid"),
            description = "النجم الفرنسي الأسرع وأحد أبرز مهاجمي الجيل الحالي",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "ronaldinho",
            name = "Ronaldinho Gaúcho",
            nameAr = "رونالدينيو غاوتشو",
            category = GameCategory.FOOTBALL,
            difficulty = Difficulty.NORMAL,
            origin = "Brazil / Barcelona / AC Milan",
            hints = listOf("ساحر السامبا الذي صفق له جمهور سانتياغو برنابيو في الكلاسيكو", "فاز بكأس العالم 2002 ودوري الأبطال والكرة الذهبية بابتسامته الساحرة", "مشهور بمهارة الإيلاستيكو واللعب الاستعراضي الممتع"),
            tags = listOf("Brazil", "Joga Bonito", "Elastico", "Samba", "Barcelona"),
            description = "ساحر كرة القدم البرازيلي صاحب الابتسامة والمهارات الإعجازية",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "haaland",
            name = "Erling Haaland",
            nameAr = "إرلينغ هالاند",
            category = GameCategory.FOOTBALL,
            difficulty = Difficulty.NORMAL,
            origin = "Norway / Manchester City / Dortmund",
            hints = listOf("المهاجم النرويجي الملقب بالوحش أو الآلة التهديفية", "حطم الرقم القياسي للأهداف في الدوري الإنجليزي بموسمه الأول", "حقق الثلاثية التاريخية مع مانشستر سيتي"),
            tags = listOf("Norway", "Man City", "Goal Machine", "Cyborg"),
            description = "الهداف النرويجي الفتاك لمانشستر سيتي",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "salah",
            name = "Mohamed Salah",
            nameAr = "محمد صلاح",
            category = GameCategory.FOOTBALL,
            difficulty = Difficulty.EASY,
            origin = "Egypt / Liverpool",
            hints = listOf("الملك المصري والهداف التاريخي لليفربول في الدوري الإنجليزي", "قاد مصر لكأس العالم 2018 وفاز بدوري أبطال أوروبا والدوري الإنجليزي", "يرتدي الرقم 11 ويلعب كجناح أيمن ساحر"),
            tags = listOf("Egyptian King", "Liverpool", "Premier League", "Pharaoh"),
            description = "أيقونة كرة القدم المصرية والعربية وأسطورة نادي ليفربول",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "maradona",
            name = "Diego Maradona",
            nameAr = "دييغو مارادونا",
            category = GameCategory.FOOTBALL,
            difficulty = Difficulty.HARD,
            origin = "Argentina / Napoli / Boca Juniors",
            hints = listOf("قاد الأرجنتين للفوز بكأس العالم 1986 بهدف القرن وهدف يد الله", "أسطورة نادي نابولي الإيطالي التاريخية", "يعتبره الكثيرون الموهبة الفطرية الأعظم في تاريخ الكرة"),
            tags = listOf("Argentina", "Napoli", "Goal of the Century", "Legend"),
            description = "الأسطورة الخالدة لكرة القدم الأرجنتينية والعالمية",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),

        // === VIDEO GAMES ===
        Character(
            id = "kratos",
            name = "Kratos",
            nameAr = "كراتوس (إله الحرب)",
            category = GameCategory.VIDEO_GAMES,
            difficulty = Difficulty.EASY,
            origin = "God of War",
            hints = listOf("شبح سبارتا الذي يحمل شفرات الفوضى وفأس ليفياثان", "ينادي ابنه دائماً بـ BOY وخاض حروباً ضد الآلهة الإغريقية والنوردية", "يحمل وشماً أحمر على جسده ولحية بيضاء مميزة في الأجزاء الحديثة"),
            tags = listOf("Ghost of Sparta", "Leviathan Axe", "Blades of Chaos", "Boy"),
            description = "شبح سبارتا وإله الحرب في سلسلة بلايستيشن الشهيرة",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "mario",
            name = "Super Mario",
            nameAr = "سوبر ماريو",
            category = GameCategory.VIDEO_GAMES,
            difficulty = Difficulty.EASY,
            origin = "Nintendo / Super Mario Bros",
            hints = listOf("سباك إيطالي يرتدي قبعة حمراء وزي أزرق ولديه شارب كثيف", "يقفز على السلاحف ويأكل الفطر لإنقاذ الأميرة بيتش من باوزر", "الأيقونة الرسمية لشركة نينتندو وشقيقه هو لويجي"),
            tags = listOf("Nintendo", "Plumber", "Mushroom Kingdom", "Peach", "Bowser"),
            description = "أشهر شخصية ألعاب فيديو في التاريخ وأيقونة نينتندو",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "geralt",
            name = "Geralt of Rivia",
            nameAr = "جيرالت من ريفيا (الويتشر)",
            category = GameCategory.VIDEO_GAMES,
            difficulty = Difficulty.NORMAL,
            origin = "The Witcher",
            hints = listOf("صياد وحوش متحول لديه شعر أبيض وسيفان (فضة وحديد)", "الملقب بالذئب الأبيض ويبحث عن ابنته بالتبني سيري", "يستخدم علامات السحر (Aard, Igni, Quen) ويتناول الجرعات"),
            tags = listOf("White Wolf", "Witcher", "Silver Sword", "Monsters", "Ciri"),
            description = "صياد الوحوش المتجول من مدرسة الذئب في عالم الويتشر",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "link",
            name = "Link",
            nameAr = "لينك (أسطورة زيلدا)",
            category = GameCategory.VIDEO_GAMES,
            difficulty = Difficulty.NORMAL,
            origin = "The Legend of Zelda",
            hints = listOf("بطل هايرول الصامت الذي يحمل السيف الرئيسي Master Sword ودرع هايلين", "يرتدي رداءً أخضر (أو أزرق في Breath of the Wild) ويحمل شعلة الشجاعة من الترايفورس", "كثيراً ما يخلط الناس بين اسمه واسم الأميرة زيلدا"),
            tags = listOf("Zelda", "Master Sword", "Hyrule", "Triforce", "Courage"),
            description = "بطل الزمن وحامي مملكة هايرول في سلسلة زيلدا",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "arthur_morgan",
            name = "Arthur Morgan",
            nameAr = "آرثر مورغان",
            category = GameCategory.VIDEO_GAMES,
            difficulty = Difficulty.HARD,
            origin = "Red Dead Redemption 2",
            hints = listOf("راعي بقر وعضو رئيسي في عصابة داتش فان دير ليند في الغرب الأمريكي", "يعاني من مرض السل في أواخر القصة ويملك مسدس وسلاح Dead Eye", "مشهور بعبارات مثل Outlaws for Life و I gave you all I had"),
            tags = listOf("Cowboy", "RDR2", "Van der Linde", "Western", "Dead Eye"),
            description = "بطل الغرب الأمريكي في تحفة روكستار Red Dead Redemption 2",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "sonic",
            name = "Sonic the Hedgehog",
            nameAr = "سونيك القنفذ",
            category = GameCategory.VIDEO_GAMES,
            difficulty = Difficulty.EASY,
            origin = "SEGA / Sonic",
            hints = listOf("قنفذ أزرق فائق السرعة يجمع الحلقات الذهبية ويقاتل الدكتور إيغمان", "يتحول إلى Super Sonic عند جمع زمردات الفوضى السبع", "الأيقونة الرسمية لشركة سيجا ويحب الشيليدوغ"),
            tags = listOf("Speed", "Blue Blur", "SEGA", "Chaos Emeralds", "Rings"),
            description = "القنفذ الأزرق الأسرع في العالم وأيقونة شركة سيجا",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "master_chief",
            name = "Master Chief (John-117)",
            nameAr = "ماستر شيف",
            category = GameCategory.VIDEO_GAMES,
            difficulty = Difficulty.NORMAL,
            origin = "Halo / Xbox",
            hints = listOf("جندي سبارتان معدل وراثياً يرتدي خوذة ودرع Mjolnir الأخضر", "يرافقه الذكاء الاصطناعي كورتانا في حربه ضد الكوفننت والفلود", "الرمز الأبرز لمنصة إكس بوكس"),
            tags = listOf("Spartan", "Cortana", "Halo", "Xbox", "Armor"),
            description = "البطل الخارق وسيد المعارك في سلسلة هالو",
            isMale = true,
            usesWeaponsOrPowers = true
        ),

        // === SUPERHEROES ===
        Character(
            id = "batman",
            name = "Batman (Bruce Wayne)",
            nameAr = "باتمان (بروس واين)",
            category = GameCategory.SUPERHEROES,
            difficulty = Difficulty.EASY,
            origin = "DC Comics",
            hints = listOf("فارس الظلام الملياردير الذي يحمي مدينة غوثام بدون قوى خارقة", "يستخدم أدوات متطورة والباتموبيل ومساعده الخادم ألفريد", "عدوه اللدود هو الجوكر وأقسم على محاربة الجريمة بعد مقتل والديه"),
            tags = listOf("Dark Knight", "Gotham", "Batarang", "Alfred", "Joker"),
            description = "فارس الظلام المحقق وحامي مدينة غوثام",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "spiderman",
            name = "Spider-Man (Peter Parker)",
            nameAr = "سبايدرمان (بيتر باركر)",
            category = GameCategory.SUPERHEROES,
            difficulty = Difficulty.EASY,
            origin = "Marvel Comics",
            hints = listOf("عضه عنكبوت مشع فاكتسب قدرة تسلق الجدران وحاسة الخطر", "عبارته الشهيرة: مع القوة العظيمة تأتي مسؤولية عظيمة", "يطلق الشباك ويتأرجح بين ناطحات سحاب نيويورك"),
            tags = listOf("Web Slinger", "Wall Crawler", "Uncle Ben", "Marvel", "Queens"),
            description = "البطل الودود في الحي ورمز مارفل الأشهر",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "ironman",
            name = "Iron Man (Tony Stark)",
            nameAr = "آيرون مان (توني ستارك)",
            category = GameCategory.SUPERHEROES,
            difficulty = Difficulty.EASY,
            origin = "Marvel / Avengers",
            hints = listOf("ملياردير عبقري ومخترع بنى بدلة درع مدرعة بمفاعل قوسي في صدره", "قال جملته الشهيرة: I am Iron Man وضحي بحياته ضد ثانوس", "عضو مؤسس في فرقة المنتقمين Avengers"),
            tags = listOf("Tony Stark", "Arc Reactor", "Avengers", "Jarvis", "Nanotech"),
            description = "العبقري المبتكر وقائد ثورة عالم مارفل السينمائي",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "superman",
            name = "Superman (Clark Kent)",
            nameAr = "سوبرمان (كال-إل)",
            category = GameCategory.SUPERHEROES,
            difficulty = Difficulty.EASY,
            origin = "DC Comics",
            hints = listOf("الناجي الأخير من كوكب كريبتون ويعمل كصحفي في صحيفة ديلي بلانيت", "يستمد قوته الخارقة والطيران من الشمس الصفراء ونقطة ضعفه الكريبتونايت", "يرتدي عباءة حمراء وشعار حرف S على صدره"),
            tags = listOf("Krypton", "Daily Planet", "Flight", "Kryptonite", "Man of Steel"),
            description = "رجل الفولاذ وأول وأعظم بطل خارق في تاريخ القصص المصورة",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "joker",
            name = "The Joker",
            nameAr = "الجوكر",
            category = GameCategory.SUPERHEROES,
            difficulty = Difficulty.NORMAL,
            origin = "DC Comics",
            hints = listOf("أمير الجريمة المهرج وشعره أخضر ووجهه مطلي بالأبيض وابتسامته مخيفة", "العدو الأزلي لباتمان ويمثل الفوضى المطلقة بدون هوية حقيقية ثابتة", "عبارته الشهيرة: Why so serious?"),
            tags = listOf("Clown Prince", "Chaos", "Gotham", "Why So Serious", "Batman"),
            description = "أشهر شرير في تاريخ الكوميكس وأمير الفوضى في غوثام",
            isMale = true,
            usesWeaponsOrPowers = true
        ),

        // === CARTOONS ===
        Character(
            id = "spongebob",
            name = "SpongeBob SquarePants",
            nameAr = "سبونج بوب سكوير بانتس",
            category = GameCategory.CARTOONS,
            difficulty = Difficulty.EASY,
            origin = "Nickelodeon",
            hints = listOf("إسفنجة صفراء تعيش في ثمرة أناناس تحت البحر في قاع الهامور", "يعمل طاهياً لبرغر سلطع برغر في مقرمشات سلطع ويحب صيد قناديل البحر", "صديقه المقرب بسيط نجم وحيوانه الأليف سريع الحلزون"),
            tags = listOf("Bikini Bottom", "Pineapple", "Krabby Patty", "Patrick", "Yellow"),
            description = "الإسفنجة المرحة التي تسكن قاع الهامور",
            isMale = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "tom_and_jerry",
            name = "Tom the Cat",
            nameAr = "القط توم (توم وجيري)",
            category = GameCategory.CARTOONS,
            difficulty = Difficulty.EASY,
            origin = "MGM / Hanna-Barbera",
            hints = listOf("قط رمادي يقضي حياته في مطاردة فأر بني ذكي داخل المنزل", "يتعرض دائماً لمواقف كوميدية وانفجارات وفخاخ ترتد عليه", "صاحب أطول وأشهر مطاردة كرتونية في التاريخ"),
            tags = listOf("Cat", "Chase", "Jerry", "Cartoon Classic", "Slapstick"),
            description = "القط المشاكس في أشهر ثنائي رسوم متحركة في العالم",
            isMale = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "rick_sanchez",
            name = "Rick Sanchez",
            nameAr = "ريك سانشيز (ريك ومورتي)",
            category = GameCategory.CARTOONS,
            difficulty = Difficulty.HARD,
            origin = "Rick and Morty",
            hints = listOf("عالم عبقري مجنون وعدمي يسافر عبر الأبعاد باستخدام مسدس البوابات الأخضر", "يصطحب حفيده مورتي في مغامرات فضائية فوضوية وشعره أزرق شائك", "عبارته الشهيرة: Wubba Lubba Dub-Dub"),
            tags = listOf("Portal Gun", "Genius", "Multiverse", "Morty", "Pickle Rick"),
            description = "العالم الأذكى في الكون المتعدد وصاحب مسدس البوابات",
            isMale = true,
            usesWeaponsOrPowers = true
        ),

        // === MOVIES & SERIES ===
        Character(
            id = "walter_white",
            name = "Walter White (Heisenberg)",
            nameAr = "والتر وايت (هايزنبرغ)",
            category = GameCategory.MOVIES_SERIES,
            difficulty = Difficulty.NORMAL,
            origin = "Breaking Bad",
            hints = listOf("مدرس كيمياء مصاب بالسرطان تحول إلى إمبراطور ميث أزرق", "يرتدي قبعة سوداء ونظارات واستخدم الاسم المستعار هايزنبرغ", "عبارته الشهيرة: I am the one who knocks و Say my name"),
            tags = listOf("Chemistry", "Heisenberg", "Blue Sky", "Jesse Pinkman", "Albuquerque"),
            description = "مدرس الكيمياء العبقري وبطل سلسلة بريكينغ باد",
            isMale = true,
            isRealPerson = false,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "jack_sparrow",
            name = "Captain Jack Sparrow",
            nameAr = "الكابتن جاك سبارو",
            category = GameCategory.MOVIES_SERIES,
            difficulty = Difficulty.NORMAL,
            origin = "Pirates of the Caribbean",
            hints = listOf("قبطان قرصان غريب الأطوار يقود سفينة اللؤلؤة السوداء ولديه بوصلة سحرية", "يمشي بطريقة مترنحة ومشهور بذكائه الخادع وحبه للروم", "دائماً يصرخ: You will always remember this as the day you almost caught Captain Jack Sparrow"),
            tags = listOf("Black Pearl", "Compass", "Pirate", "Johnny Depp", "Rum"),
            description = "قبطان سفينة اللؤلؤة السوداء وأشهر قرصان سينمائي",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "harry_potter",
            name = "Harry Potter",
            nameAr = "هاري بوتر",
            category = GameCategory.MOVIES_SERIES,
            difficulty = Difficulty.EASY,
            origin = "Harry Potter / Hogwarts",
            hints = listOf("الساحر الفتى الذي نجا من لورد فولدمورت ولديه ندبة برق على جبينه", "طالب في مدرسة هوغوورتس في منزل غريفندور ولديه نظارات مستديرة", "عصاه السحرية مصنوعة من خشب البهش وتعاويذه المفضلة Expelliarmus"),
            tags = listOf("Hogwarts", "Gryffindor", "Lightning Scar", "Wand", "Voldemort"),
            description = "الساحر المختار وبطل عالم السحر وهوغوورتس",
            isMale = true,
            usesWeaponsOrPowers = true
        ),

        // === HISTORICAL FIGURES ===
        Character(
            id = "einstein",
            name = "Albert Einstein",
            nameAr = "ألبرت أينشتاين",
            category = GameCategory.HISTORICAL,
            difficulty = Difficulty.EASY,
            origin = "Physics / Germany",
            hints = listOf("عالم فيزياء عبقري صاغ النظرية النسبية ومعادلة الطاقة E=mc²", "مشهور بشعره الأبيض الكثيف وشاربه ولسانه في الصورة التاريخية", "فاز بجائزة نوبل في الفيزياء عام 1921 لتفسير التأثير الكهروضوئي"),
            tags = listOf("Relativity", "Physics", "E=mc2", "Nobel Prize", "Genius"),
            description = "أعظم عالم فيزياء نظري في القرن العشرين ومؤسس النسبية",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "da_vinci",
            name = "Leonardo da Vinci",
            nameAr = "ليوناردو دافنشي",
            category = GameCategory.HISTORICAL,
            difficulty = Difficulty.NORMAL,
            origin = "Renaissance / Italy",
            hints = listOf("عبقري عصر النهضة الإيطالي الذي رسم لوحة الموناليزا والعشاء الأخير", "كان رساماً ومهندساً ومخترعاً صمم نماذج مبكرة للطائرات والمدافع", "كتب مذكراته بطريقة المرآة العكسية"),
            tags = listOf("Mona Lisa", "Renaissance", "Inventor", "Last Supper", "Italy"),
            description = "أيقونة عصر النهضة الإيطالية ورسام لوحة الموناليزا",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "alexander",
            name = "Alexander the Great",
            nameAr = "الإسكندر الأكبر",
            category = GameCategory.HISTORICAL,
            difficulty = Difficulty.HARD,
            origin = "Macedonia / Ancient Greece",
            hints = listOf("ملك مقدونيا وتلميذ أرسطو الذي أنشأ واحدة من أكبر الإمبراطوريات في التاريخ القديم", "لم يهزم في أي معركة وقهر الإمبراطورية الفارسية ووصل للهند قبل سن الثلاثين", "أسس مدينة الإسكندرية في مصر"),
            tags = listOf("Macedon", "Empire", "Conqueror", "Aristotle", "Alexandria"),
            description = "الفاتح التاريخي وقائد الإمبراطورية المقدونية القديمة",
            isMale = true,
            isRealPerson = true,
            usesWeaponsOrPowers = true
        ),

        // === CREATURES & MYTH ===
        Character(
            id = "godzilla",
            name = "Godzilla",
            nameAr = "غودزيلا (ملك الوحوش)",
            category = GameCategory.CREATURES,
            difficulty = Difficulty.NORMAL,
            origin = "Kaiju / Japan",
            hints = listOf("وحش كايجو عملاق مستيقظ من الإشعاع النووي يطلق نفساً ذرياً أزرق", "ملك الوحوش الذي يقاتل كونغ وغيدورا في المحيط الهادئ والمدن", "صاحب الزئير الأيقوني الذي يهز ناطحات السحاب"),
            tags = listOf("Kaiju", "Atomic Breath", "King of Monsters", "Giant Lizard"),
            description = "ملك الوحوش الأسطوري وحامي كوكب الأرض الخارق",
            isMale = true,
            usesWeaponsOrPowers = true
        ),
        Character(
            id = "pikachu",
            name = "Pikachu",
            nameAr = "بيكاتشو",
            category = GameCategory.CREATURES,
            difficulty = Difficulty.EASY,
            origin = "Pokémon",
            hints = listOf("فأر كهربائي أصفر لديه وجنتان حمراوان وذيل على شكل صاعقة برق", "الشريك الأوفى للمدرب آش كيتشوم وعبارته الشهيرة Pika Pika!", "الأيقونة الرسمية العالمية للامتياز الترفيهي بوكيمون"),
            tags = listOf("Electric", "Thunderbolt", "Ash", "Pokemon", "Yellow"),
            description = "البوكيمون الكهربائي الأشهر في العالم ورفيق آش الدائم",
            isMale = true,
            usesWeaponsOrPowers = true
        ),

        // === CARS ===
        Character(
            id = "ferrari_enzo",
            name = "Ferrari Enzo",
            nameAr = "فيراري إنزو",
            category = GameCategory.CARS,
            difficulty = Difficulty.NORMAL,
            origin = "Italy / Ferrari",
            hints = listOf("سيارة خارقة إيطالية بمحرك V12 طبيعي التنفس سميت تيمناً بمؤسس الشركة", "صُنعت بتقنيات الفورمولا 1 وتفتح أبوابها إلى الأعلى مثل الفراشة", "أنتجت 399 نسخة فقط بلونها الأحمر الأيقوني روسو كورسا"),
            tags = listOf("V12", "Hypercar", "Maranello", "Rosso Corsa", "F1"),
            description = "السيارة الخارقة الأيقونية التي حملت اسم مؤسس فيراري",
            isMale = false,
            isRealPerson = false,
            usesWeaponsOrPowers = false
        ),
        Character(
            id = "bugatti_chiron",
            name = "Bugatti Chiron",
            nameAr = "بوغاتي شيرون",
            category = GameCategory.CARS,
            difficulty = Difficulty.NORMAL,
            origin = "France / Bugatti",
            hints = listOf("وحش السرعة بمحرك W16 رباعي التوربو بقوة 1500 حصان", "تكسر سرعة 420 كم/ساعة ومصنوعة من ألياف الكربون الفاخرة", "خليفة بوغاتي فيرون الأسطورية"),
            tags = listOf("W16", "Quad Turbo", "Speed Record", "Hypercar"),
            description = "أيقونة السرعة الفائقة والفخامة الفرنسية بمحرك W16",
            isMale = false,
            isRealPerson = false,
            usesWeaponsOrPowers = false
        )
    )

    val presetQuestions: List<String> = listOf(
        "هل الشخصية ذكر؟",
        "هل الشخصية حقيقية من عالمنا الواقعي؟",
        "هل تستخدم أسلحة أو قوى خارقة / سحر؟",
        "هل تنتمي إلى عالم الأنمي أو الكرتون؟",
        "هل تلعب في خط الهجوم أو حصلت على جوائز كبرى؟",
        "هل الشخصية شريرة أو مضادة للبطل؟",
        "هل ترتدي زياً مميزاً (قناع، قبعة، درع)؟",
        "هل الشخصية من أصل ياباني أو أمريكي؟",
        "هل تمتلك سرعة خارقة أو مهارات بدنية أسطورية؟",
        "هل ظهرت في لعبة فيديو شهيرة كبطل رئيسي؟",
        "هل ماتت أو انتهت قصتها في العمل؟",
        "هل يرافقها رفيق أو حيوان أليف مميز؟"
    )

    val communityPacks: List<CommunityPack> = listOf(
        CommunityPack(
            id = "pack_naruto_legends",
            title = "🔥 أصعب شخصيات Naruto & Akatsuki",
            author = "Nagato_Shinobi",
            category = GameCategory.ANIME,
            characterCount = 32,
            likes = 1420,
            rating = 4.9f,
            difficulty = Difficulty.HARD,
            description = "حزمة مخصصة للمتعمقين في شينوبي كونوها والأكاتسكي القديمة!",
            sampleCharacters = listOf("Madara", "Itachi", "Pain", "Jiraiya", "Minato")
        ),
        CommunityPack(
            id = "pack_football_classics",
            title = "⚽ Football Golden Era & Legends",
            author = "Zizou_Cap",
            category = GameCategory.FOOTBALL,
            characterCount = 40,
            likes = 2890,
            rating = 4.8f,
            difficulty = Difficulty.NORMAL,
            description = "أساطير كرة القدم من السبعينات حتى جيل ميسي ورونالدو الذهبي",
            sampleCharacters = listOf("Maradona", "Pele", "Zidane", "Ronaldo R9", "Cruyff")
        ),
        CommunityPack(
            id = "pack_gaming_bosses",
            title = "🎮 Iconic Gaming Bosses & Heroes",
            author = "SoulsKnight",
            category = GameCategory.VIDEO_GAMES,
            characterCount = 28,
            likes = 980,
            rating = 4.7f,
            difficulty = Difficulty.EXPERT,
            description = "زعماء الألعاب الأكثر رعباً وصعوبة وأبطال الـ RPG التاريخيين",
            sampleCharacters = listOf("Malenia", "Sephiroth", "Kratos", "Vergil", "Bowser")
        ),
        CommunityPack(
            id = "pack_classic_cartoons",
            title = "🐭 Spacetoon & 90s Classic Cartoons",
            author = "NostalgiaGamer",
            category = GameCategory.CARTOONS,
            characterCount = 35,
            likes = 3120,
            rating = 5.0f,
            difficulty = Difficulty.EASY,
            description = "أبطال كرتون زمان وذكريات سبيستون الخالدة",
            sampleCharacters = listOf("Captain Tsubasa", "Conan", "Grendizer", "Tom", "SpongeBob")
        )
    )

    val dailyQuests: List<DailyQuest> = listOf(
        DailyQuest(
            id = "quest_guess_5",
            titleAr = "🎯 خمن 5 شخصيات بنجاح في أي وضع",
            titleEn = "Correctly guess 5 secret characters",
            current = 2,
            target = 5,
            rewardCoins = 150,
            rewardXp = 300
        ),
        DailyQuest(
            id = "quest_win_3_ranked",
            titleAr = "⚡ حقق الفوز في 3 مباريات مصنفة (Ranked)",
            titleEn = "Win 3 Ranked Matches",
            current = 1,
            target = 3,
            rewardCoins = 250,
            rewardXp = 500
        ),
        DailyQuest(
            id = "quest_no_hints",
            titleAr = "🧠 اربح مباراة كاملة بدون استخدام أي تلميح (Hint)",
            titleEn = "Win without using hints",
            current = 0,
            target = 1,
            rewardCoins = 200,
            rewardXp = 400
        ),
        DailyQuest(
            id = "quest_fast_guess",
            titleAr = "⚡ خمن شخصية في أقل من 15 ثانية",
            titleEn = "Guess a character in under 15 seconds",
            current = 1,
            target = 1,
            rewardCoins = 180,
            rewardXp = 350
        ),
        DailyQuest(
            id = "quest_streak_5",
            titleAr = "🔥 حقق Win Streak متتالي من 3 انتصارات",
            titleEn = "Achieve a 3-game win streak",
            current = 2,
            target = 3,
            rewardCoins = 300,
            rewardXp = 600
        )
    )

    val shopCatalog: List<ShopItem> = listOf(
        ShopItem("frame_cyber_neon", "إطار النيون السيبراني", ShopItemType.FRAME, 200, "💠", isPurchased = true, isEquipped = true),
        ShopItem("frame_golden_champion", "إطار بطل البطولات الذهبي", ShopItemType.FRAME, 600, "👑"),
        ShopItem("frame_dragon_fire", "إطار لهب التنين الأسطوري", ShopItemType.FRAME, 450, "🔥"),
        ShopItem("avatar_detective_fox", "ثعلب التحري الذكي", ShopItemType.AVATAR, 150, "🦊", isPurchased = true, isEquipped = true),
        ShopItem("avatar_cyber_ninja", "النينجا السيبراني", ShopItemType.AVATAR, 350, "🥷"),
        ShopItem("avatar_cosmic_wizard", "ساحر المجرات", ShopItemType.AVATAR, 500, "🧙‍♂️"),
        ShopItem("title_grandmaster_mind", "🧠 العقل المدبر (Mastermind)", ShopItemType.TITLE, 300, "🧠 Mastermind", isPurchased = true, isEquipped = true),
        ShopItem("title_speed_demon", "⚡ شيطان السرعة (Speed Demon)", ShopItemType.TITLE, 400, "⚡ Speed Demon"),
        ShopItem("title_anime_encyclopedia", "🎌 موسوعة الأنمي (Anime Sage)", ShopItemType.TITLE, 500, "🎌 Anime Sage"),
        ShopItem("effect_lightning_strike", "صاعقة النصر البرقية", ShopItemType.EFFECT, 400, "⚡"),
        ShopItem("effect_golden_confetti", "احتفال النجوم الذهبية", ShopItemType.EFFECT, 300, "✨"),
        ShopItem("theme_neon_matrix", "لوحة الماتريكس النيون", ShopItemType.BOARD_THEME, 500, "🟢")
    )
}
