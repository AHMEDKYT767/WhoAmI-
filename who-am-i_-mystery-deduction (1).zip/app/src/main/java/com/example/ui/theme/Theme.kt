package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = Color(0xFF00363A),
    primaryContainer = RadiantViolet,
    onPrimaryContainer = Color(0xFFEADBFF),
    secondary = NeonPurple,
    onSecondary = Color.White,
    secondaryContainer = DarkSurfaceHighlight,
    onSecondaryContainer = Color(0xFFF7F4FF),
    tertiary = CyberGold,
    onTertiary = Color(0xFF432C00),
    tertiaryContainer = Color(0xFF5D3E00),
    onTertiaryContainer = Color(0xFFFFDEA3),
    background = DarkBg,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = BorderGlow,
    outlineVariant = Color(0xFF4A3B66),
    error = DangerRed,
    onError = Color.White
)

@Composable
fun WhoAmITheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
