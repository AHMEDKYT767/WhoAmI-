package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AuthAccountDialog
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyanBlue
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.GameScreen
import com.example.viewmodel.GameViewModel

@Composable
fun ProfileScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.profile.collectAsState()
    val isUserLoggedIn by viewModel.isUserLoggedIn.collectAsState()

    var showAuthModal by remember { mutableStateOf(false) }
    var isEditingName by remember { mutableStateOf(false) }
    var editedName by remember { mutableStateOf(profile.username) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Clean Centered Profile Header
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, BorderGlow, RoundedCornerShape(20.dp)),
                color = DarkSurfaceVariant.copy(alpha = 0.85f)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Large Avatar
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(ElectricPurple, CyanBlue))
                            )
                            .border(2.dp, CyberGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = profile.avatarEmoji, fontSize = 42.sp)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Username & Tag
                    if (isEditingName) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth(0.8f)
                        ) {
                            OutlinedTextField(
                                value = editedName,
                                onValueChange = { editedName = it },
                                singleLine = true,
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedContainerColor = DarkSurface,
                                    unfocusedContainerColor = DarkSurface,
                                    focusedBorderColor = ElectricPurple,
                                    unfocusedBorderColor = BorderGlow,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary
                                )
                            )
                            Button(
                                onClick = {
                                    viewModel.updateUsername(editedName)
                                    isEditingName = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple)
                            ) {
                                Text("SAVE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Text(
                            text = profile.username,
                            color = TextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "@${profile.username.lowercase().replace(" ", "_")}",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Diamond 2,140 RP Pill
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurfaceHighlight,
                        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "💎", fontSize = 14.sp)
                            Text(
                                text = "${profile.rankTier.titleEn} Tier",
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "•  ${profile.rankPoints} RP",
                                color = CyanBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // XP Progress Bar
                    Column(
                        modifier = Modifier.fillMaxWidth(0.85f),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Level 18",
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "650 / 1000 XP",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(DarkSurfaceHighlight)
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxHeight()
                                    .fillMaxWidth(0.65f)
                                    .background(
                                        Brush.horizontalGradient(listOf(ElectricPurple, CyanBlue))
                                    )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // [ EDIT PROFILE ] & Cloud status buttons
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = DarkSurfaceHighlight,
                            border = androidx.compose.foundation.BorderStroke(1.dp, BorderGlow),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { isEditingName = !isEditingName }
                                .testTag("btn_edit_profile")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = "EDIT PROFILE",
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isUserLoggedIn) EmeraldGreen.copy(alpha = 0.15f) else DarkSurfaceHighlight,
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isUserLoggedIn) EmeraldGreen.copy(alpha = 0.5f) else BorderGlow
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { showAuthModal = true }
                                .testTag("btn_cloud_sync")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CloudDone,
                                    contentDescription = "Cloud",
                                    tint = if (isUserLoggedIn) EmeraldGreen else TextSecondary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = if (isUserLoggedIn) "CLOUD SYNCED" else "SYNC ACCOUNT",
                                    color = if (isUserLoggedIn) EmeraldGreen else TextSecondary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Compact Statistics Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                CompactStatCard(
                    number = "${profile.totalMatches}",
                    label = "Games",
                    color = CyanBlue,
                    modifier = Modifier.weight(1f)
                )
                CompactStatCard(
                    number = "${profile.totalWins}",
                    label = "Wins",
                    color = EmeraldGreen,
                    modifier = Modifier.weight(1f)
                )
                val winRate = if (profile.totalMatches > 0) (profile.totalWins * 100 / profile.totalMatches) else 82
                CompactStatCard(
                    number = "$winRate%",
                    label = "Accuracy",
                    color = CyberGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 3. Compact Sections: Achievements, Collection, Win Streak, Statistics
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Section: Achievements
                ProfileSectionCard(
                    icon = "🏆",
                    title = "Achievements",
                    subtitle = "18 / 25 Unlocked",
                    tag = "achievements_card",
                    onClick = {}
                )

                // Section: Collection
                ProfileSectionCard(
                    icon = "🎴",
                    title = "Collection",
                    subtitle = "73 / 250 Characters",
                    tag = "collection_card",
                    onClick = { viewModel.navigateTo(GameScreen.COLLECTION) }
                )

                // Section: Win Streak
                ProfileSectionCard(
                    icon = "🔥",
                    title = "Win Streak",
                    subtitle = "${profile.currentStreak} Matches (Best: ${profile.bestStreak})",
                    tag = "streak_card",
                    onClick = {}
                )

                // Section: Statistics
                ProfileSectionCard(
                    icon = "📊",
                    title = "Statistics",
                    subtitle = "Fastest guess: 14s • Favorite: Anime",
                    tag = "stats_card",
                    onClick = {}
                )
            }
        }
    }

    if (showAuthModal) {
        AuthAccountDialog(
            profile = profile,
            isLoggedIn = isUserLoggedIn,
            onSignInEmail = { email, pass ->
                viewModel.signInWithEmail(email, pass)
                showAuthModal = false
            },
            onSignUpEmail = { email, pass, username ->
                viewModel.signUpWithEmail(email, pass, username)
                showAuthModal = false
            },
            onSignOut = {
                viewModel.signOutUser()
                showAuthModal = false
            },
            onDismiss = { showAuthModal = false }
        )
    }
}

@Composable
private fun CompactStatCard(
    number: String,
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, BorderGlow, RoundedCornerShape(14.dp)),
        color = DarkSurfaceVariant.copy(alpha = 0.75f)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = number,
                color = color,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun ProfileSectionCard(
    icon: String,
    title: String,
    subtitle: String,
    tag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .border(1.dp, BorderGlow, RoundedCornerShape(14.dp))
            .testTag(tag),
        color = DarkSurfaceVariant.copy(alpha = 0.7f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(text = icon, fontSize = 20.sp)
                Column {
                    Text(
                        text = title,
                        color = TextPrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = subtitle,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Text(
                text = "›",
                color = TextMuted,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
