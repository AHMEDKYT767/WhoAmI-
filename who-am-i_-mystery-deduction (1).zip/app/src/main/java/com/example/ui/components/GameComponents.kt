package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AnswerType
import com.example.model.Character
import com.example.model.ClueLogItem
import com.example.model.Player
import com.example.model.PowerCardType
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyanBlue
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@Composable
fun TopGameHeader(
    username: String,
    level: Int = 18,
    xpProgress: Float = 0.65f,
    coins: Int,
    gems: Int = 50,
    avatar: String,
    onProfileClick: () -> Unit,
    onNotificationClick: () -> Unit = {},
    hasUnreadNotification: Boolean = false,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        shape = RoundedCornerShape(18.dp),
        color = DarkSurfaceVariant.copy(alpha = 0.95f),
        border = androidx.compose.foundation.BorderStroke(1.dp, BorderGlow)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Circular avatar + Username + Level + Small XP progress bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onProfileClick() }
                    .padding(2.dp)
                    .testTag("header_profile_pill")
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceHighlight)
                        .border(1.5.dp, ElectricPurple, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = avatar, fontSize = 18.sp)
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = username,
                            color = TextPrimary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Lv.$level",
                            color = ElectricPurple,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(3.dp))
                    // Small XP progress bar
                    Box(
                        modifier = Modifier
                            .width(70.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(DarkSurfaceHighlight)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(xpProgress)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(ElectricPurple, CyanBlue)
                                    )
                                )
                        )
                    }
                }
            }

            // Right side: Coins, Gems, Notification Bell
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Coins
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurface)
                        .padding(horizontal = 7.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🪙", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "$coins",
                        color = CyberGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                // Gems
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurface)
                        .padding(horizontal = 7.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "💎", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "$gems",
                        color = CyanBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                // Notification Bell
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(DarkSurface)
                        .clickable { onNotificationClick() }
                        .border(1.dp, BorderGlow, CircleShape)
                        .testTag("header_notification_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "🔔", fontSize = 13.sp)
                    if (hasUnreadNotification) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .align(Alignment.TopEnd)
                                .offset(x = (-2).dp, y = 2.dp)
                                .clip(CircleShape)
                                .background(DangerRed)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MatchTimerBar(
    timeRemainingSeconds: Int,
    isFinalTenSeconds: Boolean,
    isVoiceMuted: Boolean,
    isSpeaking: Boolean,
    onToggleVoice: () -> Unit,
    onToggleSpeaking: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isFinalTenSeconds) 1.08f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val timerProgress = (timeRemainingSeconds / 60f).coerceIn(0f, 1f)
    val timerColor by animateColorAsState(
        targetValue = when {
            timeRemainingSeconds <= 10 -> DangerRed
            timeRemainingSeconds <= 25 -> WarningAmber
            else -> ElectricCyan
        },
        label = "timerColor"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Voice Chat controls
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onToggleVoice,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isVoiceMuted) DarkSurfaceHighlight else NeonPurple.copy(alpha = 0.3f))
                        .testTag("btn_voice_mute")
                ) {
                    Icon(
                        imageVector = if (isVoiceMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Voice Chat Mute",
                        tint = if (isVoiceMuted) TextMuted else ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                IconButton(
                    onClick = onToggleSpeaking,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isSpeaking) EmeraldGreen.copy(alpha = 0.3f) else DarkSurfaceHighlight)
                        .testTag("btn_voice_speak")
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Voice Active",
                        tint = if (isSpeaking) EmeraldGreen else TextMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (isSpeaking) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "🎙️ متصل بالصوت...",
                        color = EmeraldGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Big Timer Counter with low-time warning
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .scale(pulseScale)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isFinalTenSeconds) DangerRed.copy(alpha = 0.25f) else DarkSurfaceHighlight
                    )
                    .border(
                        1.dp,
                        if (isFinalTenSeconds) DangerRed else Color.Transparent,
                        RoundedCornerShape(12.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                if (isFinalTenSeconds) {
                    Text(text = "🚨", fontSize = 14.sp)
                    Spacer(modifier = Modifier.width(4.dp))
                }
                Text(
                    text = "⏱️ ${timeRemainingSeconds}s",
                    color = timerColor,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        LinearProgressIndicator(
            progress = { timerProgress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = timerColor,
            trackColor = DarkSurfaceHighlight
        )

        if (isFinalTenSeconds) {
            Text(
                text = "🚨 FINAL 10 SECONDS! خمن الشخصية الآن!",
                color = DangerRed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 3.dp)
            )
        }
    }
}

@Composable
fun OpponentsCarousel(
    opponents: List<Player>,
    selectedOpponentId: String?,
    onSelectOpponent: (String) -> Unit,
    onReportOpponent: (Player) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "👥 اللاعبون في المباراة (${opponents.size})",
            color = TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(opponents) { opp ->
                val isSelected = opp.id == selectedOpponentId
                Card(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onSelectOpponent(opp.id) }
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) ElectricCyan else DarkSurfaceHighlight,
                            shape = RoundedCornerShape(14.dp)
                        )
                        .testTag("card_opponent_${opp.id}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) DarkSurfaceHighlight else DarkSurface
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(NeonPurple.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = opp.avatarEmoji, fontSize = 18.sp)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Column {
                            Text(
                                text = opp.name,
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "🔒 بطاقة سرية",
                                    color = if (opp.isGuessed) EmeraldGreen else TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        IconButton(
                            onClick = { onReportOpponent(opp) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Report/Mute",
                                tint = TextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PowerCardsDeck(
    userCoins: Int,
    onActivatePower: (PowerCardType) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "🎴 Power Cards القدرات الاستراتيجية",
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "🪙 $userCoins كوينز",
                color = CyberGold,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(PowerCardType.values()) { power ->
                val canAfford = userCoins >= power.costCoins
                Card(
                    modifier = Modifier
                        .width(130.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .clickable(enabled = canAfford) { onActivatePower(power) }
                        .border(
                            1.dp,
                            if (canAfford) NeonPurple.copy(alpha = 0.5f) else DarkSurfaceHighlight,
                            RoundedCornerShape(12.dp)
                        )
                        .testTag("power_card_${power.name}"),
                    colors = CardDefaults.cardColors(
                        containerColor = if (canAfford) DarkSurfaceVariant else DarkSurface.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = power.icon, fontSize = 20.sp)
                        Text(
                            text = power.titleAr,
                            color = if (canAfford) TextPrimary else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = power.descAr,
                            color = TextMuted,
                            fontSize = 9.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (canAfford) DarkSurfaceHighlight else DarkSurface
                        ) {
                            Text(
                                text = "🪙 ${power.costCoins}",
                                color = if (canAfford) CyberGold else TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun InteractiveEliminationCard(
    character: Character,
    isEliminated: Boolean,
    isBookmarked: Boolean,
    onToggleEliminate: () -> Unit,
    onToggleBookmark: () -> Unit,
    onGuessCharacter: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onToggleEliminate() }
            .border(
                width = if (isBookmarked) 2.dp else 1.dp,
                color = when {
                    isBookmarked -> CyberGold
                    isEliminated -> DangerRed.copy(alpha = 0.4f)
                    else -> BorderGlow
                },
                shape = RoundedCornerShape(14.dp)
            )
            .testTag("char_tile_${character.id}"),
        colors = CardDefaults.cardColors(
            containerColor = if (isEliminated) DarkSurface.copy(alpha = 0.4f) else DarkSurfaceVariant
        )
    ) {
        Box(modifier = Modifier.padding(8.dp)) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Character Name & Difficulty Stars
                Text(
                    text = character.nameAr,
                    color = if (isEliminated) TextMuted else TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    textDecoration = if (isEliminated) TextDecoration.LineThrough else TextDecoration.None,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = character.origin,
                    color = TextMuted,
                    fontSize = 9.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Tags / Stars
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "⭐".repeat(character.difficulty.stars),
                        fontSize = 8.sp
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Action buttons on card
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Bookmark / Flag as suspect
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(
                                if (isBookmarked) CyberGold.copy(alpha = 0.2f) else DarkSurfaceHighlight
                            )
                            .clickable { onToggleBookmark() },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (isBookmarked) "⭐" else "☆",
                            fontSize = 12.sp
                        )
                    }

                    // Direct Guess Button
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onGuessCharacter() }
                            .testTag("btn_guess_${character.id}"),
                        color = ElectricCyan.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = "🎯 تخمين",
                            color = ElectricCyan,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            // Big Red X overlay when eliminated
            if (isEliminated) {
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(DarkBg.copy(alpha = 0.7f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Eliminated",
                        tint = DangerRed,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ClueLogCard(
    item: ClueLogItem,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 3.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = item.askedByPlayerName,
                        color = ElectricCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = " ➔ ${item.targetPlayerName}",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = item.question,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )

                if (item.note.isNotEmpty()) {
                    Text(
                        text = item.note,
                        color = CyberGold,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Official Answer Pill (YES / NO / MAYBE)
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = when (item.answer) {
                    AnswerType.YES -> EmeraldGreen.copy(alpha = 0.2f)
                    AnswerType.NO -> DangerRed.copy(alpha = 0.2f)
                    AnswerType.MAYBE -> WarningAmber.copy(alpha = 0.2f)
                },
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    when (item.answer) {
                        AnswerType.YES -> EmeraldGreen
                        AnswerType.NO -> DangerRed
                        AnswerType.MAYBE -> WarningAmber
                    }
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = item.answer.emoji, fontSize = 11.sp)
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = item.answer.labelAr,
                        color = when (item.answer) {
                            AnswerType.YES -> EmeraldGreen
                            AnswerType.NO -> DangerRed
                            AnswerType.MAYBE -> WarningAmber
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}
