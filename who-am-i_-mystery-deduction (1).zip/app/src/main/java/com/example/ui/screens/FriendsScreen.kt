package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FriendRequest
import com.example.model.FriendUser
import com.example.model.UserPresenceStatus
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyanBlue
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DangerRed
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.GameScreen
import com.example.viewmodel.GameViewModel

enum class FriendsTab {
    ALL,
    ONLINE,
    IN_MATCH,
    OFFLINE
}

@Composable
fun FriendsScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val friends by viewModel.friendsList.collectAsState()
    val friendRequests by viewModel.friendRequests.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(FriendsTab.ALL) }
    var showAddDialog by remember { mutableStateOf(false) }
    var addUsernameInput by remember { mutableStateOf("") }

    val filteredFriends = friends.filter {
        val matchesSearch = it.username.contains(searchQuery, ignoreCase = true)
        val matchesTab = when (selectedTab) {
            FriendsTab.ALL -> true
            FriendsTab.ONLINE -> it.status == UserPresenceStatus.ONLINE || it.status == UserPresenceStatus.IN_LOBBY
            FriendsTab.IN_MATCH -> it.status == UserPresenceStatus.IN_GAME
            FriendsTab.OFFLINE -> it.status == UserPresenceStatus.OFFLINE
        }
        matchesSearch && matchesTab
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header with [ + ADD FRIEND ]
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "FRIENDS",
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "${friends.count { it.status != UserPresenceStatus.OFFLINE }} friends online",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = ElectricPurple,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { showAddDialog = !showAddDialog }
                        .testTag("btn_add_friend_header")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "ADD FRIEND",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Add Friend Input Bar (expandable)
        if (showAddDialog) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, ElectricPurple.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                    color = DarkSurfaceVariant
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = addUsernameInput,
                            onValueChange = { addUsernameInput = it },
                            placeholder = { Text("Enter username or ID...", color = TextMuted, fontSize = 13.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = DarkSurface,
                                unfocusedContainerColor = DarkSurface,
                                focusedBorderColor = ElectricPurple,
                                unfocusedBorderColor = BorderGlow,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )

                        Button(
                            onClick = {
                                if (addUsernameInput.isNotBlank()) {
                                    viewModel.sendFriendRequest(addUsernameInput)
                                    addUsernameInput = ""
                                    showAddDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricPurple),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Text("SEND", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 2. Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search username...", color = TextMuted, fontSize = 13.sp) },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(14.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.6f),
                    unfocusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.6f),
                    focusedBorderColor = ElectricPurple,
                    unfocusedBorderColor = BorderGlow,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                )
            )
        }

        // 3. Friend Requests Section (if any)
        if (friendRequests.isNotEmpty()) {
            item {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, CyanBlue.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
                    color = DarkSurfaceVariant.copy(alpha = 0.8f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "FRIEND REQUESTS",
                                color = CyanBlue,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                            Surface(
                                shape = CircleShape,
                                color = CyanBlue.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "${friendRequests.size}",
                                    color = CyanBlue,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            friendRequests.forEach { req ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(DarkSurface)
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(text = req.fromAvatar, fontSize = 20.sp)
                                        Column {
                                            Text(
                                                text = req.fromUsername,
                                                color = TextPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "${req.fromRank.emoji} ${req.fromRank.titleAr}",
                                                color = TextMuted,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        // Accept
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(EmeraldGreen.copy(alpha = 0.2f))
                                                .clickable { viewModel.acceptFriendRequest(req.id) }
                                                .border(1.dp, EmeraldGreen, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = "Accept",
                                                tint = EmeraldGreen,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        // Decline
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(DangerRed.copy(alpha = 0.2f))
                                                .clickable { viewModel.declineFriendRequest(req.id) }
                                                .border(1.dp, DangerRed, CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Decline",
                                                tint = DangerRed,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Status Filter Tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    FriendsTab.ALL to "All (${friends.size})",
                    FriendsTab.ONLINE to "Online",
                    FriendsTab.IN_MATCH to "In Match",
                    FriendsTab.OFFLINE to "Offline"
                ).forEach { (tab, label) ->
                    val isSelected = selectedTab == tab
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { selectedTab = tab }
                            .border(
                                1.dp,
                                if (isSelected) ElectricPurple else BorderGlow,
                                RoundedCornerShape(10.dp)
                            ),
                        color = if (isSelected) ElectricPurple.copy(alpha = 0.2f) else DarkSurfaceVariant.copy(alpha = 0.6f)
                    ) {
                        Text(
                            text = label,
                            color = if (isSelected) ElectricPurple else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            modifier = Modifier.padding(vertical = 8.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }

        // 5. Friends List
        if (filteredFriends.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No friends found in this tab",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }
            }
        } else {
            items(filteredFriends) { friend ->
                FriendCard(
                    friend = friend,
                    onProfile = { viewModel.navigateTo(GameScreen.PROFILE) },
                    onInvite = { viewModel.sendGameInviteToFriend(friend.id) }
                )
            }
        }
    }
}

@Composable
private fun FriendCard(
    friend: FriendUser,
    onProfile: () -> Unit,
    onInvite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val statusDot = when (friend.status) {
        UserPresenceStatus.ONLINE -> "🟢"
        UserPresenceStatus.IN_LOBBY -> "🟡"
        UserPresenceStatus.IN_GAME -> "🔴"
        UserPresenceStatus.OFFLINE -> "⚪"
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, BorderGlow, RoundedCornerShape(14.dp)),
        color = DarkSurfaceVariant.copy(alpha = 0.75f)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceHighlight)
                        .border(1.dp, BorderGlow, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = friend.avatarEmoji, fontSize = 20.sp)
                }

                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = friend.username,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(text = statusDot, fontSize = 8.sp)
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "${friend.rankTier.emoji} ${friend.rankTier.titleAr}",
                            color = CyanBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "• ${friend.status.displayName}",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            // Action Buttons: [ PROFILE ], [ INVITE ]
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkSurfaceHighlight,
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderGlow),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onProfile() }
                ) {
                    Text(
                        text = "PROFILE",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (friend.status != UserPresenceStatus.OFFLINE) ElectricPurple else DarkSurfaceHighlight,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(enabled = friend.status != UserPresenceStatus.OFFLINE) { onInvite() }
                ) {
                    Text(
                        text = "INVITE",
                        color = if (friend.status != UserPresenceStatus.OFFLINE) Color.White else TextMuted,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
        }
    }
}
