package com.example.data.social

import com.example.model.FriendRequest
import com.example.model.FriendRequestStatus
import com.example.model.FriendUser
import com.example.model.GameCategory
import com.example.model.GameInvite
import com.example.model.GameMode
import com.example.model.RankTier
import com.example.model.SocialChatMessage
import com.example.model.UserPresenceStatus
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class SocialRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()
) {

    fun observeFriends(userId: String): Flow<List<FriendUser>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = firestore.collection("users")
            .document(userId)
            .collection("friends")
            .addSnapshotListener { snapshot, error ->
                if (snapshot != null) {
                    val friends = snapshot.documents.mapNotNull { doc ->
                        val rankStr = doc.getString("rankTier") ?: RankTier.SILVER.name
                        val statusStr = doc.getString("status") ?: UserPresenceStatus.ONLINE.name
                        FriendUser(
                            id = doc.id,
                            username = doc.getString("username") ?: "لاعب",
                            avatarEmoji = doc.getString("avatarEmoji") ?: "👑",
                            rankTier = try { RankTier.valueOf(rankStr) } catch (_: Exception) { RankTier.SILVER },
                            rankPoints = (doc.getLong("rankPoints") ?: 1200L).toInt(),
                            level = (doc.getLong("level") ?: 1L).toInt(),
                            status = try { UserPresenceStatus.valueOf(statusStr) } catch (_: Exception) { UserPresenceStatus.ONLINE },
                            customStatusText = doc.getString("customStatusText") ?: "",
                            isFavorite = doc.getBoolean("isFavorite") ?: false
                        )
                    }
                    trySend(friends)
                }
            }
        awaitClose { listener.remove() }
    }

    fun observeFriendRequests(userId: String): Flow<List<FriendRequest>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = firestore.collection("users")
            .document(userId)
            .collection("friend_requests")
            .whereEqualTo("status", FriendRequestStatus.PENDING.name)
            .addSnapshotListener { snapshot, error ->
                if (snapshot != null) {
                    val requests = snapshot.documents.mapNotNull { doc ->
                        val rankStr = doc.getString("fromRank") ?: RankTier.SILVER.name
                        FriendRequest(
                            id = doc.id,
                            fromUserId = doc.getString("fromUserId") ?: "",
                            fromUsername = doc.getString("fromUsername") ?: "",
                            fromAvatar = doc.getString("fromAvatar") ?: "👑",
                            fromRank = try { RankTier.valueOf(rankStr) } catch (_: Exception) { RankTier.SILVER },
                            timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                            status = FriendRequestStatus.PENDING
                        )
                    }
                    trySend(requests)
                }
            }
        awaitClose { listener.remove() }
    }

    fun observeGameInvites(userId: String): Flow<List<GameInvite>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = firestore.collection("users")
            .document(userId)
            .collection("game_invites")
            .addSnapshotListener { snapshot, error ->
                if (snapshot != null) {
                    val invites = snapshot.documents.mapNotNull { doc ->
                        val catStr = doc.getString("category") ?: GameCategory.ANIME.name
                        val modeStr = doc.getString("mode") ?: GameMode.ONE_V_ONE.name
                        GameInvite(
                            id = doc.id,
                            roomId = doc.getString("roomId") ?: "",
                            roomName = doc.getString("roomName") ?: "غرفة لعب",
                            category = try { GameCategory.valueOf(catStr) } catch (_: Exception) { GameCategory.ANIME },
                            mode = try { GameMode.valueOf(modeStr) } catch (_: Exception) { GameMode.ONE_V_ONE },
                            fromUserId = doc.getString("fromUserId") ?: "",
                            fromUsername = doc.getString("fromUsername") ?: "صديق",
                            fromAvatar = doc.getString("fromAvatar") ?: "👑",
                            timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                        )
                    }
                    trySend(invites)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun searchUsers(query: String, currentUserId: String): List<FriendUser> {
        if (query.isBlank()) return emptyList()
        return try {
            val snapshot = firestore.collection("users")
                .whereGreaterThanOrEqualTo("username", query)
                .whereLessThanOrEqualTo("username", query + "\uf8ff")
                .limit(10)
                .get()
                .await()

            snapshot.documents.mapNotNull { doc ->
                if (doc.id == currentUserId) return@mapNotNull null
                val rankStr = doc.getString("rankTier") ?: RankTier.SILVER.name
                val statusStr = doc.getString("status") ?: UserPresenceStatus.ONLINE.name
                FriendUser(
                    id = doc.id,
                    username = doc.getString("username") ?: "لاعب",
                    avatarEmoji = doc.getString("avatarEmoji") ?: "👑",
                    rankTier = try { RankTier.valueOf(rankStr) } catch (_: Exception) { RankTier.SILVER },
                    rankPoints = (doc.getLong("rankPoints") ?: 1200L).toInt(),
                    level = (doc.getLong("level") ?: 1L).toInt(),
                    status = try { UserPresenceStatus.valueOf(statusStr) } catch (_: Exception) { UserPresenceStatus.ONLINE }
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun sendFriendRequest(
        targetUserId: String,
        fromUserId: String,
        fromUsername: String,
        fromAvatar: String,
        fromRank: RankTier
    ): Result<Unit> {
        return try {
            val requestMap = hashMapOf<String, Any>(
                "fromUserId" to fromUserId,
                "fromUsername" to fromUsername,
                "fromAvatar" to fromAvatar,
                "fromRank" to fromRank.name,
                "timestamp" to System.currentTimeMillis(),
                "status" to FriendRequestStatus.PENDING.name
            )
            firestore.collection("users")
                .document(targetUserId)
                .collection("friend_requests")
                .document(fromUserId)
                .set(requestMap, SetOptions.merge())
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun acceptFriendRequest(
        currentUserId: String,
        currentUserProfile: FriendUser,
        request: FriendRequest
    ): Result<Unit> {
        return try {
            // Add to current user's friends
            val friendMap = hashMapOf<String, Any>(
                "id" to request.fromUserId,
                "username" to request.fromUsername,
                "avatarEmoji" to request.fromAvatar,
                "rankTier" to request.fromRank.name,
                "status" to UserPresenceStatus.ONLINE.name
            )
            firestore.collection("users")
                .document(currentUserId)
                .collection("friends")
                .document(request.fromUserId)
                .set(friendMap)
                .await()

            // Add to other user's friends
            val meMap = hashMapOf<String, Any>(
                "id" to currentUserId,
                "username" to currentUserProfile.username,
                "avatarEmoji" to currentUserProfile.avatarEmoji,
                "rankTier" to currentUserProfile.rankTier.name,
                "status" to UserPresenceStatus.ONLINE.name
            )
            firestore.collection("users")
                .document(request.fromUserId)
                .collection("friends")
                .document(currentUserId)
                .set(meMap)
                .await()

            // Delete request
            firestore.collection("users")
                .document(currentUserId)
                .collection("friend_requests")
                .document(request.fromUserId)
                .delete()
                .await()

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun declineFriendRequest(currentUserId: String, fromUserId: String) {
        try {
            firestore.collection("users")
                .document(currentUserId)
                .collection("friend_requests")
                .document(fromUserId)
                .delete()
                .await()
        } catch (_: Exception) {}
    }

    suspend fun sendGameInvite(
        friendId: String,
        roomId: String,
        roomName: String,
        category: GameCategory,
        mode: GameMode,
        senderId: String,
        senderName: String,
        senderAvatar: String
    ): Result<Unit> {
        return try {
            val inviteMap = hashMapOf<String, Any>(
                "roomId" to roomId,
                "roomName" to roomName,
                "category" to category.name,
                "mode" to mode.name,
                "fromUserId" to senderId,
                "fromUsername" to senderName,
                "fromAvatar" to senderAvatar,
                "timestamp" to System.currentTimeMillis()
            )
            firestore.collection("users")
                .document(friendId)
                .collection("game_invites")
                .document(roomId)
                .set(inviteMap)
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun dismissInvite(currentUserId: String, roomId: String) {
        try {
            firestore.collection("users")
                .document(currentUserId)
                .collection("game_invites")
                .document(roomId)
                .delete()
                .await()
        } catch (_: Exception) {}
    }
}
