package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.GameDataRepository
import com.example.model.AnswerType
import com.example.model.Character
import com.example.model.ClueLogItem
import com.example.model.CommunityPack
import com.example.model.DailyQuest
import com.example.model.Difficulty
import com.example.model.GameCategory
import com.example.model.GameMode
import com.example.model.LeaderboardEntry
import com.example.model.LiveRoom
import com.example.model.Player
import com.example.model.PowerCardType
import com.example.model.QuickVoiceEmote
import com.example.model.RankTier
import com.example.model.RoomPlayer
import com.example.model.ShopItem
import com.example.model.ShopItemType
import com.example.model.TournamentNode
import com.example.model.VoiceChatSettings
import com.example.model.FriendRequest
import com.example.model.FriendUser
import com.example.model.GameInvite
import com.example.model.UserProfile
import com.example.model.UserPresenceStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

typealias UserProfileState = UserProfile

enum class GameScreen {
    HOME,
    PLAY,
    FRIENDS,
    COLLECTION,
    PROFILE,
    LOBBY_SETUP,
    LIVE_ROOMS,
    ROOM_LOBBY,
    BAN_PHASE,
    CHARACTER_PICK,
    MATCH_ACTIVE,
    MATCH_SUMMARY,
    TOURNAMENT,
    COMMUNITY_PACKS,
    LEADERBOARD,
    SHOP
}

enum class MatchPhase {
    PREPARATION,
    CHARACTER_LOCKED,
    ROUND_ACTIVE,
    GUESSING_MODAL,
    ROUND_ENDED
}

data class ActiveMatchState(
    val mode: GameMode = GameMode.ONE_V_ONE,
    val category: GameCategory = GameCategory.ANIME,
    val phase: MatchPhase = MatchPhase.PREPARATION,
    val roundNumber: Int = 1,
    val totalRounds: Int = 3,
    val timeRemainingSeconds: Int = 60,
    val isFinalTenSeconds: Boolean = false,
    val bannedCharacterIds: Set<String> = emptySet(),
    val availableCharacters: List<Character> = emptyList(),
    val eliminatedCharacterIds: Set<String> = emptySet(),
    val bookmarkedCharacterIds: Set<String> = emptySet(),
    val localPlayer: Player = Player(id = "user", name = "NAGATO", isLocalUser = true),
    val opponents: List<Player> = emptyList(),
    val clueLogs: List<ClueLogItem> = emptyList(),
    val currentAiHint: String? = null,
    val activePowerCard: PowerCardType? = null,
    val doubleGuessActive: Boolean = false,
    val winnerPlayerName: String? = null,
    val matchResultPoints: Int = 0,
    val matchSpeedBonus: Int = 0,
    val matchDifficultyBonus: Int = 0,
    val matchXpEarned: Int = 0,
    val matchCoinsEarned: Int = 0,
    val newlyUnlockedCharacter: Character? = null,
    val isVoiceChatMuted: Boolean = false,
    val isSpeaking: Boolean = false
)

class GameViewModel : ViewModel() {

    private val _currentScreen = MutableStateFlow(GameScreen.HOME)
    val currentScreen: StateFlow<GameScreen> = _currentScreen.asStateFlow()

    private val _profile = MutableStateFlow(UserProfile())
    val profile: StateFlow<UserProfile> = _profile.asStateFlow()

    private val _friendsList = MutableStateFlow<List<FriendUser>>(
        listOf(
            FriendUser("f1", "Shadow_Kira", "🥷", RankTier.LEGEND, 4600, 24, UserPresenceStatus.ONLINE, "مستعد لمبارزة أنمي ⚔️"),
            FriendUser("f2", "Zidane_Wizard", "⚽", RankTier.MASTER, 2800, 19, UserPresenceStatus.IN_LOBBY, "غرفة كلاسيكو 🏟️"),
            FriendUser("f3", "AnimeQueen_01", "👑", RankTier.DIAMOND, 2100, 16, UserPresenceStatus.ONLINE, "ابحث عن فريق 🎌"),
            FriendUser("f4", "GamerLegend_99", "🕹️", RankTier.PLATINUM, 1400, 12, UserPresenceStatus.OFFLINE, "غير متصل")
        )
    )
    val friendsList: StateFlow<List<FriendUser>> = _friendsList.asStateFlow()

    private val _friendRequests = MutableStateFlow<List<FriendRequest>>(
        listOf(
            FriendRequest("req1", "u99", "FalconDetective", "🦅", RankTier.PLATINUM)
        )
    )
    val friendRequests: StateFlow<List<FriendRequest>> = _friendRequests.asStateFlow()

    private val _gameInvites = MutableStateFlow<List<GameInvite>>(emptyList())
    val gameInvites: StateFlow<List<GameInvite>> = _gameInvites.asStateFlow()

    private val _isUserLoggedIn = MutableStateFlow(false)
    val isUserLoggedIn: StateFlow<Boolean> = _isUserLoggedIn.asStateFlow()

    fun signInWithEmail(email: String, pass: String) {
        _isUserLoggedIn.value = true
        _profile.update { it.copy(email = email) }
    }

    fun signUpWithEmail(email: String, pass: String, username: String) {
        _isUserLoggedIn.value = true
        _profile.update { it.copy(email = email, username = if (username.isNotBlank()) username else it.username) }
    }

    fun signOutUser() {
        _isUserLoggedIn.value = false
    }

    fun updateUsername(newName: String) {
        if (newName.isNotBlank()) {
            _profile.update { it.copy(username = newName.trim()) }
        }
    }

    fun lockSelectedCharacter(character: Character) {
        selectSecretCharacter(character)
    }

    fun sendFriendRequest(usernameOrId: String) {
        // Friend request dispatched to backend
    }

    fun acceptFriendRequest(requestId: String) {
        val req = _friendRequests.value.find { it.id == requestId }
        if (req != null) {
            _friendRequests.update { it.filterNot { r -> r.id == requestId } }
            _friendsList.update {
                it + FriendUser(
                    id = req.fromUserId,
                    username = req.fromUsername,
                    avatarEmoji = req.fromAvatar,
                    rankTier = req.fromRank,
                    status = UserPresenceStatus.ONLINE
                )
            }
        }
    }

    fun declineFriendRequest(requestId: String) {
        _friendRequests.update { it.filterNot { r -> r.id == requestId } }
    }

    fun sendGameInviteToFriend(friendId: String) {
        val room = _currentLiveRoom.value ?: return
    }

    fun acceptGameInvite(invite: GameInvite) {
        _gameInvites.update { it.filterNot { i -> i.id == invite.id } }
        joinLiveRoom(invite.roomId)
    }

    fun declineGameInvite(inviteId: String) {
        _gameInvites.update { it.filterNot { i -> i.id == inviteId } }
    }

    fun removeFriend(friendId: String) {
        _friendsList.update { it.filterNot { f -> f.id == friendId } }
    }

    private val _matchState = MutableStateFlow(ActiveMatchState())
    val matchState: StateFlow<ActiveMatchState> = _matchState.asStateFlow()

    private val _communityPacks = MutableStateFlow(GameDataRepository.communityPacks)
    val communityPacks: StateFlow<List<CommunityPack>> = _communityPacks.asStateFlow()

    private val _dailyQuests = MutableStateFlow(GameDataRepository.dailyQuests)
    val dailyQuests: StateFlow<List<DailyQuest>> = _dailyQuests.asStateFlow()

    private val _shopCatalog = MutableStateFlow(GameDataRepository.shopCatalog)
    val shopCatalog: StateFlow<List<ShopItem>> = _shopCatalog.asStateFlow()
    val shopItems: StateFlow<List<ShopItem>> = _shopCatalog.asStateFlow()

    private val _tournamentNodes = MutableStateFlow<List<TournamentNode>>(emptyList())
    val tournamentNodes: StateFlow<List<TournamentNode>> = _tournamentNodes.asStateFlow()

    private val _voiceSettings = MutableStateFlow(VoiceChatSettings())
    val voiceSettings: StateFlow<VoiceChatSettings> = _voiceSettings.asStateFlow()

    private val _currentLiveRoom = MutableStateFlow<LiveRoom?>(null)
    val currentLiveRoom: StateFlow<LiveRoom?> = _currentLiveRoom.asStateFlow()

    private val _quickVoiceEmotes = MutableStateFlow(
        listOf(
            QuickVoiceEmote("e1", "أنا متأكد 100%!", "🎯"),
            QuickVoiceEmote("e2", "مستحيل! ركز معي 🤔", "🧠"),
            QuickVoiceEmote("e3", "شخصية أسطورية جداً!", "🔥"),
            QuickVoiceEmote("e4", "هل هو بشري؟ 👤", "❓"),
            QuickVoiceEmote("e5", "سؤال ذكي جداً 👏", "⚡"),
            QuickVoiceEmote("e6", "الوقت قرب يخلص! ⏳", "🚨"),
            QuickVoiceEmote("e7", "مبروك الفوز يا بطل! 🏆", "🎉"),
            QuickVoiceEmote("e8", "حظ أوفر الجولة القادمة! 🤝", "💎")
        )
    )
    val quickVoiceEmotes: StateFlow<List<QuickVoiceEmote>> = _quickVoiceEmotes.asStateFlow()

    private val _liveRooms = MutableStateFlow(
        listOf(
            LiveRoom(
                id = "ROOM-7701",
                name = "🎌 نخبة محققي الأنمي | مايك مفتوح 🎙️",
                hostName = "Shadow_Kira",
                category = GameCategory.ANIME,
                mode = GameMode.FREE_FOR_ALL,
                currentPlayers = 4,
                maxPlayers = 6,
                isVoiceEnabled = true,
                isPasswordProtected = false,
                region = "🇸🇦 الرياض (18ms)",
                pingMs = 18,
                isRanked = true,
                roundTimerSec = 60,
                players = listOf(
                    RoomPlayer("p1", "Shadow_Kira", "🥷", "🇯🇵", RankTier.LEGEND, isHost = true, isReady = true, isMicOn = true, isSpeaking = true, audioLevel = 0.85f, pingMs = 18, equippedTitle = "سيد الأنمي"),
                    RoomPlayer("p2", "LeviSensei", "⚔️", "🇸🇦", RankTier.GRANDMASTER, isHost = false, isReady = true, isMicOn = true, isSpeaking = false, audioLevel = 0.0f, pingMs = 24, equippedTitle = "محقق عبقري"),
                    RoomPlayer("p3", "CyberOtaku", "👾", "🇪🇬", RankTier.MASTER, isHost = false, isReady = true, isMicOn = true, isSpeaking = true, audioLevel = 0.65f, pingMs = 38, equippedTitle = "خبير الرانك"),
                    RoomPlayer("p4", "AnimeQueen_01", "👑", "🇰🇼", RankTier.DIAMOND, isHost = false, isReady = false, isMicOn = false, isSpeaking = false, audioLevel = 0.0f, pingMs = 29, equippedTitle = "صيادة الشخصيات")
                )
            ),
            LiveRoom(
                id = "ROOM-5219",
                name = "⚽ كلاسيكو كرة القدم العالمية 🏟️",
                hostName = "Zidane_Wizard",
                category = GameCategory.FOOTBALL,
                mode = GameMode.ONE_V_ONE,
                currentPlayers = 1,
                maxPlayers = 2,
                isVoiceEnabled = true,
                isPasswordProtected = false,
                region = "🇦🇪 دبي (22ms)",
                pingMs = 22,
                isRanked = true,
                roundTimerSec = 45,
                players = listOf(
                    RoomPlayer("p5", "Zidane_Wizard", "⚽", "🇩🇿", RankTier.MASTER, isHost = true, isReady = true, isMicOn = true, isSpeaking = false, pingMs = 22, equippedTitle = "صانع الألعاب")
                )
            ),
            LiveRoom(
                id = "ROOM-9042",
                name = "🎮 عشاق ألعاب الفيديو و الـ Bosses 🕹️",
                hostName = "Kratos_Fury",
                category = GameCategory.VIDEO_GAMES,
                mode = GameMode.TEAMS,
                currentPlayers = 3,
                maxPlayers = 4,
                isVoiceEnabled = true,
                isPasswordProtected = false,
                region = "🇸🇦 جدة (26ms)",
                pingMs = 26,
                isRanked = false,
                roundTimerSec = 60,
                players = listOf(
                    RoomPlayer("p6", "Kratos_Fury", "🪓", "🇬🇷", RankTier.DIAMOND, isHost = true, isReady = true, isMicOn = true, isSpeaking = true, audioLevel = 0.9f, pingMs = 26),
                    RoomPlayer("p7", "SpeedyGamer", "⚡", "🇦🇪", RankTier.DIAMOND, isHost = false, isReady = true, isMicOn = true, isSpeaking = false, pingMs = 28),
                    RoomPlayer("p8", "MarioHero", "🍄", "🇮🇹", RankTier.PLATINUM, isHost = false, isReady = false, isMicOn = true, isSpeaking = false, pingMs = 42)
                )
            ),
            LiveRoom(
                id = "ROOM-3180",
                name = "🦸‍♂️ أبطال وأشرار مارفل ودي سي 💥",
                hostName = "FalconDetective",
                category = GameCategory.SUPERHEROES,
                mode = GameMode.PARTY,
                currentPlayers = 5,
                maxPlayers = 8,
                isVoiceEnabled = true,
                isPasswordProtected = false,
                region = "🇪🇬 القاهرة (34ms)",
                pingMs = 34,
                isRanked = false,
                roundTimerSec = 50,
                players = listOf(
                    RoomPlayer("p9", "FalconDetective", "🦅", "🇯🇴", RankTier.PLATINUM, isHost = true, isReady = true, isMicOn = true, pingMs = 34),
                    RoomPlayer("p10", "SpiderWeb", "🕷️", "🇪🇬", RankTier.GOLD, isHost = false, isReady = true, isMicOn = true, pingMs = 36),
                    RoomPlayer("p11", "BatmanDark", "🦇", "🇸🇦", RankTier.DIAMOND, isHost = false, isReady = true, isMicOn = false, pingMs = 21),
                    RoomPlayer("p12", "IronTech", "🤖", "🇦🇪", RankTier.MASTER, isHost = false, isReady = true, isMicOn = true, pingMs = 25),
                    RoomPlayer("p13", "WonderGamer", "⭐", "🇶🇦", RankTier.PLATINUM, isHost = false, isReady = false, isMicOn = true, pingMs = 30)
                )
            ),
            LiveRoom(
                id = "ROOM-1124",
                name = "🔒 غرفة خاصة - بطولات الأصدقاء VIP",
                hostName = "DragonLord",
                category = GameCategory.CREATURES,
                mode = GameMode.CUSTOM_ROOM,
                currentPlayers = 2,
                maxPlayers = 4,
                isVoiceEnabled = true,
                isPasswordProtected = true,
                passwordPin = "1234",
                region = "🇸🇦 الرياض (16ms)",
                pingMs = 16,
                isRanked = false,
                roundTimerSec = 60,
                players = listOf(
                    RoomPlayer("p14", "DragonLord", "🐉", "🇸🇦", RankTier.GRANDMASTER, isHost = true, isReady = true, isMicOn = true, pingMs = 16),
                    RoomPlayer("p15", "PhoenixRider", "🔥", "🇧🇭", RankTier.MASTER, isHost = false, isReady = true, isMicOn = true, pingMs = 20)
                )
            )
        )
    )
    val liveRooms: StateFlow<List<LiveRoom>> = _liveRooms.asStateFlow()

    private val _isMatchmaking = MutableStateFlow(false)
    val isMatchmaking: StateFlow<Boolean> = _isMatchmaking.asStateFlow()

    private val _matchmakingElapsedSeconds = MutableStateFlow(0)
    val matchmakingElapsedSeconds: StateFlow<Int> = _matchmakingElapsedSeconds.asStateFlow()

    private var voiceSimulationJob: Job? = null
    private var matchmakingJob: Job? = null

    private val _leaderboardEntries = MutableStateFlow(
        listOf(
            LeaderboardEntry(1, "NAGATO (أنت)", "🇸🇦", "🦊", RankTier.LEGEND, 4920, 14, 96),
            LeaderboardEntry(2, "Shadow_Kira", "🇯🇵", "🥷", RankTier.LEGEND, 4780, 11, 93),
            LeaderboardEntry(3, "Levi_Captain", "🇫🇷", "⚔️", RankTier.GRANDMASTER, 4310, 8, 91),
            LeaderboardEntry(4, "GokuSlayer", "🇧🇷", "🔥", RankTier.GRANDMASTER, 3950, 7, 88),
            LeaderboardEntry(5, "Zidane_Wizard", "🇩🇿", "⚽", RankTier.MASTER, 3420, 6, 85),
            LeaderboardEntry(6, "CyberOtaku", "🇪🇬", "👾", RankTier.MASTER, 3100, 5, 83),
            LeaderboardEntry(7, "SpeedyGamer", "🇦🇪", "⚡", RankTier.DIAMOND, 2750, 4, 80),
            LeaderboardEntry(8, "Kratos_Fury", "🇬🇷", "🪓", RankTier.DIAMOND, 2480, 4, 79),
            LeaderboardEntry(9, "AnimeQueen_01", "🇰🇼", "👑", RankTier.PLATINUM, 2190, 3, 76),
            LeaderboardEntry(10, "FalconDetective", "🇯🇴", "🦅", RankTier.PLATINUM, 1940, 2, 73)
        )
    )
    val leaderboardEntries: StateFlow<List<LeaderboardEntry>> = _leaderboardEntries.asStateFlow()

    private var timerJob: Job? = null
    private var simulatedOpponentJob: Job? = null

    init {
        generateInitialTournament()
    }

    fun navigateTo(screen: GameScreen) {
        _currentScreen.value = screen
    }

    // === MATCH LIFECYCLE ===

    fun startMatchSetup(mode: GameMode, category: GameCategory = GameCategory.ANIME) {
        val categoryChars = GameDataRepository.allCharacters.filter { it.category == category }
        
        val oppCount = when (mode) {
            GameMode.ONE_V_ONE -> 1
            GameMode.FREE_FOR_ALL -> 4
            GameMode.TEAMS -> 3
            GameMode.PARTY -> 3
            GameMode.RANKED -> 2
            GameMode.CUSTOM_ROOM -> 3
            GameMode.TOURNAMENT -> 1
        }

        val aiNames = listOf("Kira_AI", "LeviSensei", "ShadowHunter", "SpeedyGamer", "OtakuKing", "CyberWolf")
        val generatedOpponents = (0 until oppCount).map { i ->
            val randomChar = categoryChars.random()
            Player(
                id = "opp_$i",
                name = aiNames.getOrElse(i) { "Player_${i + 1}" },
                isLocalUser = false,
                isAi = true,
                secretCharacter = randomChar,
                rankTitle = listOf("Diamond", "Master", "Platinum", "Gold").random(),
                avatarEmoji = listOf("🥷", "⚡", "👑", "🔥", "🐺", "🎯").random()
            )
        }

        _matchState.value = ActiveMatchState(
            mode = mode,
            category = category,
            phase = MatchPhase.PREPARATION,
            availableCharacters = categoryChars,
            localPlayer = Player(
                id = "user",
                name = _profile.value.username,
                isLocalUser = true,
                avatarEmoji = _profile.value.equippedAvatar,
                rankTitle = _profile.value.rankTier.tierNameEn
            ),
            opponents = generatedOpponents
        )

        if (mode == GameMode.RANKED || mode == GameMode.CUSTOM_ROOM) {
            _currentScreen.value = GameScreen.BAN_PHASE
        } else {
            _currentScreen.value = GameScreen.CHARACTER_PICK
        }
    }

    fun toggleBanCharacter(charId: String) {
        _matchState.update { current ->
            val currentBans = current.bannedCharacterIds.toMutableSet()
            if (currentBans.contains(charId)) {
                currentBans.remove(charId)
            } else if (currentBans.size < 2) {
                currentBans.add(charId)
            }
            current.copy(bannedCharacterIds = currentBans)
        }
    }

    fun confirmBansAndProceed() {
        val remaining = _matchState.value.availableCharacters.filterNot { _matchState.value.bannedCharacterIds.contains(it.id) }
        val aiBan = remaining.randomOrNull()?.id
        val finalBans = _matchState.value.bannedCharacterIds.toMutableSet()
        if (aiBan != null && finalBans.size < 3) {
            finalBans.add(aiBan)
        }

        _matchState.update { it.copy(bannedCharacterIds = finalBans) }
        _currentScreen.value = GameScreen.CHARACTER_PICK
    }

    fun selectSecretCharacter(character: Character) {
        viewModelScope.launch {
            _matchState.update { current ->
                current.copy(
                    localPlayer = current.localPlayer.copy(secretCharacter = character),
                    phase = MatchPhase.CHARACTER_LOCKED
                )
            }

            delay(1200) // Visual locking transition

            startActiveRound()
        }
    }

    private fun startActiveRound() {
        _matchState.update {
            it.copy(
                phase = MatchPhase.ROUND_ACTIVE,
                timeRemainingSeconds = 60,
                isFinalTenSeconds = false,
                clueLogs = listOf(
                    ClueLogItem(
                        id = UUID.randomUUID().toString(),
                        question = "بدأت الجولة! اسأل أسئلتك بذكاء واستبعد الشخصيات من لوحتك.",
                        askedByPlayerName = "🤖 Game Master",
                        targetPlayerName = "الجميع",
                        answer = AnswerType.YES,
                        timestamp = getCurrentTimeString(),
                        note = "تلميح: استخدم إجابات نعم / لا لاستبعاد نصف القائمة بسرعة!"
                    )
                )
            )
        }
        _currentScreen.value = GameScreen.MATCH_ACTIVE

        startTimer()
        startSimulatedOpponentTurns()
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (_matchState.value.timeRemainingSeconds > 0 && _matchState.value.phase == MatchPhase.ROUND_ACTIVE) {
                delay(1000)
                _matchState.update { current ->
                    val newTime = current.timeRemainingSeconds - 1
                    val isFinalTen = newTime in 1..10
                    current.copy(
                        timeRemainingSeconds = newTime,
                        isFinalTenSeconds = isFinalTen
                    )
                }
            }

            if (_matchState.value.timeRemainingSeconds <= 0 && _matchState.value.phase == MatchPhase.ROUND_ACTIVE) {
                handleRoundTimeout()
            }
        }
    }

    private fun startSimulatedOpponentTurns() {
        simulatedOpponentJob?.cancel()
        simulatedOpponentJob = viewModelScope.launch {
            while (_matchState.value.phase == MatchPhase.ROUND_ACTIVE) {
                delay((8000..14000).random().toLong())
                if (_matchState.value.phase != MatchPhase.ROUND_ACTIVE) break

                val opponents = _matchState.value.opponents
                if (opponents.isEmpty()) continue

                val randomOpp = opponents.random()
                val targetUser = _matchState.value.localPlayer

                val randomQuestion = GameDataRepository.presetQuestions.random()
                val userSecret = targetUser.secretCharacter

                val answer = if (userSecret != null) {
                    evaluateAnswerForCharacter(randomQuestion, userSecret)
                } else {
                    listOf(AnswerType.YES, AnswerType.NO).random()
                }

                val newLog = ClueLogItem(
                    id = UUID.randomUUID().toString(),
                    question = randomQuestion,
                    askedByPlayerName = randomOpp.name,
                    targetPlayerName = targetUser.name,
                    answer = answer,
                    timestamp = getCurrentTimeString()
                )

                _matchState.update { it.copy(clueLogs = it.clueLogs + newLog) }
            }
        }
    }

    fun askQuestion(questionText: String, targetOpponentId: String? = null) {
        val targetOpp = _matchState.value.opponents.find { it.id == targetOpponentId }
            ?: _matchState.value.opponents.firstOrNull()

        if (targetOpp == null) return

        val secretChar = targetOpp.secretCharacter
        val answer = if (secretChar != null) {
            evaluateAnswerForCharacter(questionText, secretChar)
        } else {
            AnswerType.MAYBE
        }

        val log = ClueLogItem(
            id = UUID.randomUUID().toString(),
            question = questionText,
            askedByPlayerName = _matchState.value.localPlayer.name,
            targetPlayerName = targetOpp.name,
            answer = answer,
            timestamp = getCurrentTimeString()
        )

        _matchState.update { it.copy(clueLogs = it.clueLogs + log) }
    }

    private fun evaluateAnswerForCharacter(question: String, character: Character): AnswerType {
        val q = question.lowercase(Locale.ROOT)
        return when {
            q.contains("ذكر") || q.contains("رجل") || q.contains("male") -> if (character.isMale) AnswerType.YES else AnswerType.NO
            q.contains("حقيقية") || q.contains("واقعي") || q.contains("real") -> if (character.isRealPerson) AnswerType.YES else AnswerType.NO
            q.contains("سلاح") || q.contains("قوى") || q.contains("سحر") || q.contains("weapon") || q.contains("power") -> if (character.usesWeaponsOrPowers) AnswerType.YES else AnswerType.NO
            q.contains("أنمي") || q.contains("anime") -> if (character.category == GameCategory.ANIME) AnswerType.YES else AnswerType.NO
            q.contains("كرة") || q.contains("football") -> if (character.category == GameCategory.FOOTBALL) AnswerType.YES else AnswerType.NO
            q.contains("لعبة") || q.contains("game") -> if (character.category == GameCategory.VIDEO_GAMES) AnswerType.YES else AnswerType.NO
            q.contains("شرير") || q.contains("villain") -> if (character.tags.any { it.contains("Villain", ignoreCase = true) || it.contains("Akatsuki", ignoreCase = true) || it.contains("Joker", ignoreCase = true) }) AnswerType.YES else AnswerType.NO
            else -> listOf(AnswerType.YES, AnswerType.NO, AnswerType.MAYBE).random()
        }
    }

    fun toggleEliminateCharacter(charId: String) {
        _matchState.update { current ->
            val eliminated = current.eliminatedCharacterIds.toMutableSet()
            if (eliminated.contains(charId)) {
                eliminated.remove(charId)
            } else {
                eliminated.add(charId)
            }
            current.copy(eliminatedCharacterIds = eliminated)
        }
    }

    fun toggleBookmarkCharacter(charId: String) {
        _matchState.update { current ->
            val bookmarks = current.bookmarkedCharacterIds.toMutableSet()
            if (bookmarks.contains(charId)) {
                bookmarks.remove(charId)
            } else {
                bookmarks.add(charId)
            }
            current.copy(bookmarkedCharacterIds = bookmarks)
        }
    }

    fun activatePowerCard(power: PowerCardType) {
        if (_profile.value.coins < power.costCoins) return

        _profile.update { it.copy(coins = it.coins - power.costCoins) }

        when (power) {
            PowerCardType.TIME_BOOST -> {
                _matchState.update {
                    it.copy(
                        timeRemainingSeconds = it.timeRemainingSeconds + 20,
                        isFinalTenSeconds = false,
                        clueLogs = it.clueLogs + ClueLogItem(
                            id = UUID.randomUUID().toString(),
                            question = "تم تفعيل بطاقة تمديد الوقت (+20 ثانية) ⏳",
                            askedByPlayerName = "⚡ Power Card",
                            targetPlayerName = "الجميع",
                            answer = AnswerType.YES,
                            timestamp = getCurrentTimeString()
                        )
                    )
                }
            }
            PowerCardType.REVEAL -> {
                val targetOpp = _matchState.value.opponents.firstOrNull()
                val targetSecretId = targetOpp?.secretCharacter?.id
                val availableToEliminate = _matchState.value.availableCharacters
                    .filter { it.id != targetSecretId && !_matchState.value.eliminatedCharacterIds.contains(it.id) }
                    .take(2)
                    .map { it.id }
                    .toSet()

                _matchState.update {
                    it.copy(
                        eliminatedCharacterIds = it.eliminatedCharacterIds + availableToEliminate,
                        clueLogs = it.clueLogs + ClueLogItem(
                            id = UUID.randomUUID().toString(),
                            question = "تم تفعيل بطاقة الرؤية الخاطفة: تم استبعاد شخصيتين مستحيلتين! 👁️",
                            askedByPlayerName = "⚡ Power Card",
                            targetPlayerName = "الجميع",
                            answer = AnswerType.YES,
                            timestamp = getCurrentTimeString()
                        )
                    )
                }
            }
            PowerCardType.DETECTIVE -> {
                val targetOpp = _matchState.value.opponents.firstOrNull()
                val hint = targetOpp?.secretCharacter?.hints?.firstOrNull() ?: "الشخصية مشهورة جداً وذات مهارات خاصة"
                _matchState.update {
                    it.copy(
                        currentAiHint = hint,
                        clueLogs = it.clueLogs + ClueLogItem(
                            id = UUID.randomUUID().toString(),
                            question = "كاشف الأدلة 🔍: $hint",
                            askedByPlayerName = "⚡ Power Card",
                            targetPlayerName = "الجميع",
                            answer = AnswerType.YES,
                            timestamp = getCurrentTimeString()
                        )
                    )
                }
            }
            PowerCardType.DOUBLE_GUESS -> {
                _matchState.update {
                    it.copy(
                        doubleGuessActive = true,
                        clueLogs = it.clueLogs + ClueLogItem(
                            id = UUID.randomUUID().toString(),
                            question = "تم تفعيل التخمين المزدوج: تخمينك القادم بدون أي عقوبة خطأ! 🎯",
                            askedByPlayerName = "⚡ Power Card",
                            targetPlayerName = "الجميع",
                            answer = AnswerType.YES,
                            timestamp = getCurrentTimeString()
                        )
                    )
                }
            }
            PowerCardType.WILD_QUESTION -> {
                val targetOpp = _matchState.value.opponents.firstOrNull()
                val origin = targetOpp?.secretCharacter?.origin ?: "عمل مشهور"
                _matchState.update {
                    it.copy(
                        clueLogs = it.clueLogs + ClueLogItem(
                            id = UUID.randomUUID().toString(),
                            question = "سؤال جوكر AI 🃏: الشخصية تنتمي إلى العمل الأسطوري ($origin)",
                            askedByPlayerName = "🤖 Game Master AI",
                            targetPlayerName = "الجميع",
                            answer = AnswerType.YES,
                            timestamp = getCurrentTimeString()
                        )
                    )
                }
            }
        }
    }

    fun submitGuess(targetOpponentId: String, guessedCharacter: Character) {
        val targetOpp = _matchState.value.opponents.find { it.id == targetOpponentId }
            ?: _matchState.value.opponents.firstOrNull()

        if (targetOpp == null) return

        val isCorrect = targetOpp.secretCharacter?.id == guessedCharacter.id

        if (isCorrect) {
            handleVictory(guessedCharacter)
        } else {
            handleIncorrectGuess(guessedCharacter)
        }
    }

    private fun handleVictory(guessedCharacter: Character) {
        timerJob?.cancel()
        simulatedOpponentJob?.cancel()

        val speedSecondsLeft = _matchState.value.timeRemainingSeconds
        val speedBonus = speedSecondsLeft * 10
        val diffBonus = (guessedCharacter.difficulty.multiplier * 150).toInt()
        val streakMultiplier = 1 + (_profile.value.winStreak * 0.05f)
        val basePoints = 250
        val totalPoints = ((basePoints + speedBonus + diffBonus) * streakMultiplier).toInt()

        val xpEarned = totalPoints / 2
        val coinsEarned = totalPoints / 4

        val newUnlockedSet = _profile.value.unlockedCharacterIds + guessedCharacter.id
        val newStreak = _profile.value.winStreak + 1
        val newRankPoints = _profile.value.rankPoints + (totalPoints / 10)
        val updatedTier = calculateRankTier(newRankPoints)

        _profile.update {
            it.copy(
                coins = it.coins + coinsEarned,
                xp = it.xp + xpEarned,
                rankPoints = newRankPoints,
                rankTier = updatedTier,
                winStreak = newStreak,
                highestStreak = maxOf(it.highestStreak, newStreak),
                totalGames = it.totalGames + 1,
                wins = it.wins + 1,
                unlockedCharacterIds = newUnlockedSet
            )
        }

        updateDailyQuestProgress("quest_guess_5", 1)
        if (_matchState.value.mode == GameMode.RANKED) {
            updateDailyQuestProgress("quest_win_3_ranked", 1)
        }
        if (speedSecondsLeft >= 45) {
            updateDailyQuestProgress("quest_fast_guess", 1)
        }

        _matchState.update {
            it.copy(
                phase = MatchPhase.ROUND_ENDED,
                winnerPlayerName = _profile.value.username,
                matchResultPoints = totalPoints,
                matchSpeedBonus = speedBonus,
                matchDifficultyBonus = diffBonus,
                matchXpEarned = xpEarned,
                matchCoinsEarned = coinsEarned,
                newlyUnlockedCharacter = guessedCharacter
            )
        }
        _currentScreen.value = GameScreen.MATCH_SUMMARY
    }

    private fun handleIncorrectGuess(guessedCharacter: Character) {
        if (_matchState.value.doubleGuessActive) {
            _matchState.update {
                it.copy(
                    doubleGuessActive = false,
                    clueLogs = it.clueLogs + ClueLogItem(
                        id = UUID.randomUUID().toString(),
                        question = "تخمين خاطئ (${guessedCharacter.nameAr})! لكن تم حمايتك بواسطة بطاقة التخمين المزدوج 🛡️",
                        askedByPlayerName = "🚨 System",
                        targetPlayerName = "أنت",
                        answer = AnswerType.NO,
                        timestamp = getCurrentTimeString()
                    )
                )
            }
            return
        }

        val newTime = maxOf(5, _matchState.value.timeRemainingSeconds - 15)
        _matchState.update {
            it.copy(
                timeRemainingSeconds = newTime,
                clueLogs = it.clueLogs + ClueLogItem(
                    id = UUID.randomUUID().toString(),
                    question = "تخمين خاطئ (${guessedCharacter.nameAr})! تم تطبيق عقوبة زمنية (-15 ثانية) ⏳",
                    askedByPlayerName = "🚨 System",
                    targetPlayerName = "أنت",
                    answer = AnswerType.NO,
                    timestamp = getCurrentTimeString()
                )
            )
        }
    }

    private fun handleRoundTimeout() {
        timerJob?.cancel()
        simulatedOpponentJob?.cancel()

        _profile.update {
            it.copy(
                winStreak = 0,
                totalGames = it.totalGames + 1
            )
        }

        _matchState.update {
            it.copy(
                phase = MatchPhase.ROUND_ENDED,
                winnerPlayerName = _matchState.value.opponents.firstOrNull()?.name ?: "الخصم",
                matchResultPoints = 50,
                matchXpEarned = 30,
                matchCoinsEarned = 15
            )
        }
        _currentScreen.value = GameScreen.MATCH_SUMMARY
    }

    private fun calculateRankTier(points: Int): RankTier {
        return when {
            points >= RankTier.LEGEND.minPoints -> RankTier.LEGEND
            points >= RankTier.GRANDMASTER.minPoints -> RankTier.GRANDMASTER
            points >= RankTier.MASTER.minPoints -> RankTier.MASTER
            points >= RankTier.DIAMOND.minPoints -> RankTier.DIAMOND
            points >= RankTier.PLATINUM.minPoints -> RankTier.PLATINUM
            points >= RankTier.GOLD.minPoints -> RankTier.GOLD
            points >= RankTier.SILVER.minPoints -> RankTier.SILVER
            else -> RankTier.BRONZE
        }
    }

    // === TOURNAMENT 64 SIMULATION ===
    private fun generateInitialTournament() {
        val names = listOf(
            "NAGATO (أنت)", "Kira_AI", "Levi_King", "GokuFan99", "Zidane_Cap",
            "ShadowNinja", "OtakuMaster", "CyberGhost", "SpeedDemon", "Valkyrie",
            "TitanSlayer", "Shinobi_7", "RedKnight", "BlazeGamer", "MysticSage", "AlphaWolf"
        )
        val round1 = (0 until 8).map { i ->
            TournamentNode(
                id = "t_r1_$i",
                roundName = "دور الـ 16",
                player1Name = names.getOrElse(i * 2) { "Player_${i * 2 + 1}" },
                player2Name = names.getOrElse(i * 2 + 1) { "Player_${i * 2 + 2}" },
                score1 = (2..5).random(),
                score2 = (0..2).random(),
                isCompleted = false
            )
        }
        _tournamentNodes.value = round1
    }

    fun playOrSimulateTournamentMatch(nodeId: String) {
        _tournamentNodes.update { current ->
            current.map { node ->
                if (node.id == nodeId && !node.isCompleted) {
                    val p1Wins = node.player1Name.contains("NAGATO") || (0..1).random() == 1
                    val winner = if (p1Wins) node.player1Name else node.player2Name
                    node.copy(
                        isCompleted = true,
                        score1 = if (p1Wins) 3 else 1,
                        score2 = if (p1Wins) 1 else 3,
                        winnerName = winner
                    )
                } else node
            }
        }
    }

    // === COMMUNITY PACKS ===
    fun likeCommunityPack(packId: String) {
        _communityPacks.update { current ->
            current.map { pack ->
                if (pack.id == packId) pack.copy(likes = pack.likes + 1) else pack
            }
        }
    }

    fun createCommunityPack(title: String, desc: String, category: GameCategory, sampleChars: List<String>) {
        val newPack = CommunityPack(
            id = UUID.randomUUID().toString(),
            title = title,
            author = _profile.value.username,
            category = category,
            characterCount = sampleChars.size + 15,
            likes = 1,
            rating = 5.0f,
            difficulty = Difficulty.NORMAL,
            description = desc,
            sampleCharacters = sampleChars,
            isVerified = false
        )
        _communityPacks.update { listOf(newPack) + it }
    }

    // === DAILY QUESTS & SHOP ===
    private fun updateDailyQuestProgress(questId: String, amount: Int) {
        _dailyQuests.update { current ->
            current.map { quest ->
                if (quest.id == questId && !quest.isClaimed) {
                    val newCur = minOf(quest.target, quest.current + amount)
                    quest.copy(current = newCur)
                } else quest
            }
        }
    }

    fun claimQuestReward(questId: String) {
        val quest = _dailyQuests.value.find { it.id == questId } ?: return
        if (quest.current >= quest.target && !quest.isClaimed) {
            _profile.update {
                it.copy(
                    coins = it.coins + quest.rewardCoins,
                    xp = it.xp + quest.rewardXp
                )
            }
            _dailyQuests.update { current ->
                current.map { if (it.id == questId) it.copy(isClaimed = true) else it }
            }
        }
    }

    fun buyOrEquipShopItem(itemId: String) {
        val item = _shopCatalog.value.find { it.id == itemId } ?: return
        if (item.isPurchased) {
            equipShopItem(item)
        } else if (_profile.value.coins >= item.priceCoins) {
            purchaseShopItem(item)
            equipShopItem(item)
        }
    }

    private fun purchaseShopItem(item: ShopItem) {
        if (_profile.value.coins >= item.priceCoins && !item.isPurchased) {
            _profile.update { it.copy(coins = it.coins - item.priceCoins) }
            _shopCatalog.update { current ->
                current.map { if (it.id == item.id) it.copy(isPurchased = true) else it }
            }
        }
    }

    private fun equipShopItem(item: ShopItem) {
        when (item.type) {
            ShopItemType.FRAME -> _profile.update { it.copy(equippedFrame = item.id) }
            ShopItemType.AVATAR -> _profile.update { it.copy(equippedAvatar = item.previewValue) }
            ShopItemType.TITLE -> _profile.update { it.copy(equippedTitle = item.previewValue) }
            else -> {}
        }
        _shopCatalog.update { current ->
            current.map {
                if (it.type == item.type) {
                    it.copy(isEquipped = it.id == item.id)
                } else it
            }
        }
    }

    fun toggleVoiceMute() {
        _matchState.update { it.copy(isVoiceChatMuted = !it.isVoiceChatMuted) }
        _voiceSettings.update { it.copy(isMicMuted = !it.isMicMuted) }
        updateCurrentRoomLocalPlayerMic(!_voiceSettings.value.isMicMuted)
    }

    fun toggleSpeakingState() {
        _matchState.update { it.copy(isSpeaking = !it.isSpeaking) }
        _currentLiveRoom.update { room ->
            room?.copy(
                players = room.players.map {
                    if (it.isLocalUser) it.copy(isSpeaking = _matchState.value.isSpeaking, audioLevel = if (_matchState.value.isSpeaking) 0.8f else 0.0f)
                    else it
                }
            )
        }
    }

    // === LIVE ROOMS & ONLINE PLAYERS ===

    fun startQuickMatch(category: GameCategory = GameCategory.ANIME, mode: GameMode = GameMode.FREE_FOR_ALL) {
        _isMatchmaking.value = true
        _matchmakingElapsedSeconds.value = 0
        matchmakingJob?.cancel()
        matchmakingJob = viewModelScope.launch {
            for (sec in 1..4) {
                delay(1000)
                _matchmakingElapsedSeconds.value = sec
            }
            _isMatchmaking.value = false
            // Found real players room
            val matchedRoom = LiveRoom(
                id = "MATCH-" + (1000..9999).random(),
                name = "⚡ مباراة سريعة أونلاين (${category.titleAr})",
                hostName = "SaudiGamer_Pro",
                category = category,
                mode = mode,
                currentPlayers = 4,
                maxPlayers = 4,
                isVoiceEnabled = true,
                region = "🇸🇦 الرياض (19ms)",
                pingMs = 19,
                isRanked = true,
                players = listOf(
                    RoomPlayer("u1", "SaudiGamer_Pro", "⚡", "🇸🇦", RankTier.LEGEND, isHost = true, isReady = true, isMicOn = true, isSpeaking = false, pingMs = 19, equippedTitle = "أسطورة الرانك"),
                    RoomPlayer("u2", "CairoSherlock", "🔍", "🇪🇬", RankTier.MASTER, isHost = false, isReady = true, isMicOn = true, isSpeaking = true, audioLevel = 0.75f, pingMs = 32, equippedTitle = "محقق ذكي"),
                    RoomPlayer("u3", "GulfDetective", "🦅", "🇦🇪", RankTier.DIAMOND, isHost = false, isReady = true, isMicOn = true, isSpeaking = false, pingMs = 24, equippedTitle = "صياد الغموض"),
                    RoomPlayer("user_me", _profile.value.username, _profile.value.equippedAvatar, "🇸🇦", _profile.value.rankTier, isHost = false, isReady = true, isLocalUser = true, isMicOn = !_voiceSettings.value.isMicMuted, pingMs = 20, equippedTitle = _profile.value.equippedTitle)
                )
            )
            _currentLiveRoom.value = matchedRoom
            _currentScreen.value = GameScreen.ROOM_LOBBY
            startVoiceSimulationLoop()
        }
    }

    fun cancelMatchmaking() {
        matchmakingJob?.cancel()
        _isMatchmaking.value = false
        _matchmakingElapsedSeconds.value = 0
    }

    fun createLiveRoom(
        name: String,
        category: GameCategory,
        mode: GameMode,
        maxPlayers: Int,
        isVoiceEnabled: Boolean,
        isPassword: Boolean,
        pin: String,
        roundTimerSec: Int
    ) {
        val newRoomId = "ROOM-" + (2000..9999).random()
        val room = LiveRoom(
            id = newRoomId,
            name = if (name.isBlank()) "غرفة ${_profile.value.username} 🎙️" else name,
            hostName = _profile.value.username,
            category = category,
            mode = mode,
            currentPlayers = 1,
            maxPlayers = maxPlayers,
            isVoiceEnabled = isVoiceEnabled,
            isPasswordProtected = isPassword,
            passwordPin = pin,
            region = "🇸🇦 الرياض (16ms)",
            pingMs = 16,
            isRanked = false,
            roundTimerSec = roundTimerSec,
            players = listOf(
                RoomPlayer(
                    id = "user_me",
                    name = _profile.value.username,
                    avatar = _profile.value.equippedAvatar,
                    countryFlag = "🇸🇦",
                    rankTier = _profile.value.rankTier,
                    isHost = true,
                    isReady = true,
                    isLocalUser = true,
                    isMicOn = !_voiceSettings.value.isMicMuted,
                    pingMs = 16,
                    equippedTitle = _profile.value.equippedTitle
                )
            )
        )
        _liveRooms.update { listOf(room) + it }
        _currentLiveRoom.value = room
        _currentScreen.value = GameScreen.ROOM_LOBBY
        startVoiceSimulationLoop()
    }

    fun joinLiveRoom(room: LiveRoom) {
        val userPlayer = RoomPlayer(
            id = "user_me",
            name = _profile.value.username,
            avatar = _profile.value.equippedAvatar,
            countryFlag = "🇸🇦",
            rankTier = _profile.value.rankTier,
            isHost = false,
            isReady = false,
            isLocalUser = true,
            isMicOn = !_voiceSettings.value.isMicMuted,
            pingMs = (15..35).random(),
            equippedTitle = _profile.value.equippedTitle
        )
        val updatedPlayers = (room.players.filterNot { it.isLocalUser } + userPlayer)
        val updatedRoom = room.copy(
            players = updatedPlayers,
            currentPlayers = updatedPlayers.size
        )
        _currentLiveRoom.value = updatedRoom
        _currentScreen.value = GameScreen.ROOM_LOBBY
        startVoiceSimulationLoop()
    }

    fun joinRoomByCode(code: String): Boolean {
        val cleanCode = code.trim().uppercase()
        val found = _liveRooms.value.find { it.id.equals(cleanCode, ignoreCase = true) || it.id.endsWith(cleanCode) }
        if (found != null) {
            joinLiveRoom(found)
            return true
        }
        // If not in standard list, create a dynamic live joined room
        val generatedRoom = LiveRoom(
            id = if (cleanCode.startsWith("ROOM-")) cleanCode else "ROOM-$cleanCode",
            name = "غرفة النخبة المشتركة #$cleanCode",
            hostName = "MasterChief",
            category = GameCategory.ANIME,
            mode = GameMode.FREE_FOR_ALL,
            currentPlayers = 3,
            maxPlayers = 6,
            isVoiceEnabled = true,
            players = listOf(
                RoomPlayer("p_host", "MasterChief", "👑", "🇸🇦", RankTier.MASTER, isHost = true, isReady = true, isMicOn = true, pingMs = 20),
                RoomPlayer("p_guest", "OtakuHero", "🎌", "🇰🇼", RankTier.DIAMOND, isHost = false, isReady = true, isMicOn = true, pingMs = 25)
            )
        )
        joinLiveRoom(generatedRoom)
        return true
    }

    fun joinLiveRoom(roomId: String) {
        val found = _liveRooms.value.find { it.id == roomId }
        if (found != null) {
            joinLiveRoom(found)
        } else {
            joinRoomByCode(roomId)
        }
    }

    fun leaveLiveRoom() {
        voiceSimulationJob?.cancel()
        _currentLiveRoom.value = null
        _currentScreen.value = GameScreen.LIVE_ROOMS
    }

    fun toggleRoomReady() {
        _currentLiveRoom.update { room ->
            room?.copy(
                players = room.players.map {
                    if (it.isLocalUser) it.copy(isReady = !it.isReady) else it
                }
            )
        }
    }

    fun launchRoomGame() {
        val room = _currentLiveRoom.value ?: return
        startMatchSetup(mode = room.mode, category = room.category)
    }

    fun setPlayerVolume(playerId: String, volume: Float) {
        _currentLiveRoom.update { room ->
            room?.copy(
                players = room.players.map {
                    if (it.id == playerId) it.copy(voiceVolume = volume.coerceIn(0f, 2f)) else it
                }
            )
        }
    }

    fun togglePlayerMuteInRoom(playerId: String) {
        _currentLiveRoom.update { room ->
            room?.copy(
                players = room.players.map {
                    if (it.id == playerId) it.copy(isMicOn = !it.isMicOn) else it
                }
            )
        }
    }

    fun toggleDeafen() {
        _voiceSettings.update { it.copy(isDeafened = !it.isDeafened) }
    }

    fun setPushToTalk(enabled: Boolean) {
        _voiceSettings.update { it.copy(isPushToTalk = enabled) }
    }

    fun setPushToTalkActive(active: Boolean) {
        _voiceSettings.update { it.copy(isPushToTalkActive = active) }
        _matchState.update { it.copy(isSpeaking = active) }
        _currentLiveRoom.update { room ->
            room?.copy(
                players = room.players.map {
                    if (it.isLocalUser) it.copy(isSpeaking = active, audioLevel = if (active) 0.85f else 0.0f) else it
                }
            )
        }
    }

    fun sendVoiceEmote(emote: QuickVoiceEmote) {
        // Broadcast tactical voice emote / audio cue to clue logs & player visual
        _matchState.update {
            it.copy(
                clueLogs = it.clueLogs + ClueLogItem(
                    id = UUID.randomUUID().toString(),
                    question = "${emote.emoji} ${emote.textAr}",
                    askedByPlayerName = _profile.value.username,
                    targetPlayerName = "🎙️ الغرفة الصوتية",
                    answer = AnswerType.YES,
                    timestamp = getCurrentTimeString()
                )
            )
        }
    }

    private fun updateCurrentRoomLocalPlayerMic(isOn: Boolean) {
        _currentLiveRoom.update { room ->
            room?.copy(
                players = room.players.map {
                    if (it.isLocalUser) it.copy(isMicOn = isOn) else it
                }
            )
        }
    }

    private fun startVoiceSimulationLoop() {
        voiceSimulationJob?.cancel()
        voiceSimulationJob = viewModelScope.launch {
            while (true) {
                delay((2000..4500).random().toLong())
                _currentLiveRoom.update { room ->
                    if (room == null) return@update null
                    val otherPlayers = room.players.filterNot { it.isLocalUser }
                    if (otherPlayers.isEmpty()) return@update room
                    val talkingPlayer = otherPlayers.random()
                    val speakingNow = (0..10).random() > 3 // 70% chance to speak
                    room.copy(
                        players = room.players.map { p ->
                            if (p.id == talkingPlayer.id && p.isMicOn) {
                                p.copy(
                                    isSpeaking = speakingNow,
                                    audioLevel = if (speakingNow) (0.4f + (0..50).random() / 100f) else 0f
                                )
                            } else if (!p.isLocalUser) {
                                p.copy(isSpeaking = false, audioLevel = 0f)
                            } else p
                        }
                    )
                }
            }
        }
    }

    fun reportPlayer(playerName: String, reason: String) {
        _matchState.update {
            it.copy(
                clueLogs = it.clueLogs + ClueLogItem(
                    id = UUID.randomUUID().toString(),
                    question = "تم إرسال بلاغك ضد ($playerName) بنجاح للإشراف 🛡️",
                    askedByPlayerName = "🛡️ Safety Mod",
                    targetPlayerName = "أنت",
                    answer = AnswerType.YES,
                    timestamp = getCurrentTimeString()
                )
            )
        }
    }

    private fun getCurrentTimeString(): String {
        return SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    }
}
