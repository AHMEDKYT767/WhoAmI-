package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.GameCategory
import com.example.model.GameMode
import com.example.model.LiveRoom
import com.example.ui.components.LiveVoiceWaveVisualizer
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.GameViewModel

@Composable
fun LiveRoomsScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val liveRooms by viewModel.liveRooms.collectAsState()
    val isMatchmaking by viewModel.isMatchmaking.collectAsState()
    val matchmakingSeconds by viewModel.matchmakingElapsedSeconds.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf<GameCategory?>(null) }
    var onlyVoiceChatRooms by remember { mutableStateOf(false) }

    var showCreateRoomModal by remember { mutableStateOf(false) }
    var showJoinByCodeModal by remember { mutableStateOf(false) }
    var showEnterPasswordModal by remember { mutableStateOf<LiveRoom?>(null) }

    val filteredRooms = liveRooms.filter { room ->
        val matchesQuery = room.name.contains(searchQuery, ignoreCase = true) ||
                room.category.titleAr.contains(searchQuery, ignoreCase = true) ||
                room.hostName.contains(searchQuery, ignoreCase = true)
        val matchesCategory = selectedCategoryFilter == null || room.category == selectedCategoryFilter
        val matchesVoice = !onlyVoiceChatRooms || room.isVoiceEnabled
        matchesQuery && matchesCategory && matchesVoice
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Image Banner & Online Live Counter
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(22.dp)),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.img_game_hero),
                        contentDescription = "Live Rooms Banner",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, DarkBg.copy(alpha = 0.92f))
                                )
                            )
                            .padding(14.dp),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = EmeraldGreen.copy(alpha = 0.2f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldGreen)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(7.dp)
                                                .clip(CircleShape)
                                                .background(EmeraldGreen)
                                        )
                                        Text(
                                            text = "1,420 لاعب حقيقي متصل الآن",
                                            color = EmeraldGreen,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "🌐 غرف اللعب المباشرة والمايك الحي",
                                    color = TextPrimary,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }

                            LiveVoiceWaveVisualizer(
                                isActive = true,
                                barColor = ElectricCyan,
                                barCount = 5
                            )
                        }
                    }
                }
            }
        }

        // Quick Action Buttons (Quick Match, Create Room, Enter Code)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Quick Match Button
                Button(
                    onClick = { viewModel.startQuickMatch() },
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp)
                        .testTag("btn_quick_match"),
                    colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Quick Match",
                        tint = DarkBg,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "مباراة سريعة ⚡",
                        color = DarkBg,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp
                    )
                }

                // Create Custom Room
                Button(
                    onClick = { showCreateRoomModal = true },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("btn_create_room"),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHighlight),
                    border = androidx.compose.foundation.BorderStroke(1.dp, NeonPurple.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Create",
                        tint = TextPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "إنشاء غرفة 🎙️",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }

                // Join with PIN code
                IconButton(
                    onClick = { showJoinByCodeModal = true },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkSurfaceHighlight)
                        .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .testTag("btn_join_code")
                ) {
                    Icon(
                        imageVector = Icons.Default.Key,
                        contentDescription = "Enter Code",
                        tint = CyberGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Search Bar & Open Mic filter toggle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("ابحث عن اسم الغرفة أو المضيف...", color = TextMuted, fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = ElectricCyan,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = DarkSurfaceVariant,
                        unfocusedContainerColor = DarkSurfaceVariant,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedIndicatorColor = ElectricCyan,
                        unfocusedIndicatorColor = DarkSurfaceHighlight
                    ),
                    singleLine = true
                )

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (onlyVoiceChatRooms) EmeraldGreen.copy(alpha = 0.2f) else DarkSurfaceVariant,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (onlyVoiceChatRooms) EmeraldGreen else DarkSurfaceHighlight
                    ),
                    modifier = Modifier
                        .height(50.dp)
                        .clickable { onlyVoiceChatRooms = !onlyVoiceChatRooms }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice",
                            tint = if (onlyVoiceChatRooms) EmeraldGreen else TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "مايك فقط",
                            color = if (onlyVoiceChatRooms) EmeraldGreen else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Category Filter Chips Row
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    CategoryChip(
                        title = "الكل",
                        emoji = "✨",
                        isSelected = selectedCategoryFilter == null,
                        onClick = { selectedCategoryFilter = null }
                    )
                }
                items(GameCategory.values()) { cat ->
                    CategoryChip(
                        title = cat.titleAr,
                        emoji = cat.emoji,
                        isSelected = selectedCategoryFilter == cat,
                        onClick = { selectedCategoryFilter = cat }
                    )
                }
            }
        }

        // Live Rooms List Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الغرف المتاحة حالياً (${filteredRooms.size})",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "تحديث حي 🟢",
                    color = EmeraldGreen,
                    fontSize = 11.sp
                )
            }
        }

        // Rooms Items
        items(filteredRooms) { room ->
            LiveRoomItemCard(
                room = room,
                onJoin = {
                    if (room.isPasswordProtected) {
                        showEnterPasswordModal = room
                    } else {
                        viewModel.joinLiveRoom(room)
                    }
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // Matchmaking Progress Modal
    if (isMatchmaking) {
        MatchmakingProgressDialog(
            elapsedSeconds = matchmakingSeconds,
            onCancel = { viewModel.cancelMatchmaking() }
        )
    }

    // Create Room Modal
    if (showCreateRoomModal) {
        CreateRoomDialog(
            onDismiss = { showCreateRoomModal = false },
            onCreate = { name, cat, mode, maxPlayers, isVoice, isPass, pin, timer ->
                viewModel.createLiveRoom(name, cat, mode, maxPlayers, isVoice, isPass, pin, timer)
                showCreateRoomModal = false
            }
        )
    }

    // Join with Code Dialog
    if (showJoinByCodeModal) {
        JoinByCodeDialog(
            onDismiss = { showJoinByCodeModal = false },
            onJoin = { code ->
                val success = viewModel.joinRoomByCode(code)
                if (success) {
                    showJoinByCodeModal = false
                }
            }
        )
    }

    // Enter Room PIN Dialog
    if (showEnterPasswordModal != null) {
        val targetRoom = showEnterPasswordModal!!
        EnterRoomPinDialog(
            room = targetRoom,
            onDismiss = { showEnterPasswordModal = null },
            onConfirmPin = { enteredPin ->
                if (enteredPin == targetRoom.passwordPin) {
                    viewModel.joinLiveRoom(targetRoom)
                    showEnterPasswordModal = null
                }
            }
        )
    }
}

@Composable
fun LiveRoomItemCard(
    room: LiveRoom,
    onJoin: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable { onJoin() }
            .border(1.dp, NeonPurple.copy(alpha = 0.4f), RoundedCornerShape(18.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Room Title & Mode
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = room.category.emoji, fontSize = 22.sp)
                    Column {
                        Text(
                            text = room.name,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "المضيف: ${room.hostName} • ${room.region}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                // Mode Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkSurfaceHighlight,
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, ElectricCyan.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "${room.mode.icon} ${room.mode.titleAr}",
                        color = ElectricCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            // Players in Room Avatars & Live Speaking Waves
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Players Avatars Row
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    room.players.take(5).forEach { player ->
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(DarkSurfaceHighlight)
                                .border(
                                    1.dp,
                                    if (player.isSpeaking) EmeraldGreen else NeonPurple.copy(alpha = 0.5f),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = player.avatar, fontSize = 16.sp)
                        }
                    }

                    if (room.players.size < room.maxPlayers) {
                        Surface(
                            shape = CircleShape,
                            color = DarkSurfaceHighlight,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "+${room.maxPlayers - room.players.size}",
                                    color = TextMuted,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = "${room.players.size}/${room.maxPlayers} لاعبين",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Voice Indicator & Join Button
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (room.isVoiceEnabled) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = EmeraldGreen.copy(alpha = 0.15f)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Mic On",
                                    tint = EmeraldGreen,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "مايك حي",
                                    color = EmeraldGreen,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    if (room.isPasswordProtected) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Private",
                            tint = CyberGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Button(
                        onClick = onJoin,
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "انضمام 🚀",
                            color = DarkBg,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryChip(
    title: String,
    emoji: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (isSelected) ElectricCyan else DarkSurfaceHighlight,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) ElectricCyan else DarkSurfaceHighlight
        ),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = emoji, fontSize = 14.sp)
            Text(
                text = title,
                color = if (isSelected) DarkBg else TextPrimary,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
fun MatchmakingProgressDialog(
    elapsedSeconds: Int,
    onCancel: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val radarScale = infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(animation = tween(1000), repeatMode = RepeatMode.Reverse),
        label = "radar_scale"
    ).value

    AlertDialog(
        onDismissRequest = onCancel,
        title = {
            Text(
                text = "⚡ جاري البحث عن لاعبين حقيقيين...",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .scale(radarScale),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(ElectricCyan.copy(alpha = 0.15f))
                            .border(2.dp, ElectricCyan, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            color = ElectricCyan,
                            modifier = Modifier.size(50.dp),
                            strokeWidth = 3.dp
                        )
                        Text(text = "🎙️", fontSize = 24.sp)
                    }
                }

                Text(
                    text = "وقت البحث: 00:0$elapsedSeconds ثانية",
                    color = ElectricCyan,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "خوادم الشرق الأوسط (الرياض • دبي • القاهرة) | بنج 22ms",
                    color = TextMuted,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onCancel,
                colors = ButtonDefaults.buttonColors(containerColor = HotPink),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("إلغاء البحث", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = DarkSurface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun CreateRoomDialog(
    onDismiss: () -> Unit,
    onCreate: (String, GameCategory, GameMode, Int, Boolean, Boolean, String, Int) -> Unit
) {
    var roomName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(GameCategory.ANIME) }
    var selectedMode by remember { mutableStateOf(GameMode.FREE_FOR_ALL) }
    var maxPlayers by remember { mutableStateOf(6) }
    var isVoiceEnabled by remember { mutableStateOf(true) }
    var isPasswordProtected by remember { mutableStateOf(false) }
    var pinCode by remember { mutableStateOf("") }
    var timerSec by remember { mutableStateOf(60) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = "🎙️", fontSize = 22.sp)
                Text(
                    text = "إنشاء غرفة صوتية مخصصة",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Room Name
                OutlinedTextField(
                    value = roomName,
                    onValueChange = { roomName = it },
                    placeholder = { Text("اسم الغرفة (مثال: أبطال الأنمي 🎌)", color = TextMuted, fontSize = 12.sp) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = DarkSurfaceHighlight,
                        unfocusedContainerColor = DarkSurfaceHighlight,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    singleLine = true
                )

                // Category Selector
                Text(text = "اختر قسم الشخصيات:", color = TextSecondary, fontSize = 11.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(GameCategory.values()) { cat ->
                        CategoryChip(
                            title = cat.titleAr,
                            emoji = cat.emoji,
                            isSelected = selectedCategory == cat,
                            onClick = { selectedCategory = cat }
                        )
                    }
                }

                // Mode Selector
                Text(text = "نمط اللعب:", color = TextSecondary, fontSize = 11.sp)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(listOf(GameMode.ONE_V_ONE, GameMode.FREE_FOR_ALL, GameMode.TEAMS, GameMode.PARTY)) { mode ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedMode == mode) ElectricCyan else DarkSurfaceHighlight,
                            modifier = Modifier.clickable { selectedMode = mode }
                        ) {
                            Text(
                                text = "${mode.icon} ${mode.titleAr}",
                                color = if (selectedMode == mode) DarkBg else TextPrimary,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                            )
                        }
                    }
                }

                // Voice Chat Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "تفعيل الدردشة الصوتية بالمايك 🎙️", color = TextPrimary, fontSize = 12.sp)
                    Switch(
                        checked = isVoiceEnabled,
                        onCheckedChange = { isVoiceEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = EmeraldGreen)
                    )
                }

                // Password Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "غرفة خاصة برمز سري 🔒", color = TextPrimary, fontSize = 12.sp)
                    Switch(
                        checked = isPasswordProtected,
                        onCheckedChange = { isPasswordProtected = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = CyberGold)
                    )
                }

                if (isPasswordProtected) {
                    OutlinedTextField(
                        value = pinCode,
                        onValueChange = { pinCode = it },
                        placeholder = { Text("أدخل رمز الغرفة السري (مثال: 1234)", color = TextMuted, fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onCreate(roomName, selectedCategory, selectedMode, maxPlayers, isVoiceEnabled, isPasswordProtected, pinCode, timerSec)
                },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
            ) {
                Text("إنشاء ودخول الصالة 🚀", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHighlight)
            ) {
                Text("إلغاء", color = TextPrimary)
            }
        },
        containerColor = DarkSurface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun JoinByCodeDialog(
    onDismiss: () -> Unit,
    onJoin: (String) -> Unit
) {
    var code by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = "🔑", fontSize = 22.sp)
                Text(
                    text = "الانضمام برمز الغرفة",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "أدخل رمز الغرفة المشترك (مثال: ROOM-7701 أو 7701):",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    placeholder = { Text("رمز الغرفة...", color = TextMuted) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onJoin(code) },
                enabled = code.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
            ) {
                Text("دخول الغرفة", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHighlight)
            ) {
                Text("إلغاء", color = TextPrimary)
            }
        },
        containerColor = DarkSurface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun EnterRoomPinDialog(
    room: LiveRoom,
    onDismiss: () -> Unit,
    onConfirmPin: (String) -> Unit
) {
    var pin by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "🔒 غرفة محمية برمز سري",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "غرفة (${room.name}) تتطلب رمز PIN للدخول:",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it },
                    placeholder = { Text("PIN...", color = TextMuted) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmPin(pin) },
                colors = ButtonDefaults.buttonColors(containerColor = CyberGold)
            ) {
                Text("تأكيد ودخول", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHighlight)
            ) {
                Text("إلغاء", color = TextPrimary)
            }
        },
        containerColor = DarkSurface,
        shape = RoundedCornerShape(20.dp)
    )
}
