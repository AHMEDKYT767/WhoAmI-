package com.example.model

enum class Difficulty(val stars: Int, val labelEn: String, val labelAr: String, val multiplier: Float) {
    EASY(1, "Easy", "سهل ⭐", 1.0f),
    NORMAL(2, "Normal", "متوسط ⭐⭐", 1.25f),
    HARD(3, "Hard", "صعب ⭐⭐⭐", 1.5f),
    EXPERT(4, "Expert", "خبير ⭐⭐⭐⭐", 2.0f),
    IMPOSSIBLE(5, "Impossible", "مستحيل ⭐⭐⭐⭐⭐", 3.0f)
}

enum class GameCategory(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val emoji: String,
    val description: String
) {
    ANIME("anime", "Anime", "أنمي", "🎌", "Naruto, Luffy, Levi, Goku & legendary characters"),
    FOOTBALL("football", "Football", "كرة القدم", "⚽", "Messi, Ronaldo, Zidane, Mbappe & icons"),
    SPORTS("sports", "Sports", "رياضات عامة", "🏀", "Jordan, LeBron, Federer, Bolt & champions"),
    VIDEO_GAMES("games", "Video Games", "ألعاب الفيديو", "🎮", "Kratos, Mario, Link, Geralt & heroes"),
    CARTOONS("cartoons", "Cartoons", "رسوم متحركة", "🐭", "SpongeBob, Mickey, Tom, Bugs Bunny & classics"),
    SUPERHEROES("superheroes", "Superheroes", "أبطال خارقين", "🦸", "Batman, Spider-Man, Iron Man & villains"),
    MOVIES_SERIES("movies", "Movies & Series", "أفلام ومسلسلات", "🎬", "Walter White, Sherlock, Jack Sparrow"),
    HISTORICAL("history", "History", "شخصيات تاريخية", "🏛️", "Einstein, Da Vinci, Alexander, Napoleon"),
    CREATURES("creatures", "Creatures & Myth", "مخلوقات وأساطير", "🐉", "Godzilla, Pikachu, Phoenix, Dragons"),
    CARS("cars", "Cars & Supercars", "سيارات ومحركات", "🚗", "Ferrari Enzo, Bugatti, Mustang, GTR")
}

data class Character(
    val id: String,
    val name: String,
    val nameAr: String,
    val category: GameCategory,
    val difficulty: Difficulty,
    val origin: String,
    val hints: List<String>,
    val tags: List<String>,
    val description: String,
    val isMale: Boolean = true,
    val isRealPerson: Boolean = false,
    val usesWeaponsOrPowers: Boolean = true,
    val eraOrGenre: String = "Modern"
) {
    val nameEn: String get() = name
    val emoji: String get() = tags.firstOrNull { it.any { char -> char.isSurrogate() || char.code > 1000 } } ?: when (category) {
        GameCategory.ANIME -> "⚡"
        GameCategory.FOOTBALL -> "⚽"
        GameCategory.SPORTS -> "🏀"
        GameCategory.VIDEO_GAMES -> "🎮"
        GameCategory.CARTOONS -> "🐭"
        GameCategory.SUPERHEROES -> "🦸"
        GameCategory.MOVIES_SERIES -> "🎬"
        GameCategory.HISTORICAL -> "🏛️"
        GameCategory.CREATURES -> "🐉"
        GameCategory.CARS -> "🚗"
    }
    val gender: String get() = if (isMale) "Male" else "Female"
}

enum class GameMode(
    val id: String,
    val titleEn: String,
    val titleAr: String,
    val icon: String,
    val desc: String,
    val minPlayers: Int,
    val maxPlayers: Int
) {
    ONE_V_ONE("1v1", "1v1 Duel", "مبارزة 1 ضد 1", "⚔️", "Fast tactical duel against an opponent or AI Game Master", 2, 2),
    FREE_FOR_ALL("ffa", "Free For All", "الكل ضد الكل", "👑", "3 to 8 players race to guess everyone's secret character", 3, 8),
    TEAMS("teams", "Teams 2v2", "فرق 2 ضد 2", "🟦", "Team up, collaborate on clues, and outsmart rivals", 4, 4),
    PARTY("party", "Party Mode", "وضع الحفلة", "🎉", "Crazy modifiers, rapid speed rounds & wild hints", 2, 8),
    RANKED("ranked", "Ranked Ladder", "المباراة المصنفة", "🏆", "Competitive ladder matches affecting your global rank", 2, 4),
    CUSTOM_ROOM("custom", "Custom Room", "غرفة مخصصة", "🏠", "Host private rooms with custom timers, rules & bans", 2, 8),
    TOURNAMENT("tournament", "64 Tournament", "بطولة 64 لاعب", "🏟️", "Single elimination bracket to become the Grand Champion", 2, 64)
}

enum class PowerCardType(
    val titleEn: String,
    val titleAr: String,
    val icon: String,
    val descAr: String,
    val costCoins: Int
) {
    DETECTIVE("Detective", "كاشف الأدلة", "🔍", "يكشف خاصية سرية مؤكدة عن شخصية الخصم", 30),
    REVEAL("Reveal", "رؤية خاطفة", "👁️", "يستبعد شخصيتين مستحيلتين فوراً من قائمتك", 40),
    TIME_BOOST("Time Boost", "تمديد الوقت", "⏳", "يضيف +20 ثانية إضافية للجولة الحاسمة", 25),
    DOUBLE_GUESS("Double Guess", "تخمين مزدوج", "🎯", "محاولة تخمين إضافية بدون تطبيق عقوبة الخطأ", 50),
    WILD_QUESTION("Wild Clue", "سؤال جوكر", "🃏", "إجابة مضمونة من AI Game Master بدون استهلاك دور", 35)
}

enum class AnswerType(val labelEn: String, val labelAr: String, val emoji: String) {
    YES("YES", "نعم", "✅"),
    NO("NO", "لا", "❌"),
    MAYBE("MAYBE / PARTLY", "ربما / جزئياً", "🤔")
}

data class ClueLogItem(
    val id: String,
    val question: String,
    val askedByPlayerName: String,
    val targetPlayerName: String,
    val answer: AnswerType,
    val timestamp: String,
    val note: String = ""
)

data class Player(
    val id: String,
    val name: String,
    val isLocalUser: Boolean = false,
    val isAi: Boolean = false,
    val secretCharacter: Character? = null,
    val score: Int = 0,
    val isGuessed: Boolean = false,
    val isMuted: Boolean = false,
    val isTalking: Boolean = false,
    val rankTitle: String = "Diamond",
    val avatarEmoji: String = "🦊",
    val guessedCorrectlyCount: Int = 0,
    val strikesLeft: Int = 3
)

enum class RankTier(
    val tierNameEn: String,
    val tierNameAr: String,
    val minPoints: Int,
    val badgeIcon: String,
    val hexColor: Long
) {
    BRONZE("Bronze", "برونزي", 0, "🥉", 0xFFCD7F32),
    SILVER("Silver", "فضي", 300, "🥈", 0xFFC0C0C0),
    GOLD("Gold", "ذهبي", 700, "🥇", 0xFFFFD700),
    PLATINUM("Platinum", "بلاتينيوم", 1200, "💎", 0xFF00E5FF),
    DIAMOND("Diamond", "ماسي", 1800, "💠", 0xFFB9F2FF),
    MASTER("Master", "ماستر", 2500, "🔮", 0xFFFF007F),
    GRANDMASTER("Grandmaster", "جراند ماستر", 3400, "👑", 0xFFFF3D00),
    LEGEND("Legend", "أسطوري", 4500, "🌟", 0xFFFFD700);

    val titleEn: String get() = tierNameEn
    val titleAr: String get() = tierNameAr
    val emoji: String get() = badgeIcon
}

data class DailyQuest(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val current: Int,
    val target: Int,
    val rewardCoins: Int,
    val rewardXp: Int,
    val isClaimed: Boolean = false
)

data class CommunityPack(
    val id: String,
    val title: String,
    val author: String,
    val category: GameCategory,
    val characterCount: Int,
    val likes: Int,
    val rating: Float,
    val difficulty: Difficulty,
    val description: String,
    val sampleCharacters: List<String>,
    val isVerified: Boolean = true
)

enum class ShopItemType(val titleAr: String, val icon: String) {
    FRAME("إطار الملف", "🖼️"),
    AVATAR("رمز شخصي", "🎭"),
    TITLE("لقب أسطوري", "🏷️"),
    EFFECT("تأثير الفوز", "✨"),
    BOARD_THEME("ثيم اللوحة", "🎨")
}

data class ShopItem(
    val id: String,
    val name: String,
    val type: ShopItemType,
    val priceCoins: Int,
    val previewValue: String,
    val isPurchased: Boolean = false,
    val isEquipped: Boolean = false
) {
    val nameAr: String get() = name
    val description: String get() = "${type.titleAr}: $name"
    val icon: String get() = previewValue
    val isUnlocked: Boolean get() = isPurchased
}

data class TournamentNode(
    val id: String,
    val roundName: String,
    val player1Name: String,
    val player2Name: String,
    val score1: Int = 0,
    val score2: Int = 0,
    val winnerName: String? = null,
    val isCompleted: Boolean = false
)

data class LeaderboardEntry(
    val rank: Int,
    val username: String,
    val countryFlag: String,
    val avatar: String,
    val tier: RankTier,
    val points: Int,
    val winStreak: Int,
    val accuracyRate: Int
)

data class RoomPlayer(
    val id: String,
    val name: String,
    val avatar: String = "🦊",
    val countryFlag: String = "🇸🇦",
    val rankTier: RankTier = RankTier.DIAMOND,
    val isHost: Boolean = false,
    val isReady: Boolean = false,
    val isLocalUser: Boolean = false,
    val isMicOn: Boolean = true,
    val isDeafened: Boolean = false,
    val isSpeaking: Boolean = false,
    val voiceVolume: Float = 1.0f,
    val audioLevel: Float = 0.0f,
    val pingMs: Int = 28,
    val equippedTitle: String = "مستنتج أسطوري",
    val score: Int = 0
)

data class LiveRoom(
    val id: String,
    val name: String,
    val hostName: String,
    val category: GameCategory,
    val mode: GameMode,
    val currentPlayers: Int,
    val maxPlayers: Int,
    val isVoiceEnabled: Boolean = true,
    val isPasswordProtected: Boolean = false,
    val passwordPin: String = "",
    val region: String = "🇸🇦 الرياض (24ms)",
    val pingMs: Int = 24,
    val isRanked: Boolean = false,
    val roundTimerSec: Int = 60,
    val players: List<RoomPlayer> = emptyList()
)

data class QuickVoiceEmote(
    val id: String,
    val textAr: String,
    val emoji: String,
    val category: String = "tactical"
)

data class VoiceChatSettings(
    val isMicMuted: Boolean = false,
    val isDeafened: Boolean = false,
    val isPushToTalk: Boolean = false,
    val isPushToTalkActive: Boolean = false,
    val micInputLevel: Float = 0.8f,
    val roomOutputVolume: Float = 1.0f,
    val isNoiseSuppressionEnabled: Boolean = true,
    val isEchoCancellationEnabled: Boolean = true
)
