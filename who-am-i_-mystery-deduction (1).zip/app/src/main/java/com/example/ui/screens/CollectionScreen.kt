package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameDataRepository
import com.example.model.Character
import com.example.model.GameCategory
import com.example.ui.theme.BorderGlow
import com.example.ui.theme.CyanBlue
import com.example.ui.theme.CyberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.GameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CollectionScreen(
    viewModel: GameViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.profile.collectAsState()
    var selectedCategory by remember { mutableStateOf<GameCategory?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var inspectedCharacter by remember { mutableStateOf<Character?>(null) }

    val allChars = GameDataRepository.allCharacters
    val filteredChars = remember(selectedCategory, searchQuery) {
        allChars.filter { char ->
            val matchesCategory = selectedCategory == null || char.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                    char.nameEn.contains(searchQuery, ignoreCase = true) ||
                    char.nameAr.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }
    }

    val unlockedCount = allChars.count { profile.unlockedCharacterIds.contains(it.id) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBg)
            .padding(16.dp)
    ) {
        // 1. Header & Progress: 73 / 250
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "COLLECTION",
                    color = TextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Characters Album",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = ElectricPurple.copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, ElectricPurple.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = "🎴", fontSize = 13.sp)
                    Text(
                        text = "$unlockedCount / ${allChars.size}",
                        color = ElectricPurple,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 2. Search Bar: 🔎 Search characters...
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search characters...", color = TextMuted, fontSize = 13.sp) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = TextSecondary,
                    modifier = Modifier.size(18.dp)
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            shape = RoundedCornerShape(14.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.7f),
                unfocusedContainerColor = DarkSurfaceVariant.copy(alpha = 0.7f),
                focusedBorderColor = ElectricPurple,
                unfocusedBorderColor = BorderGlow,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 3. Category Tabs: All, Anime, Football, Games, Cartoons, Movies, etc.
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                val isAll = selectedCategory == null
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { selectedCategory = null }
                        .border(
                            1.dp,
                            if (isAll) ElectricPurple else BorderGlow,
                            RoundedCornerShape(10.dp)
                        ),
                    color = if (isAll) ElectricPurple.copy(alpha = 0.2f) else DarkSurfaceVariant.copy(alpha = 0.6f)
                ) {
                    Text(
                        text = "All",
                        color = if (isAll) ElectricPurple else TextSecondary,
                        fontSize = 12.sp,
                        fontWeight = if (isAll) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp)
                    )
                }
            }

            items(GameCategory.values()) { cat ->
                val isSelected = selectedCategory == cat
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { selectedCategory = cat }
                        .border(
                            1.dp,
                            if (isSelected) ElectricPurple else BorderGlow,
                            RoundedCornerShape(10.dp)
                        ),
                    color = if (isSelected) ElectricPurple.copy(alpha = 0.2f) else DarkSurfaceVariant.copy(alpha = 0.6f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(text = cat.emoji, fontSize = 13.sp)
                        Text(
                            text = cat.titleEn,
                            color = if (isSelected) ElectricPurple else TextSecondary,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 4. Character Cards Grid (Visual cards with unlocked/locked state)
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(filteredChars) { character ->
                val isUnlocked = profile.unlockedCharacterIds.contains(character.id)
                CharacterCollectionCard(
                    character = character,
                    isUnlocked = isUnlocked,
                    onClick = { inspectedCharacter = character }
                )
            }
        }
    }

    // 5. Character Detail BottomSheet
    inspectedCharacter?.let { character ->
        val isUnlocked = profile.unlockedCharacterIds.contains(character.id)
        ModalBottomSheet(
            onDismissRequest = { inspectedCharacter = null },
            containerColor = DarkSurfaceVariant,
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .padding(bottom = 28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Large Character Image
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceHighlight)
                        .border(2.dp, if (isUnlocked) ElectricPurple else BorderGlow, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = character.emoji,
                        fontSize = 46.sp,
                        modifier = Modifier.alpha(if (isUnlocked) 1f else 0.4f)
                    )
                    if (!isUnlocked) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Locked",
                                tint = TextSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = character.nameEn,
                    color = TextPrimary,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )

                Text(
                    text = character.nameAr,
                    color = TextSecondary,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category & Difficulty Badges
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceHighlight
                    ) {
                        Text(
                            text = "${character.category.emoji} ${character.category.titleEn}",
                            color = CyanBlue,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = when (character.difficulty) {
                            com.example.model.Difficulty.EASY -> EmeraldGreen.copy(alpha = 0.2f)
                            com.example.model.Difficulty.NORMAL -> CyberGold.copy(alpha = 0.2f)
                            com.example.model.Difficulty.HARD -> HotPink.copy(alpha = 0.2f)
                            com.example.model.Difficulty.EXPERT, com.example.model.Difficulty.IMPOSSIBLE -> ElectricPurple.copy(alpha = 0.2f)
                        }
                    ) {
                        Text(
                            text = character.difficulty.name,
                            color = when (character.difficulty) {
                                com.example.model.Difficulty.EASY -> EmeraldGreen
                                com.example.model.Difficulty.NORMAL -> CyberGold
                                com.example.model.Difficulty.HARD -> HotPink
                                com.example.model.Difficulty.EXPERT, com.example.model.Difficulty.IMPOSSIBLE -> ElectricPurple
                            },
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Unlock Status Card
                if (!isUnlocked) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, BorderGlow, RoundedCornerShape(14.dp)),
                        color = DarkSurface
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Locked",
                                    tint = CyberGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "LOCKED",
                                    color = CyberGold,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Win 10 ${character.category.titleEn} matches to unlock",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Progress: 7 / 10",
                                color = CyanBlue,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .border(1.dp, EmeraldGreen.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                        color = DarkSurface
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "✓ UNLOCKED",
                                color = EmeraldGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Character is unlocked and available in all competitive modes!",
                                color = TextSecondary,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Character Traits
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, BorderGlow, RoundedCornerShape(14.dp)),
                    color = DarkSurface
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "GUESSING TRAITS",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Gender: ${character.gender}", color = TextSecondary, fontSize = 11.sp)
                            Text(text = "Origin: ${character.origin}", color = TextSecondary, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CharacterCollectionCard(
    character: Character,
    isUnlocked: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .border(
                1.dp,
                if (isUnlocked) BorderGlow else BorderGlow.copy(alpha = 0.5f),
                RoundedCornerShape(14.dp)
            )
            .testTag("collection_card_${character.id}"),
        color = DarkSurfaceVariant.copy(alpha = if (isUnlocked) 0.8f else 0.4f)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceHighlight),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = character.emoji,
                    fontSize = 28.sp,
                    modifier = Modifier.alpha(if (isUnlocked) 1f else 0.3f)
                )
                if (!isUnlocked) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = character.nameEn,
                color = if (isUnlocked) TextPrimary else TextMuted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )

            Text(
                text = character.difficulty.name,
                color = if (isUnlocked) CyanBlue else TextMuted,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
