package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Dark futuristic / modern gaming palette
val DarkBg = Color(0xFF080B14)
val DarkSurface = Color(0xFF101526)
val DarkSurfaceVariant = Color(0xFF161D33)
val DarkSurfaceHighlight = Color(0xFF202945)

val ElectricPurple = Color(0xFF7C5CFF)
val NeonPurple = Color(0xFF7C5CFF)
val RadiantViolet = Color(0xFF6D48E5)
val CyanBlue = Color(0xFF38BDF8)
val ElectricCyan = Color(0xFF38BDF8)

val EmeraldGreen = Color(0xFF22C55E)
val WarningAmber = Color(0xFFF59E0B)
val DangerRed = Color(0xFFEF4444)
val HotPink = Color(0xFFEC4899)
val CyberGold = Color(0xFFFBBF24)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextDisabled = Color(0xFF475569)

val BorderGlow = Color(0xFF202945)
val CardOverlay = Color(0x33000000)

// Rank Colors
val RankBronze = Color(0xFFCD7F32)
val RankSilver = Color(0xFFC0C0C0)
val RankGold = Color(0xFFFFD700)
val RankPlatinum = Color(0xFF38BDF8)
val RankDiamond = Color(0xFF7C5CFF)
val RankMaster = Color(0xFFEC4899)
val RankGrandmaster = Color(0xFFEF4444)
val RankLegend = Color(0xFFFBBF24)

