package com.example.data.audio

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

data class VoiceAudioState(
    val isRecording: Boolean = false,
    val isMuted: Boolean = false,
    val isDeafened: Boolean = false,
    val audioLevel: Float = 0f, // 0.0 to 1.0
    val isSpeaking: Boolean = false,
    val hasRecordPermission: Boolean = false
)

class VoiceChatManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val _audioState = MutableStateFlow(VoiceAudioState())
    val audioState: StateFlow<VoiceAudioState> = _audioState.asStateFlow()

    private var audioRecord: AudioRecord? = null
    private var recordJob: Job? = null

    private val sampleRate = 16000
    private val channelConfig = AudioFormat.CHANNEL_IN_MONO
    private val audioFormat = AudioFormat.ENCODING_PCM_16BIT

    fun setHasPermission(hasPermission: Boolean) {
        _audioState.value = _audioState.value.copy(hasRecordPermission = hasPermission)
        if (hasPermission && !_audioState.value.isMuted) {
            startAudioLevelMonitoring()
        }
    }

    fun setMuted(muted: Boolean) {
        _audioState.value = _audioState.value.copy(isMuted = muted)
        if (muted) {
            stopAudioLevelMonitoring()
            _audioState.value = _audioState.value.copy(audioLevel = 0f, isSpeaking = false)
        } else if (_audioState.value.hasRecordPermission) {
            startAudioLevelMonitoring()
        }
    }

    fun setDeafened(deafened: Boolean) {
        _audioState.value = _audioState.value.copy(isDeafened = deafened)
    }

    fun startAudioLevelMonitoring() {
        if (recordJob?.isActive == true) return
        if (!_audioState.value.hasRecordPermission || _audioState.value.isMuted) return

        recordJob = scope.launch(Dispatchers.IO) {
            val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            if (minBufferSize <= 0) return@launch

            try {
                audioRecord = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    channelConfig,
                    audioFormat,
                    minBufferSize
                )

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    return@launch
                }

                audioRecord?.startRecording()
                _audioState.value = _audioState.value.copy(isRecording = true)

                val buffer = ShortArray(minBufferSize)
                while (isActive && !_audioState.value.isMuted) {
                    val readCount = audioRecord?.read(buffer, 0, minBufferSize) ?: 0
                    if (readCount > 0) {
                        var sum = 0L
                        for (i in 0 until readCount) {
                            sum += abs(buffer[i].toInt())
                        }
                        val avg = (sum.toFloat() / readCount)
                        val normalized = (avg / 32767f).coerceIn(0f, 1f)
                        val isTalking = normalized > 0.05f

                        _audioState.value = _audioState.value.copy(
                            audioLevel = normalized,
                            isSpeaking = isTalking
                        )
                    }
                }
            } catch (_: SecurityException) {
                _audioState.value = _audioState.value.copy(hasRecordPermission = false)
            } catch (_: Exception) {
                // Ignore audio record errors gracefully
            } finally {
                try {
                    audioRecord?.stop()
                    audioRecord?.release()
                } catch (_: Exception) {}
                audioRecord = null
                _audioState.value = _audioState.value.copy(isRecording = false, audioLevel = 0f, isSpeaking = false)
            }
        }
    }

    fun stopAudioLevelMonitoring() {
        recordJob?.cancel()
        recordJob = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null
        _audioState.value = _audioState.value.copy(isRecording = false, audioLevel = 0f, isSpeaking = false)
    }
}
