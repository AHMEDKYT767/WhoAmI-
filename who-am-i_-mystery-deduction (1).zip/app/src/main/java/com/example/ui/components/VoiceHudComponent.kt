package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.SettingsVoice
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Player
import com.example.model.QuickVoiceEmote
import com.example.model.RoomPlayer
import com.example.model.VoiceChatSettings
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.HotPink
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber

@Composable
fun LiveVoiceWaveVisualizer(
    isActive: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = EmeraldGreen,
    barCount: Int = 5
) {
    val infiniteTransition = rememberInfiniteTransition(label = "voice_wave")
    val heights = (0 until barCount).map { index ->
        if (isActive) {
            infiniteTransition.animateFloat(
                initialValue = 0.2f,
                targetValue = 1.0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 250 + index * 60),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "bar_$index"
            ).value
        } else {
            0.15f
        }
    }

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        heights.forEach { h ->
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height((h * 20).dp.coerceAtLeast(4.dp))
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (isActive) barColor else TextMuted.copy(alpha = 0.4f))
            )
        }
    }
}

@Composable
fun InGameVoiceHud(
    isMicMuted: Boolean,
    isSpeaking: Boolean,
    activeSpeakerName: String?,
    onToggleMic: () -> Unit,
    onPushToTalkPress: (Boolean) -> Unit,
    onOpenVoiceSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp),
        shape = RoundedCornerShape(18.dp),
        color = DarkSurfaceVariant.copy(alpha = 0.92f),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSpeaking) EmeraldGreen else NeonPurple.copy(alpha = 0.5f)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Speaker Info / Active Voice Status
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LiveVoiceWaveVisualizer(
                    isActive = isSpeaking || activeSpeakerName != null,
                    barColor = if (isSpeaking) EmeraldGreen else ElectricCyan
                )

                Column {
                    Text(
                        text = if (isSpeaking) "أنت تتحدث الآن 🎙️"
                        else if (activeSpeakerName != null) "$activeSpeakerName يتحدث..."
                        else if (isMicMuted) "المايك مغلق (Muted)"
                        else "المايك جاهز (Open Mic)",
                        color = if (isSpeaking) EmeraldGreen else if (isMicMuted) WarningAmber else TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "صوت نقي 3D مع عزل الضوضاء 🛡️",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            // Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Push-to-Talk Hold button
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSpeaking) EmeraldGreen else DarkSurfaceHighlight)
                        .border(
                            1.dp,
                            if (isSpeaking) EmeraldGreen else ElectricCyan.copy(alpha = 0.5f),
                            RoundedCornerShape(12.dp)
                        )
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = {
                                    onPushToTalkPress(true)
                                    tryAwaitRelease()
                                    onPushToTalkPress(false)
                                }
                            )
                        }
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = "Push to Talk",
                            tint = if (isSpeaking) DarkBg else ElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = if (isSpeaking) "تحدث الآن" else "اضغط للتحدث",
                            color = if (isSpeaking) DarkBg else TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Mic Mute Toggle
                IconButton(
                    onClick = onToggleMic,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isMicMuted) WarningAmber.copy(alpha = 0.2f) else EmeraldGreen.copy(alpha = 0.2f))
                        .border(
                            1.dp,
                            if (isMicMuted) WarningAmber else EmeraldGreen,
                            CircleShape
                        )
                        .testTag("btn_toggle_mic")
                ) {
                    Icon(
                        imageVector = if (isMicMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute Toggle",
                        tint = if (isMicMuted) WarningAmber else EmeraldGreen,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Voice Settings
                IconButton(
                    onClick = onOpenVoiceSettings,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceHighlight)
                ) {
                    Icon(
                        imageVector = Icons.Default.SettingsVoice,
                        contentDescription = "Voice Settings",
                        tint = ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun VoiceSettingsDialog(
    settings: VoiceChatSettings,
    onDismiss: () -> Unit,
    onToggleDeafen: () -> Unit,
    onTogglePushToTalk: (Boolean) -> Unit
) {
    var noiseSuppression by remember { mutableStateOf(settings.isNoiseSuppressionEnabled) }
    var echoCancellation by remember { mutableStateOf(settings.isEchoCancellationEnabled) }
    var micGain by remember { mutableStateOf(settings.micInputLevel) }
    var roomVolume by remember { mutableStateOf(settings.roomOutputVolume) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = "🎙️", fontSize = 22.sp)
                Text(
                    text = "إعدادات الدردشة الصوتية والمايك",
                    color = TextPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Mic Sensitivity Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "حساسية المايكروفون (Mic Gain)", color = TextPrimary, fontSize = 12.sp)
                        Text(text = "${(micGain * 100).toInt()}%", color = ElectricCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = micGain,
                        onValueChange = { micGain = it },
                        valueRange = 0.1f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricCyan,
                            activeTrackColor = ElectricCyan,
                            inactiveTrackColor = DarkSurfaceHighlight
                        )
                    )
                }

                // Room Master Volume Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "مستوى صوت الغرفة (Master Volume)", color = TextPrimary, fontSize = 12.sp)
                        Text(text = "${(roomVolume * 100).toInt()}%", color = HotPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = roomVolume,
                        onValueChange = { roomVolume = it },
                        valueRange = 0.0f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = HotPink,
                            activeTrackColor = HotPink,
                            inactiveTrackColor = DarkSurfaceHighlight
                        )
                    )
                }

                // Push to Talk Mode Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "وضع اضغط للتحدث (Push-to-Talk)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = "كتم المايك وتفعيله فقط عند الضغط", color = TextMuted, fontSize = 11.sp)
                    }
                    Switch(
                        checked = settings.isPushToTalk,
                        onCheckedChange = { onTogglePushToTalk(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = ElectricCyan,
                            checkedTrackColor = ElectricCyan.copy(alpha = 0.5f)
                        )
                    )
                }

                // Noise Suppression
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "عزل الضوضاء الذكي (AI Noise Cancelling)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = "تصفية صوت الخلفية والتنفس تلقائياً", color = TextMuted, fontSize = 11.sp)
                    }
                    Switch(
                        checked = noiseSuppression,
                        onCheckedChange = { noiseSuppression = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = EmeraldGreen,
                            checkedTrackColor = EmeraldGreen.copy(alpha = 0.5f)
                        )
                    )
                }

                // Echo Cancellation
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "منع صدى الصوت (Echo Cancellation)", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(text = "منع تكرار الصوت الصادر من السماعات", color = TextMuted, fontSize = 11.sp)
                    }
                    Switch(
                        checked = echoCancellation,
                        onCheckedChange = { echoCancellation = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = EmeraldGreen,
                            checkedTrackColor = EmeraldGreen.copy(alpha = 0.5f)
                        )
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
            ) {
                Text("حفظ وإغلاق", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = DarkSurface,
        shape = RoundedCornerShape(20.dp)
    )
}

@Composable
fun PlayerVoiceControlModal(
    player: RoomPlayer,
    onDismiss: () -> Unit,
    onVolumeChange: (Float) -> Unit,
    onToggleMute: () -> Unit
) {
    var volume by remember { mutableStateOf(player.voiceVolume) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(text = player.avatar, fontSize = 24.sp)
                Column {
                    Text(
                        text = player.name,
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${player.countryFlag} • ${player.rankTier.tierNameAr}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Individual Player Volume Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "مستوى صوت اللاعب", color = TextPrimary, fontSize = 12.sp)
                        Text(text = "${(volume * 100).toInt()}%", color = ElectricCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = volume,
                        onValueChange = {
                            volume = it
                            onVolumeChange(it)
                        },
                        valueRange = 0.0f..2.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = ElectricCyan,
                            activeTrackColor = ElectricCyan,
                            inactiveTrackColor = DarkSurfaceHighlight
                        )
                    )
                }

                // Mute this player locally
                Button(
                    onClick = {
                        onToggleMute()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (player.isMicOn) DarkSurfaceHighlight else EmeraldGreen
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = if (player.isMicOn) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                        contentDescription = "Mute/Unmute",
                        tint = TextPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (player.isMicOn) "كتم صوت هذا اللاعب محلياً 🔇" else "إلغاء كتم صوت اللاعب 🔊",
                        color = TextPrimary,
                        fontSize = 13.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan)
            ) {
                Text("تم", color = DarkBg, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = DarkSurface,
        shape = RoundedCornerShape(20.dp)
    )
}
